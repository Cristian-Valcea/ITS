# This file makes src/api a Python package.
# It can be empty or used for package-level initializations if needed.
# For example, you might want to import some common Pydantic models or services here
# to make them available at the package level, but it's not strictly necessary.

# from .main import app # Example if you want to expose the app object directly
# from . import services
# from . import config_models
# from . import request_models
# from . import response_models

# logging.getLogger(__name__).info("API package initialized.")
