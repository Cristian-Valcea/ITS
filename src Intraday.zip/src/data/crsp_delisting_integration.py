# src/data/crsp_delisting_integration.py
"""
CRSP Delisting Flags Integration

This module provides comprehensive integration with CRSP (Center for Research in Security Prices)
delisting data, which is the gold standard for survivorship bias elimination in academic and
institutional quantitative finance.

CRSP Delisting Codes (DLSTCD) Reference:
- 100-199: Bankruptcy, liquidation, or dropped due to financial difficulties
- 200-299: Mergers, acquisitions, or other corporate actions
- 300-399: Exchanges (moved to different exchange)
- 400-499: Dropped by exchange for other reasons
- 500-599: Dropped due to insufficient capital, assets, or market makers
- 600-699: Other reasons

Key Features:
- Comprehensive CRSP delisting code mapping
- Automatic data validation and cleaning
- Performance attribution for delisting events
- Integration with existing survivorship bias handler
"""

import pandas as pd
import numpy as np
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Set, Union
from pathlib import Path
import requests
import zipfile
import io

from .survivorship_bias_handler import SurvivorshipBiasHandler, DelistingEvent, DelistingReason


class CRSPDelistingIntegrator:
    """
    Comprehensive CRSP delisting data integration system.
    
    Handles the complete CRSP delisting workflow:
    1. Data acquisition and validation
    2. Code mapping and standardization
    3. Performance attribution calculation
    4. Integration with survivorship bias handler
    """
    
    # Comprehensive CRSP delisting code mapping
    CRSP_DELISTING_CODES = {
        # 100-199: Bankruptcy/Financial Difficulties
        100: {"reason": "100", "desc": "Bankruptcy", "recovery_rate": 0.0},
        101: {"reason": "100", "desc": "Bankruptcy - Chapter 11", "recovery_rate": 0.15},
        102: {"reason": "100", "desc": "Bankruptcy - Chapter 7", "recovery_rate": 0.0},
        110: {"reason": "100", "desc": "Liquidation", "recovery_rate": 0.05},
        111: {"reason": "100", "desc": "Voluntary liquidation", "recovery_rate": 0.20},
        120: {"reason": "500", "desc": "Insufficient capital", "recovery_rate": 0.0},
        130: {"reason": "600", "desc": "Regulatory issues", "recovery_rate": 0.0},
        
        # 200-299: Mergers/Acquisitions
        200: {"reason": "200", "desc": "Merger", "recovery_rate": None},
        201: {"reason": "200", "desc": "Cash merger", "recovery_rate": None},
        202: {"reason": "200", "desc": "Stock merger", "recovery_rate": None},
        203: {"reason": "200", "desc": "Mixed merger (cash + stock)", "recovery_rate": None},
        210: {"reason": "200", "desc": "Acquisition", "recovery_rate": None},
        220: {"reason": "200", "desc": "Spin-off", "recovery_rate": None},
        230: {"reason": "200", "desc": "Leveraged buyout", "recovery_rate": None},
        
        # 300-399: Exchange Changes
        300: {"reason": "400", "desc": "Moved to different exchange", "recovery_rate": None},
        301: {"reason": "400", "desc": "Moved to NASDAQ", "recovery_rate": None},
        302: {"reason": "400", "desc": "Moved to NYSE", "recovery_rate": None},
        303: {"reason": "400", "desc": "Moved to AMEX", "recovery_rate": None},
        310: {"reason": "400", "desc": "Moved to OTC", "recovery_rate": None},
        
        # 400-499: Exchange Delisting
        400: {"reason": "600", "desc": "Dropped by exchange", "recovery_rate": 0.0},
        401: {"reason": "600", "desc": "Failed to meet listing requirements", "recovery_rate": 0.0},
        402: {"reason": "600", "desc": "Insufficient market makers", "recovery_rate": 0.0},
        410: {"reason": "600", "desc": "Regulatory delisting", "recovery_rate": 0.0},
        
        # 500-599: Insufficient Assets/Capital
        500: {"reason": "500", "desc": "Insufficient assets", "recovery_rate": 0.0},
        501: {"reason": "500", "desc": "Insufficient shareholders", "recovery_rate": 0.0},
        502: {"reason": "500", "desc": "Insufficient market value", "recovery_rate": 0.0},
        510: {"reason": "500", "desc": "Insufficient trading volume", "recovery_rate": 0.0},
        
        # 600-699: Other Reasons
        600: {"reason": "999", "desc": "Other reasons", "recovery_rate": 0.0},
        601: {"reason": "999", "desc": "Maturity (bonds/preferred)", "recovery_rate": 1.0},
        602: {"reason": "999", "desc": "Called (bonds/preferred)", "recovery_rate": 1.0},
        610: {"reason": "999", "desc": "Name change only", "recovery_rate": None},
        620: {"reason": "999", "desc": "CUSIP change only", "recovery_rate": None},
    }
    
    def __init__(self, 
                 survivorship_handler: SurvivorshipBiasHandler,
                 logger: Optional[logging.Logger] = None):
        """
        Initialize CRSP delisting integrator.
        
        Args:
            survivorship_handler: SurvivorshipBiasHandler instance
            logger: Optional logger instance
        """
        self.survivorship_handler = survivorship_handler
        self.logger = logger or logging.getLogger(__name__)
        
        # Performance tracking
        self.load_statistics = {
            'total_records': 0,
            'valid_records': 0,
            'invalid_records': 0,
            'duplicate_records': 0,
            'events_created': 0,
            'load_time': None
        }
        
        self.logger.info("CRSPDelistingIntegrator initialized")
    
    def load_crsp_delisting_file(self, 
                               file_path: str,
                               file_format: str = "csv",
                               validate_data: bool = True,
                               calculate_returns: bool = True) -> Dict:
        """
        Load CRSP delisting data from file with comprehensive processing.
        
        Args:
            file_path: Path to CRSP delisting file
            file_format: File format ("csv", "sas", "stata")
            validate_data: Whether to validate data quality
            calculate_returns: Whether to calculate delisting returns
            
        Returns:
            Dictionary with load statistics and results
        """
        start_time = datetime.now()
        self.logger.info(f"Loading CRSP delisting data from {file_path}")
        
        try:
            # Load data based on format
            if file_format.lower() == "csv":
                df = pd.read_csv(file_path)
            elif file_format.lower() == "sas":
                df = pd.read_sas(file_path)
            elif file_format.lower() == "stata":
                df = pd.read_stata(file_path)
            else:
                raise ValueError(f"Unsupported file format: {file_format}")
            
            self.load_statistics['total_records'] = len(df)
            
            # Standardize column names (CRSP uses various naming conventions)
            df = self._standardize_crsp_columns(df)
            
            # Validate data if requested
            if validate_data:
                df = self._validate_crsp_data(df)
            
            # Process delisting events
            events_created = self._process_crsp_delisting_events(df, calculate_returns)
            
            # Update statistics
            self.load_statistics['events_created'] = events_created
            self.load_statistics['load_time'] = (datetime.now() - start_time).total_seconds()
            
            self.logger.info(f"CRSP delisting data loaded successfully:")
            self.logger.info(f"  Total records: {self.load_statistics['total_records']}")
            self.logger.info(f"  Valid records: {self.load_statistics['valid_records']}")
            self.logger.info(f"  Events created: {self.load_statistics['events_created']}")
            self.logger.info(f"  Load time: {self.load_statistics['load_time']:.2f} seconds")
            
            return self.load_statistics
            
        except Exception as e:
            self.logger.error(f"Error loading CRSP delisting data: {e}")
            return {'error': str(e), 'events_created': 0}
    
    def _standardize_crsp_columns(self, df: pd.DataFrame) -> pd.DataFrame:
        """Standardize CRSP column names across different data versions."""
        
        # Common CRSP column mappings
        column_mappings = {
            # Identifiers
            'PERMNO': 'permno',
            'PERMCO': 'permco', 
            'TICKER': 'ticker',
            'CUSIP': 'cusip',
            'NCUSIP': 'cusip',
            'COMNAM': 'company_name',
            
            # Delisting information
            'DLSTDT': 'delist_date',
            'DLSTCD': 'delist_code',
            'DLPRC': 'delist_price',
            'DLRET': 'delist_return',
            'DLRETX': 'delist_return_ex_div',
            
            # Additional fields
            'EXCHCD': 'exchange_code',
            'SHRCD': 'share_code',
            'SICCD': 'sic_code',
            'NAMEDT': 'name_date',
            'NAMEENDT': 'name_end_date'
        }
        
        # Apply mappings
        df_standardized = df.copy()
        for old_name, new_name in column_mappings.items():
            if old_name in df.columns:
                df_standardized = df_standardized.rename(columns={old_name: new_name})
        
        # Ensure required columns exist
        required_columns = ['ticker', 'delist_date', 'delist_code']
        missing_columns = [col for col in required_columns if col not in df_standardized.columns]
        
        if missing_columns:
            raise ValueError(f"Missing required CRSP columns: {missing_columns}")
        
        return df_standardized
    
    def _validate_crsp_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """Validate and clean CRSP delisting data."""
        
        initial_count = len(df)
        
        # Remove records with missing critical data
        df_clean = df.dropna(subset=['ticker', 'delist_date', 'delist_code']).copy()
        
        # Convert dates
        df_clean['delist_date'] = pd.to_datetime(df_clean['delist_date'], errors='coerce')
        df_clean = df_clean.dropna(subset=['delist_date'])
        
        # Validate delisting codes
        df_clean['delist_code'] = pd.to_numeric(df_clean['delist_code'], errors='coerce')
        df_clean = df_clean.dropna(subset=['delist_code'])
        df_clean['delist_code'] = df_clean['delist_code'].astype(int)
        
        # Remove invalid tickers (common CRSP data issues)
        invalid_tickers = ['', 'N/A', 'NULL', 'NONE']
        df_clean = df_clean[~df_clean['ticker'].isin(invalid_tickers)]
        
        # Remove future dates (data quality issue)
        today = datetime.now().date()
        df_clean = df_clean[df_clean['delist_date'].dt.date <= today]
        
        # Remove duplicates (keep most recent)
        df_clean = df_clean.sort_values('delist_date').drop_duplicates(
            subset=['ticker', 'delist_date'], keep='last'
        )
        
        # Update statistics
        self.load_statistics['valid_records'] = len(df_clean)
        self.load_statistics['invalid_records'] = initial_count - len(df_clean)
        
        self.logger.info(f"Data validation completed:")
        self.logger.info(f"  Valid records: {len(df_clean)}/{initial_count}")
        self.logger.info(f"  Removed {initial_count - len(df_clean)} invalid records")
        
        return df_clean
    
    def _process_crsp_delisting_events(self, 
                                     df: pd.DataFrame, 
                                     calculate_returns: bool = True) -> int:
        """Process CRSP delisting events and create DelistingEvent objects."""
        
        events_created = 0
        
        for _, row in df.iterrows():
            try:
                # Get delisting code information
                delist_code = int(row['delist_code'])
                code_info = self.CRSP_DELISTING_CODES.get(
                    delist_code, 
                    {"reason": "999", "desc": f"Unknown CRSP code {delist_code}", "recovery_rate": 0.0}
                )
                
                # Calculate delisting return if available and requested
                delisting_return = None
                if calculate_returns and 'delist_return' in row and pd.notna(row['delist_return']):
                    delisting_return = float(row['delist_return'])
                
                # Determine final price
                final_price = None
                if 'delist_price' in row and pd.notna(row['delist_price']):
                    final_price = float(row['delist_price'])
                elif delisting_return is not None:
                    # Estimate final price from return (would need previous price)
                    # This is a placeholder - in practice, you'd join with price data
                    pass
                
                # Handle merger information
                acquirer_symbol = None
                exchange_ratio = None
                if code_info["reason"] == "200":  # Merger
                    # In practice, you'd have additional merger data
                    # This could come from CRSP merger files or other sources
                    pass
                
                # Create delisting event
                event = DelistingEvent(
                    symbol=row['ticker'].strip().upper(),
                    delist_date=row['delist_date'].to_pydatetime(),
                    reason_code=code_info["reason"],
                    reason_desc=f"CRSP {delist_code}: {code_info['desc']}",
                    final_price=final_price,
                    recovery_rate=code_info["recovery_rate"],
                    acquirer_symbol=acquirer_symbol,
                    exchange_ratio=exchange_ratio,
                    data_source="CRSP"
                )
                
                # Add additional metadata if available
                if hasattr(event, 'metadata'):
                    event.metadata = {
                        'crsp_permno': row.get('permno'),
                        'crsp_permco': row.get('permco'),
                        'cusip': row.get('cusip'),
                        'company_name': row.get('company_name'),
                        'exchange_code': row.get('exchange_code'),
                        'sic_code': row.get('sic_code'),
                        'delisting_return': delisting_return
                    }
                
                # Add to survivorship handler
                if self.survivorship_handler.add_delisting_event(event):
                    events_created += 1
                else:
                    self.load_statistics['duplicate_records'] += 1
                    
            except Exception as e:
                self.logger.warning(f"Error processing CRSP record for {row.get('ticker', 'UNKNOWN')}: {e}")
                continue
        
        return events_created
    
    def download_crsp_sample_data(self, output_path: str = "data/crsp_sample.csv") -> bool:
        """
        Download sample CRSP delisting data for testing.
        Note: This is a placeholder - actual CRSP data requires subscription.
        """
        try:
            # Create sample CRSP-format data for testing
            sample_data = [
                # Format: TICKER, DLSTDT, DLSTCD, DLPRC, DLRET, COMNAM
                ["ENRN", "2001-11-28", 100, 0.26, -0.99, "ENRON CORP"],
                ["WCOM", "2002-07-01", 100, 0.83, -0.95, "WORLDCOM INC"],
                ["BEAR", "2008-05-30", 200, 10.00, -0.90, "BEAR STEARNS COMPANIES INC"],
                ["LEH", "2008-09-15", 100, 0.21, -0.99, "LEHMAN BROTHERS HOLDINGS INC"],
                ["WAMU", "2008-09-25", 100, 0.00, -1.00, "WASHINGTON MUTUAL INC"],
                ["GM", "2009-06-01", 101, 0.75, -0.98, "GENERAL MOTORS CORP"],
                ["CRY", "2009-04-30", 100, 0.00, -1.00, "CHRYSLER LLC"],
                ["YHOO", "2017-06-13", 200, 48.17, 0.00, "YAHOO! INC"],
                ["LNKD", "2016-12-08", 200, 196.00, 0.50, "LINKEDIN CORP"],
                ["SHLD", "2018-10-15", 100, 0.15, -0.99, "SEARS HOLDINGS CORP"]
            ]
            
            # Create DataFrame
            df = pd.DataFrame(sample_data, columns=[
                'TICKER', 'DLSTDT', 'DLSTCD', 'DLPRC', 'DLRET', 'COMNAM'
            ])
            
            # Add additional CRSP-style columns
            df['PERMNO'] = range(10000, 10000 + len(df))
            df['PERMCO'] = range(1000, 1000 + len(df))
            df['EXCHCD'] = [1, 1, 1, 1, 1, 1, 1, 3, 3, 1]  # 1=NYSE, 3=NASDAQ
            df['SHRCD'] = [10] * len(df)  # 10=Common stock
            
            # Save to file
            Path(output_path).parent.mkdir(parents=True, exist_ok=True)
            df.to_csv(output_path, index=False)
            
            self.logger.info(f"Sample CRSP data created at {output_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error creating sample CRSP data: {e}")
            return False
    
    def analyze_crsp_coverage(self, 
                            start_date: datetime, 
                            end_date: datetime,
                            universe: Set[str]) -> Dict:
        """
        Analyze CRSP delisting coverage for a given universe and time period.
        
        Args:
            start_date: Analysis start date
            end_date: Analysis end date
            universe: Set of symbols to analyze
            
        Returns:
            Dictionary with coverage analysis
        """
        # Get all delisting events in period
        all_events = self.survivorship_handler.get_delisting_events(
            start_date=start_date,
            end_date=end_date
        )
        
        # Filter to CRSP events
        crsp_events = [e for e in all_events if e.data_source == "CRSP"]
        
        # Filter to universe
        universe_events = [e for e in crsp_events if e.symbol in universe]
        
        # Analyze by delisting reason
        reason_breakdown = {}
        for event in universe_events:
            reason = event.reason_code
            if reason not in reason_breakdown:
                reason_breakdown[reason] = []
            reason_breakdown[reason].append(event.symbol)
        
        # Calculate coverage metrics
        total_universe_delistings = len([e for e in all_events if e.symbol in universe])
        crsp_coverage_rate = len(universe_events) / total_universe_delistings if total_universe_delistings > 0 else 1.0
        
        analysis = {
            'period': {
                'start_date': start_date.isoformat(),
                'end_date': end_date.isoformat(),
                'days': (end_date - start_date).days
            },
            'universe_size': len(universe),
            'total_delistings': total_universe_delistings,
            'crsp_delistings': len(universe_events),
            'crsp_coverage_rate': crsp_coverage_rate,
            'reason_breakdown': {k: len(v) for k, v in reason_breakdown.items()},
            'delisted_symbols': {k: v for k, v in reason_breakdown.items()},
            'missing_coverage': total_universe_delistings - len(universe_events)
        }
        
        return analysis
    
    def generate_crsp_quality_report(self) -> Dict:
        """Generate data quality report for loaded CRSP data."""
        
        # Get all CRSP events
        all_events = self.survivorship_handler.get_delisting_events()
        crsp_events = [e for e in all_events if e.data_source == "CRSP"]
        
        if not crsp_events:
            return {'error': 'No CRSP data found'}
        
        # Analyze data quality
        total_events = len(crsp_events)
        events_with_price = len([e for e in crsp_events if e.final_price is not None])
        events_with_recovery = len([e for e in crsp_events if e.recovery_rate is not None])
        
        # Date range analysis
        dates = [e.delist_date for e in crsp_events]
        min_date = min(dates)
        max_date = max(dates)
        
        # Reason code analysis
        reason_counts = {}
        for event in crsp_events:
            reason = event.reason_code
            reason_counts[reason] = reason_counts.get(reason, 0) + 1
        
        # Temporal distribution (by year)
        year_counts = {}
        for event in crsp_events:
            year = event.delist_date.year
            year_counts[year] = year_counts.get(year, 0) + 1
        
        report = {
            'summary': {
                'total_crsp_events': total_events,
                'date_range': {
                    'earliest': min_date.isoformat(),
                    'latest': max_date.isoformat(),
                    'span_years': (max_date - min_date).days / 365.25
                },
                'data_completeness': {
                    'events_with_price': events_with_price,
                    'price_coverage_rate': events_with_price / total_events,
                    'events_with_recovery': events_with_recovery,
                    'recovery_coverage_rate': events_with_recovery / total_events
                }
            },
            'reason_breakdown': reason_counts,
            'temporal_distribution': year_counts,
            'load_statistics': self.load_statistics
        }
        
        return report
    
    def export_delisting_summary(self, output_path: str) -> bool:
        """Export comprehensive delisting summary to CSV."""
        try:
            # Get all CRSP events
            all_events = self.survivorship_handler.get_delisting_events()
            crsp_events = [e for e in all_events if e.data_source == "CRSP"]
            
            if not crsp_events:
                self.logger.warning("No CRSP events to export")
                return False
            
            # Create summary DataFrame
            summary_data = []
            for event in crsp_events:
                summary_data.append({
                    'symbol': event.symbol,
                    'delist_date': event.delist_date.strftime('%Y-%m-%d'),
                    'reason_code': event.reason_code,
                    'reason_desc': event.reason_desc,
                    'final_price': event.final_price,
                    'recovery_rate': event.recovery_rate,
                    'acquirer_symbol': event.acquirer_symbol,
                    'exchange_ratio': event.exchange_ratio,
                    'data_source': event.data_source
                })
            
            df = pd.DataFrame(summary_data)
            df.to_csv(output_path, index=False)
            
            self.logger.info(f"CRSP delisting summary exported to {output_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error exporting delisting summary: {e}")
            return False


def create_production_crsp_pipeline(survivorship_handler: SurvivorshipBiasHandler,
                                  crsp_data_path: str,
                                  update_frequency: str = "monthly") -> Dict:
    """
    Create production CRSP data pipeline.
    
    Args:
        survivorship_handler: SurvivorshipBiasHandler instance
        crsp_data_path: Path to CRSP data files
        update_frequency: Update frequency ("daily", "weekly", "monthly")
        
    Returns:
        Pipeline configuration and status
    """
    integrator = CRSPDelistingIntegrator(survivorship_handler)
    
    # Load initial CRSP data
    load_stats = integrator.load_crsp_delisting_file(crsp_data_path)
    
    # Generate quality report
    quality_report = integrator.generate_crsp_quality_report()
    
    # Analyze coverage
    # This would typically analyze against a known universe like S&P 500
    sample_universe = {"AAPL", "GOOGL", "MSFT", "ENRN", "WCOM", "LEH"}
    coverage_analysis = integrator.analyze_crsp_coverage(
        start_date=datetime(2000, 1, 1),
        end_date=datetime(2020, 1, 1),
        universe=sample_universe
    )
    
    pipeline_config = {
        'status': 'active',
        'data_source': crsp_data_path,
        'update_frequency': update_frequency,
        'last_update': datetime.now().isoformat(),
        'load_statistics': load_stats,
        'quality_report': quality_report,
        'coverage_analysis': coverage_analysis,
        'next_update': (datetime.now() + timedelta(days=30)).isoformat()  # Monthly
    }
    
    return pipeline_config


if __name__ == "__main__":
    # Example usage
    logging.basicConfig(level=logging.INFO)
    
    # Initialize components
    from .survivorship_bias_handler import SurvivorshipBiasHandler
    
    handler = SurvivorshipBiasHandler("data/crsp_test.db")
    integrator = CRSPDelistingIntegrator(handler)
    
    # Create sample CRSP data
    integrator.download_crsp_sample_data("data/crsp_sample.csv")
    
    # Load CRSP data
    load_stats = integrator.load_crsp_delisting_file("data/crsp_sample.csv")
    print(f"Loaded {load_stats['events_created']} CRSP delisting events")
    
    # Generate quality report
    quality_report = integrator.generate_crsp_quality_report()
    print(f"CRSP data quality report:")
    print(f"  Total events: {quality_report['summary']['total_crsp_events']}")
    print(f"  Date range: {quality_report['summary']['date_range']['earliest']} to {quality_report['summary']['date_range']['latest']}")
    print(f"  Price coverage: {quality_report['summary']['data_completeness']['price_coverage_rate']:.1%}")
    
    # Export summary
    integrator.export_delisting_summary("data/crsp_delisting_summary.csv")
    print("CRSP delisting summary exported")