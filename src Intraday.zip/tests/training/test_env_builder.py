#!/usr/bin/env python3
"""
Unit tests for Environment Builder component.

Tests the environment building functionality including:
- Environment creation and configuration
- Observation and action space building
- Environment parameter validation
- Reward configuration
- Environment wrapper integration
"""

import pytest
from unittest.mock import MagicMock, patch
import numpy as np

# Import the module under test
try:
    from src.training.core.env_builder import (
        make_env, build_observation_space, build_action_space,
        validate_environment_config, configure_reward_function
    )
    # Try to import gym/gymnasium
    try:
        import gymnasium as gym
        spaces = gym.spaces
    except ImportError:
        try:
            import gym
            spaces = gym.spaces
        except ImportError:
            spaces = None
except ImportError:
    # Fallback for testing without full dependencies
    make_env = None
    build_observation_space = None
    build_action_space = None
    validate_environment_config = None
    configure_reward_function = None
    spaces = None

@pytest.fixture
def mock_config():
    """Mock configuration for environment building."""
    return {
        'environment': {
            'env_type': 'trading',
            'initial_balance': 100000,
            'transaction_cost': 0.001,
            'max_steps': 1000
        },
        'observation': {
            'feature_columns': ['rsi_14', 'ema_10', 'ema_20', 'price'],
            'lookback_window': 10,
            'normalize': True
        },
        'action': {
            'action_type': 'discrete',
            'num_actions': 3,  # Hold, Buy, Sell
            'position_sizing': 'fixed'
        },
        'reward': {
            'reward_type': 'pnl',
            'risk_penalty': 0.1,
            'transaction_penalty': 0.01
        }
    }

@pytest.fixture
def sample_data():
    """Sample market data for testing."""
    return {
        'prices': np.random.randn(1000, 4) + 100,  # OHLC data
        'features': np.random.randn(1000, 10),     # Technical indicators
        'timestamps': np.arange(1000)
    }

@pytest.mark.skipif(make_env is None, reason="Environment builder not available")
class TestEnvironmentBuilder:
    """Test suite for Environment Builder."""
    
    def test_environment_creation(self, mock_config, sample_data):
        """Test environment creation."""
        env = make_env(mock_config, sample_data)
        
        assert env is not None
        assert hasattr(env, 'reset')
        assert hasattr(env, 'step')
        assert hasattr(env, 'observation_space')
        assert hasattr(env, 'action_space')
    
    def test_observation_space_building(self, mock_config):
        """Test observation space building."""
        feature_columns = mock_config['observation']['feature_columns']
        
        obs_space = build_observation_space(feature_columns, mock_config)
        
        assert obs_space is not None
        if spaces is not None:
            assert isinstance(obs_space, spaces.Box)
            assert obs_space.shape == (len(feature_columns),)
        else:
            # Mock space
            assert obs_space['shape'] == (len(feature_columns),)
    
    def test_action_space_building(self, mock_config):
        """Test action space building."""
        action_space = build_action_space(mock_config)
        
        assert action_space is not None
        if spaces is not None:
            assert isinstance(action_space, spaces.Discrete)
            assert action_space.n == 3
        else:
            # Mock space
            assert action_space['n'] == 3
    
    def test_continuous_action_space(self, mock_config):
        """Test continuous action space building."""
        mock_config['action']['action_type'] = 'continuous'
        
        action_space = build_action_space(mock_config)
        
        assert action_space is not None
        if spaces is not None:
            assert isinstance(action_space, spaces.Box)
            assert action_space.shape == (1,)
        else:
            # Mock space
            assert action_space['shape'] == (1,)
    
    def test_environment_config_validation(self, mock_config):
        """Test environment configuration validation."""
        # Test valid config
        is_valid = validate_environment_config(mock_config)
        assert is_valid is True
        
        # Test invalid config - missing required fields
        invalid_config = {'environment': {}}
        is_valid = validate_environment_config(invalid_config)
        assert is_valid is False
        
        # Test invalid config - negative values
        invalid_config = mock_config.copy()
        invalid_config['environment']['initial_balance'] = -1000
        is_valid = validate_environment_config(invalid_config)
        assert is_valid is False
    
    def test_reward_function_configuration(self, mock_config):
        """Test reward function configuration."""
        reward_fn = configure_reward_function(mock_config)
        
        assert callable(reward_fn)
        
        # Test reward calculation
        mock_state = {
            'pnl': 100.0,
            'position': 0.5,
            'transaction_cost': 1.0
        }
        
        reward = reward_fn(mock_state)
        assert isinstance(reward, float)
    
    def test_environment_wrappers(self, mock_config, sample_data):
        """Test environment wrapper integration."""
        mock_config['wrappers'] = {
            'normalize_observations': True,
            'clip_actions': True,
            'frame_stack': 4
        }
        
        env = make_env(mock_config, sample_data)
        
        # Environment should be wrapped
        assert env is not None
        # Check if wrappers are applied (this would depend on implementation)
    
    def test_observation_preprocessing(self, mock_config):
        """Test observation preprocessing."""
        feature_columns = ['price', 'volume', 'rsi', 'macd']
        mock_config['observation']['feature_columns'] = feature_columns
        mock_config['observation']['normalize'] = True
        
        obs_space = build_observation_space(feature_columns, mock_config)
        
        assert obs_space is not None
        if spaces is not None:
            # Check normalization bounds
            assert np.all(obs_space.low == -np.inf)
            assert np.all(obs_space.high == np.inf)
    
    def test_custom_observation_bounds(self, mock_config):
        """Test custom observation bounds."""
        feature_columns = ['price', 'volume']
        mock_config['observation']['feature_columns'] = feature_columns
        mock_config['observation_bounds'] = {
            'low': [0, 0],
            'high': [1000, 1000000]
        }
        
        obs_space = build_observation_space(feature_columns, mock_config)
        
        assert obs_space is not None
        if spaces is not None:
            assert np.array_equal(obs_space.low, [0, 0])
            assert np.array_equal(obs_space.high, [1000, 1000000])
    
    def test_multi_asset_environment(self, mock_config, sample_data):
        """Test multi-asset environment creation."""
        mock_config['environment']['assets'] = ['AAPL', 'MSFT', 'GOOGL']
        mock_config['observation']['feature_columns'] = [
            'aapl_price', 'msft_price', 'googl_price',
            'aapl_rsi', 'msft_rsi', 'googl_rsi'
        ]
        
        env = make_env(mock_config, sample_data)
        
        assert env is not None
        # Check observation space accommodates multiple assets
        if hasattr(env, 'observation_space'):
            if spaces is not None:
                assert env.observation_space.shape[0] == 6
    
    def test_environment_seeding(self, mock_config, sample_data):
        """Test environment seeding for reproducibility."""
        seed = 42
        
        env1 = make_env(mock_config, sample_data, seed=seed)
        env2 = make_env(mock_config, sample_data, seed=seed)
        
        # Reset both environments
        obs1 = env1.reset()
        obs2 = env2.reset()
        
        # Should produce same initial observations
        if isinstance(obs1, tuple):
            obs1 = obs1[0]
        if isinstance(obs2, tuple):
            obs2 = obs2[0]
            
        np.testing.assert_array_equal(obs1, obs2)
    
    def test_environment_step_functionality(self, mock_config, sample_data):
        """Test environment step functionality."""
        env = make_env(mock_config, sample_data)
        
        obs = env.reset()
        if isinstance(obs, tuple):
            obs = obs[0]
        
        # Take a step
        action = env.action_space.sample() if hasattr(env.action_space, 'sample') else 0
        step_result = env.step(action)
        
        assert len(step_result) >= 4  # obs, reward, done, info
        
        next_obs, reward, done, info = step_result[:4]
        
        assert isinstance(reward, (int, float))
        assert isinstance(done, bool)
        assert isinstance(info, dict)


class TestEnvironmentBuilderMock:
    """Test suite using mock environment builder when real one isn't available."""
    
    def test_mock_environment_builder(self, mock_config, sample_data):
        """Test with mock environment builder."""
        # Create mock functions
        def mock_make_env(config, data, seed=None):
            class MockEnv:
                def __init__(self):
                    self.observation_space = MockSpace('box', (4,))
                    self.action_space = MockSpace('discrete', 3)
                    self.current_step = 0
                
                def reset(self):
                    self.current_step = 0
                    return np.random.randn(4)
                
                def step(self, action):
                    self.current_step += 1
                    obs = np.random.randn(4)
                    reward = np.random.randn()
                    done = self.current_step >= 100
                    info = {'step': self.current_step}
                    return obs, reward, done, info
                
                def close(self):
                    pass
            
            return MockEnv()
        
        def mock_build_observation_space(feature_columns, config):
            return MockSpace('box', (len(feature_columns),))
        
        def mock_build_action_space(config):
            if config['action']['action_type'] == 'discrete':
                return MockSpace('discrete', config['action']['num_actions'])
            else:
                return MockSpace('box', (1,))
        
        def mock_validate_environment_config(config):
            required_keys = ['environment', 'observation', 'action']
            return all(key in config for key in required_keys)
        
        def mock_configure_reward_function(config):
            def reward_fn(state):
                return state.get('pnl', 0.0) - state.get('transaction_cost', 0.0)
            return reward_fn
        
        class MockSpace:
            def __init__(self, space_type, shape_or_n):
                self.type = space_type
                if space_type == 'box':
                    self.shape = shape_or_n
                    self.low = np.full(shape_or_n, -np.inf)
                    self.high = np.full(shape_or_n, np.inf)
                else:  # discrete
                    self.n = shape_or_n
            
            def sample(self):
                if self.type == 'box':
                    return np.random.randn(*self.shape)
                else:
                    return np.random.randint(0, self.n)
        
        # Test environment creation
        env = mock_make_env(mock_config, sample_data)
        assert env is not None
        
        # Test observation space
        obs_space = mock_build_observation_space(['a', 'b', 'c'], mock_config)
        assert obs_space.shape == (3,)
        
        # Test action space
        action_space = mock_build_action_space(mock_config)
        assert action_space.n == 3
        
        # Test validation
        is_valid = mock_validate_environment_config(mock_config)
        assert is_valid is True
        
        # Test reward function
        reward_fn = mock_configure_reward_function(mock_config)
        reward = reward_fn({'pnl': 100, 'transaction_cost': 1})
        assert reward == 99.0
        
        # Test environment functionality
        obs = env.reset()
        assert obs.shape == (4,)
        
        action = env.action_space.sample()
        step_result = env.step(action)
        assert len(step_result) == 4


@pytest.mark.integration
class TestEnvironmentBuilderIntegration:
    """Integration tests for Environment Builder."""
    
    @pytest.mark.skipif(make_env is None, reason="Environment builder not available")
    def test_full_environment_integration(self, mock_config, sample_data):
        """Test full environment integration."""
        # This would test with real trading environment when available
        # For now, we'll skip if components aren't available
        pytest.skip("Full integration test requires trading environment dependencies")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])