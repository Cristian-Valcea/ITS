#!/usr/bin/env python3
"""
Unit tests for Hyperparameter Search component.

Tests the hyperparameter optimization functionality including:
- Optuna integration
- Search space definition
- Parameter validation
- Multi-objective optimization
- Results analysis and saving
"""

import pytest
from unittest.mock import MagicMock, patch
import tempfile
import shutil
import json
from pathlib import Path

# Import the module under test
try:
    from src.training.core.hyperparam_search import (
        run_hyperparameter_study, define_search_space,
        validate_hyperparameters, analyze_study_results
    )
    import optuna
    OPTUNA_AVAILABLE = True
except ImportError:
    # Fallback for testing without full dependencies
    run_hyperparameter_study = None
    define_search_space = None
    validate_hyperparameters = None
    analyze_study_results = None
    optuna = None
    OPTUNA_AVAILABLE = False

@pytest.fixture
def mock_config():
    """Mock configuration for hyperparameter search."""
    return {
        'algorithm': 'DQN',
        'search': {
            'n_trials': 10,
            'timeout': 3600,
            'n_jobs': 1,
            'direction': 'maximize'
        },
        'search_space': {
            'learning_rate': {
                'type': 'float',
                'low': 1e-5,
                'high': 1e-2,
                'log': True
            },
            'gamma': {
                'type': 'float',
                'low': 0.9,
                'high': 0.999
            },
            'buffer_size': {
                'type': 'int',
                'low': 1000,
                'high': 100000,
                'step': 1000
            },
            'batch_size': {
                'type': 'categorical',
                'choices': [16, 32, 64, 128]
            }
        }
    }

@pytest.fixture
def temp_study_dir():
    """Create temporary directory for study results."""
    temp_dir = Path(tempfile.mkdtemp())
    yield temp_dir
    shutil.rmtree(temp_dir, ignore_errors=True)

@pytest.fixture
def mock_objective_function():
    """Mock objective function for optimization."""
    def objective(trial):
        # Mock hyperparameter suggestions
        lr = trial.suggest_float('learning_rate', 1e-5, 1e-2, log=True)
        gamma = trial.suggest_float('gamma', 0.9, 0.999)
        buffer_size = trial.suggest_int('buffer_size', 1000, 100000, step=1000)
        batch_size = trial.suggest_categorical('batch_size', [16, 32, 64, 128])
        
        # Mock training and evaluation
        # Return a score based on hyperparameters (for testing)
        score = lr * 1000 + gamma * 100 + buffer_size / 1000 + batch_size
        return score
    
    return objective

@pytest.mark.skipif(not OPTUNA_AVAILABLE, reason="Optuna not available")
class TestHyperparameterSearch:
    """Test suite for Hyperparameter Search."""
    
    def test_search_space_definition(self, mock_config):
        """Test search space definition."""
        search_space = define_search_space('DQN', mock_config)
        
        assert 'learning_rate' in search_space
        assert 'gamma' in search_space
        assert 'buffer_size' in search_space
        assert 'batch_size' in search_space
        
        # Check parameter types
        assert search_space['learning_rate']['type'] == 'float'
        assert search_space['batch_size']['type'] == 'categorical'
    
    def test_parameter_validation(self, mock_config):
        """Test hyperparameter validation."""
        # Test valid parameters
        valid_params = {
            'learning_rate': 0.001,
            'gamma': 0.95,
            'buffer_size': 10000,
            'batch_size': 32
        }
        
        is_valid = validate_hyperparameters(valid_params, 'DQN')
        assert is_valid is True
        
        # Test invalid parameters
        invalid_params = {
            'learning_rate': -0.001,  # Negative learning rate
            'gamma': 1.5,             # Gamma > 1
            'buffer_size': 0,         # Zero buffer size
            'batch_size': 7           # Invalid batch size
        }
        
        is_valid = validate_hyperparameters(invalid_params, 'DQN')
        assert is_valid is False
    
    def test_study_creation_and_execution(self, mock_config, mock_objective_function, temp_study_dir):
        """Test study creation and execution."""
        study_name = "test_study"
        
        study = run_hyperparameter_study(
            objective=mock_objective_function,
            config=mock_config,
            study_name=study_name,
            storage_path=temp_study_dir / "study.db"
        )
        
        assert study is not None
        assert len(study.trials) == mock_config['search']['n_trials']
        assert study.best_trial is not None
    
    def test_multi_objective_optimization(self, mock_config, temp_study_dir):
        """Test multi-objective optimization."""
        def multi_objective(trial):
            lr = trial.suggest_float('learning_rate', 1e-5, 1e-2, log=True)
            gamma = trial.suggest_float('gamma', 0.9, 0.999)
            
            # Return multiple objectives: reward and stability
            reward = lr * 1000 + gamma * 100
            stability = 1.0 - abs(lr - 0.001)  # Prefer lr around 0.001
            
            return reward, stability
        
        mock_config['search']['direction'] = ['maximize', 'maximize']
        
        study = run_hyperparameter_study(
            objective=multi_objective,
            config=mock_config,
            study_name="multi_objective_test",
            storage_path=temp_study_dir / "multi_study.db"
        )
        
        assert study is not None
        assert len(study.trials) == mock_config['search']['n_trials']
    
    def test_pruning_integration(self, mock_config, temp_study_dir):
        """Test pruning integration for early stopping."""
        def prunable_objective(trial):
            # Simulate training with intermediate values
            for step in range(10):
                intermediate_value = step * 0.1
                trial.report(intermediate_value, step)
                
                # Check if trial should be pruned
                if trial.should_prune():
                    raise optuna.TrialPruned()
            
            return 1.0
        
        # Add pruner to config
        mock_config['search']['pruner'] = 'median'
        
        study = run_hyperparameter_study(
            objective=prunable_objective,
            config=mock_config,
            study_name="pruning_test",
            storage_path=temp_study_dir / "pruning_study.db"
        )
        
        assert study is not None
        # Some trials should be pruned
        pruned_trials = [t for t in study.trials if t.state == optuna.trial.TrialState.PRUNED]
        assert len(pruned_trials) >= 0  # May or may not have pruned trials
    
    def test_study_results_analysis(self, mock_config, mock_objective_function, temp_study_dir):
        """Test study results analysis."""
        study = run_hyperparameter_study(
            objective=mock_objective_function,
            config=mock_config,
            study_name="analysis_test",
            storage_path=temp_study_dir / "analysis_study.db"
        )
        
        results = analyze_study_results(study)
        
        assert 'best_params' in results
        assert 'best_value' in results
        assert 'n_trials' in results
        assert 'parameter_importance' in results
        
        # Check best parameters
        best_params = results['best_params']
        assert 'learning_rate' in best_params
        assert 'gamma' in best_params
    
    def test_study_persistence(self, mock_config, mock_objective_function, temp_study_dir):
        """Test study persistence and loading."""
        storage_path = temp_study_dir / "persistent_study.db"
        study_name = "persistent_test"
        
        # Create and run study
        study1 = run_hyperparameter_study(
            objective=mock_objective_function,
            config=mock_config,
            study_name=study_name,
            storage_path=storage_path
        )
        
        n_trials_1 = len(study1.trials)
        
        # Load existing study and continue
        mock_config['search']['n_trials'] = 5  # Add more trials
        study2 = run_hyperparameter_study(
            objective=mock_objective_function,
            config=mock_config,
            study_name=study_name,
            storage_path=storage_path,
            load_if_exists=True
        )
        
        # Should have more trials now
        assert len(study2.trials) >= n_trials_1
    
    def test_parallel_optimization(self, mock_config, mock_objective_function, temp_study_dir):
        """Test parallel optimization."""
        mock_config['search']['n_jobs'] = 2
        
        study = run_hyperparameter_study(
            objective=mock_objective_function,
            config=mock_config,
            study_name="parallel_test",
            storage_path=temp_study_dir / "parallel_study.db"
        )
        
        assert study is not None
        assert len(study.trials) == mock_config['search']['n_trials']
    
    def test_algorithm_specific_search_spaces(self, mock_config):
        """Test algorithm-specific search spaces."""
        # Test DQN search space
        dqn_space = define_search_space('DQN', mock_config)
        assert 'learning_rate' in dqn_space
        assert 'gamma' in dqn_space
        
        # Test PPO search space (if implemented)
        ppo_config = mock_config.copy()
        ppo_config['algorithm'] = 'PPO'
        ppo_space = define_search_space('PPO', ppo_config)
        # PPO might have different parameters
        assert isinstance(ppo_space, dict)
    
    def test_custom_search_space(self, mock_config):
        """Test custom search space definition."""
        custom_space = {
            'custom_param': {
                'type': 'float',
                'low': 0.0,
                'high': 1.0
            }
        }
        
        mock_config['search_space'].update(custom_space)
        
        search_space = define_search_space('DQN', mock_config)
        assert 'custom_param' in search_space
    
    def test_search_constraints(self, mock_config, temp_study_dir):
        """Test search constraints and conditional parameters."""
        def constrained_objective(trial):
            lr = trial.suggest_float('learning_rate', 1e-5, 1e-2, log=True)
            
            # Conditional parameter based on learning rate
            if lr > 1e-3:
                decay = trial.suggest_float('lr_decay', 0.9, 0.99)
            else:
                decay = 1.0  # No decay for low learning rates
            
            return lr * 1000 + decay * 100
        
        study = run_hyperparameter_study(
            objective=constrained_objective,
            config=mock_config,
            study_name="constrained_test",
            storage_path=temp_study_dir / "constrained_study.db"
        )
        
        assert study is not None
        assert study.best_trial is not None


class TestHyperparameterSearchMock:
    """Test suite using mock hyperparameter search when real one isn't available."""
    
    def test_mock_hyperparameter_search(self, mock_config, temp_study_dir):
        """Test with mock hyperparameter search."""
        # Create mock functions
        def mock_define_search_space(algorithm, config):
            return config.get('search_space', {
                'learning_rate': {'type': 'float', 'low': 1e-5, 'high': 1e-2},
                'gamma': {'type': 'float', 'low': 0.9, 'high': 0.999}
            })
        
        def mock_validate_hyperparameters(params, algorithm):
            # Simple validation
            if 'learning_rate' in params and params['learning_rate'] <= 0:
                return False
            if 'gamma' in params and (params['gamma'] <= 0 or params['gamma'] >= 1):
                return False
            return True
        
        def mock_run_hyperparameter_study(objective, config, study_name, storage_path, **kwargs):
            class MockTrial:
                def __init__(self, params, value):
                    self.params = params
                    self.value = value
                    self.number = 0
            
            class MockStudy:
                def __init__(self):
                    self.trials = []
                    self.best_trial = None
                    self.best_value = float('-inf')
                
                def optimize(self, objective, n_trials):
                    for i in range(n_trials):
                        # Mock trial parameters
                        params = {
                            'learning_rate': 0.001 * (i + 1),
                            'gamma': 0.95 + i * 0.001
                        }
                        
                        # Mock trial object
                        class MockTrialObj:
                            def suggest_float(self, name, low, high, **kwargs):
                                return params.get(name, (low + high) / 2)
                            
                            def suggest_int(self, name, low, high, **kwargs):
                                return params.get(name, (low + high) // 2)
                            
                            def suggest_categorical(self, name, choices):
                                return params.get(name, choices[0])
                        
                        trial_obj = MockTrialObj()
                        value = objective(trial_obj)
                        
                        trial = MockTrial(params, value)
                        trial.number = i
                        self.trials.append(trial)
                        
                        if value > self.best_value:
                            self.best_value = value
                            self.best_trial = trial
            
            study = MockStudy()
            study.optimize(objective, config['search']['n_trials'])
            return study
        
        def mock_analyze_study_results(study):
            return {
                'best_params': study.best_trial.params if study.best_trial else {},
                'best_value': study.best_value,
                'n_trials': len(study.trials),
                'parameter_importance': {'learning_rate': 0.6, 'gamma': 0.4}
            }
        
        # Test search space definition
        search_space = mock_define_search_space('DQN', mock_config)
        assert 'learning_rate' in search_space
        
        # Test parameter validation
        valid_params = {'learning_rate': 0.001, 'gamma': 0.95}
        is_valid = mock_validate_hyperparameters(valid_params, 'DQN')
        assert is_valid is True
        
        invalid_params = {'learning_rate': -0.001, 'gamma': 1.5}
        is_valid = mock_validate_hyperparameters(invalid_params, 'DQN')
        assert is_valid is False
        
        # Test study execution
        def mock_objective(trial):
            lr = trial.suggest_float('learning_rate', 1e-5, 1e-2)
            gamma = trial.suggest_float('gamma', 0.9, 0.999)
            return lr * 1000 + gamma * 100
        
        study = mock_run_hyperparameter_study(
            objective=mock_objective,
            config=mock_config,
            study_name="mock_test",
            storage_path=temp_study_dir / "mock_study.db"
        )
        
        assert study is not None
        assert len(study.trials) == mock_config['search']['n_trials']
        assert study.best_trial is not None
        
        # Test results analysis
        results = mock_analyze_study_results(study)
        assert 'best_params' in results
        assert 'best_value' in results
        assert results['n_trials'] == mock_config['search']['n_trials']


@pytest.mark.integration
class TestHyperparameterSearchIntegration:
    """Integration tests for Hyperparameter Search."""
    
    @pytest.mark.skipif(not OPTUNA_AVAILABLE, reason="Optuna not available")
    def test_full_optimization_pipeline(self, mock_config, temp_study_dir):
        """Test full optimization pipeline integration."""
        # This would test with real training pipeline when available
        # For now, we'll skip if components aren't available
        pytest.skip("Full integration test requires training pipeline dependencies")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])