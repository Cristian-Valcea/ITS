#!/usr/bin/env python3
"""
Unit tests for Policy Export component.

Tests the policy export functionality including:
- TorchScript bundle export
- Model metadata generation
- Bundle validation
- Multiple export formats
- Production deployment preparation
"""

import pytest
from unittest.mock import MagicMock, patch
import tempfile
import shutil
import json
from pathlib import Path
import zipfile

# Import the module under test
try:
    from src.training.core.policy_export import (
        export_torchscript_bundle, write_model_metadata,
        validate_model_bundle, create_deployment_package
    )
except ImportError:
    # Fallback for testing without full dependencies
    export_torchscript_bundle = None
    write_model_metadata = None
    validate_model_bundle = None
    create_deployment_package = None

@pytest.fixture
def mock_config():
    """Mock configuration for policy export."""
    return {
        'algorithm': 'DQN',
        'model_version': '1.0.0',
        'training_timesteps': 10000,
        'export': {
            'format': 'torchscript',
            'optimize': True,
            'include_metadata': True
        },
        'deployment': {
            'target_platform': 'cpu',
            'max_latency_ms': 100,
            'batch_size': 1
        }
    }

@pytest.fixture
def mock_model():
    """Mock trained model for testing."""
    model = MagicMock()
    model.policy = MagicMock()
    model.policy.to_torchscript = MagicMock()
    model.get_parameters = MagicMock(return_value={'lr': 0.001})
    return model

@pytest.fixture
def temp_export_dir():
    """Create temporary directory for export testing."""
    temp_dir = Path(tempfile.mkdtemp())
    yield temp_dir
    shutil.rmtree(temp_dir, ignore_errors=True)

@pytest.mark.skipif(export_torchscript_bundle is None, reason="Policy export not available")
class TestPolicyExport:
    """Test suite for Policy Export."""
    
    def test_torchscript_export(self, mock_model, mock_config, temp_export_dir):
        """Test TorchScript bundle export."""
        export_path = temp_export_dir / "model_bundle"
        
        # Mock TorchScript model
        mock_torchscript = MagicMock()
        mock_model.policy.to_torchscript.return_value = mock_torchscript
        
        with patch('torch.jit.save') as mock_save:
            result = export_torchscript_bundle(
                model=mock_model,
                export_path=export_path,
                config=mock_config
            )
            
            assert result is True
            assert export_path.exists()
            mock_save.assert_called_once()
    
    def test_metadata_generation(self, mock_model, mock_config, temp_export_dir):
        """Test model metadata generation."""
        metadata_path = temp_export_dir / "metadata.json"
        
        success = write_model_metadata(
            export_path=temp_export_dir,
            model=mock_model,
            config=mock_config
        )
        
        assert success is True
        assert metadata_path.exists()
        
        # Verify metadata content
        with open(metadata_path, 'r') as f:
            metadata = json.load(f)
        
        assert 'algorithm' in metadata
        assert 'model_version' in metadata
        assert 'export_timestamp' in metadata
        assert 'training_config' in metadata
        assert metadata['algorithm'] == 'DQN'
    
    def test_bundle_validation(self, mock_model, mock_config, temp_export_dir):
        """Test model bundle validation."""
        # Create a complete bundle
        model_path = temp_export_dir / "model.pt"
        metadata_path = temp_export_dir / "metadata.json"
        
        # Create mock files
        model_path.touch()
        
        metadata = {
            'algorithm': 'DQN',
            'model_version': '1.0.0',
            'export_timestamp': '2024-01-01T00:00:00Z'
        }
        with open(metadata_path, 'w') as f:
            json.dump(metadata, f)
        
        # Test validation
        is_valid = validate_model_bundle(temp_export_dir)
        assert is_valid is True
        
        # Test invalid bundle - missing model file
        model_path.unlink()
        is_valid = validate_model_bundle(temp_export_dir)
        assert is_valid is False
    
    def test_deployment_package_creation(self, mock_model, mock_config, temp_export_dir):
        """Test deployment package creation."""
        package_path = temp_export_dir / "deployment_package.zip"
        
        # Create mock bundle files
        model_path = temp_export_dir / "model.pt"
        metadata_path = temp_export_dir / "metadata.json"
        requirements_path = temp_export_dir / "requirements.txt"
        
        model_path.touch()
        metadata_path.write_text('{"algorithm": "DQN"}')
        requirements_path.write_text('torch>=1.9.0\nnumpy>=1.20.0')
        
        success = create_deployment_package(
            bundle_path=temp_export_dir,
            package_path=package_path,
            config=mock_config
        )
        
        assert success is True
        assert package_path.exists()
        
        # Verify package contents
        with zipfile.ZipFile(package_path, 'r') as zf:
            files = zf.namelist()
            assert 'model.pt' in files
            assert 'metadata.json' in files
            assert 'requirements.txt' in files
    
    def test_export_optimization(self, mock_model, mock_config, temp_export_dir):
        """Test export optimization options."""
        mock_config['export']['optimize'] = True
        mock_config['export']['quantize'] = True
        
        export_path = temp_export_dir / "optimized_model"
        
        with patch('torch.jit.optimize_for_inference') as mock_optimize:
            with patch('torch.quantization.quantize_dynamic') as mock_quantize:
                result = export_torchscript_bundle(
                    model=mock_model,
                    export_path=export_path,
                    config=mock_config
                )
                
                assert result is True
                # Optimization functions should be called
                mock_optimize.assert_called()
                mock_quantize.assert_called()
    
    def test_multiple_export_formats(self, mock_model, mock_config, temp_export_dir):
        """Test multiple export formats."""
        formats = ['torchscript', 'onnx', 'tensorrt']
        
        for format_type in formats:
            mock_config['export']['format'] = format_type
            export_path = temp_export_dir / f"model_{format_type}"
            
            if format_type == 'torchscript':
                with patch('torch.jit.save'):
                    result = export_torchscript_bundle(
                        model=mock_model,
                        export_path=export_path,
                        config=mock_config
                    )
                    assert result is True
            else:
                # For other formats, we'd need specific export functions
                # For now, just test that the config is accepted
                assert mock_config['export']['format'] == format_type
    
    def test_latency_validation(self, mock_model, mock_config, temp_export_dir):
        """Test latency validation for exported models."""
        export_path = temp_export_dir / "model_bundle"
        
        # Mock TorchScript model with timing
        mock_torchscript = MagicMock()
        mock_model.policy.to_torchscript.return_value = mock_torchscript
        
        with patch('torch.jit.save'):
            with patch('time.time', side_effect=[0.0, 0.05]):  # 50ms latency
                result = export_torchscript_bundle(
                    model=mock_model,
                    export_path=export_path,
                    config=mock_config,
                    validate_latency=True
                )
                
                assert result is True  # Should pass latency requirement
    
    def test_batch_export(self, mock_config, temp_export_dir):
        """Test batch export of multiple models."""
        models = []
        for i in range(3):
            model = MagicMock()
            model.policy = MagicMock()
            model.policy.to_torchscript = MagicMock()
            models.append(model)
        
        export_paths = []
        for i, model in enumerate(models):
            export_path = temp_export_dir / f"model_{i}"
            export_paths.append(export_path)
            
            with patch('torch.jit.save'):
                result = export_torchscript_bundle(
                    model=model,
                    export_path=export_path,
                    config=mock_config
                )
                assert result is True
        
        # All models should be exported
        for path in export_paths:
            assert path.exists()
    
    def test_export_error_handling(self, mock_model, mock_config, temp_export_dir):
        """Test error handling in export process."""
        export_path = temp_export_dir / "model_bundle"
        
        # Mock export failure
        mock_model.policy.to_torchscript.side_effect = Exception("Export failed")
        
        result = export_torchscript_bundle(
            model=mock_model,
            export_path=export_path,
            config=mock_config
        )
        
        assert result is False
    
    def test_version_compatibility(self, mock_model, mock_config, temp_export_dir):
        """Test version compatibility checking."""
        metadata_path = temp_export_dir / "metadata.json"
        
        # Add version requirements to config
        mock_config['compatibility'] = {
            'min_torch_version': '1.9.0',
            'python_version': '3.8+'
        }
        
        success = write_model_metadata(
            export_path=temp_export_dir,
            model=mock_model,
            config=mock_config
        )
        
        assert success is True
        
        # Verify compatibility info in metadata
        with open(metadata_path, 'r') as f:
            metadata = json.load(f)
        
        assert 'compatibility' in metadata
        assert 'min_torch_version' in metadata['compatibility']


class TestPolicyExportMock:
    """Test suite using mock policy export when real one isn't available."""
    
    def test_mock_policy_export(self, mock_model, mock_config, temp_export_dir):
        """Test with mock policy export."""
        # Create mock functions
        def mock_export_torchscript_bundle(model, export_path, config, **kwargs):
            export_path.mkdir(exist_ok=True)
            model_file = export_path / "model.pt"
            model_file.touch()
            return True
        
        def mock_write_model_metadata(export_path, model, config):
            metadata_path = export_path / "metadata.json"
            metadata = {
                'algorithm': config['algorithm'],
                'model_version': config['model_version'],
                'export_timestamp': '2024-01-01T00:00:00Z',
                'training_config': config
            }
            with open(metadata_path, 'w') as f:
                json.dump(metadata, f)
            return True
        
        def mock_validate_model_bundle(bundle_path):
            model_file = bundle_path / "model.pt"
            metadata_file = bundle_path / "metadata.json"
            return model_file.exists() and metadata_file.exists()
        
        def mock_create_deployment_package(bundle_path, package_path, config):
            with zipfile.ZipFile(package_path, 'w') as zf:
                for file_path in bundle_path.glob('*'):
                    if file_path.is_file():
                        zf.write(file_path, file_path.name)
            return True
        
        # Test export
        export_path = temp_export_dir / "model_bundle"
        result = mock_export_torchscript_bundle(mock_model, export_path, mock_config)
        assert result is True
        assert (export_path / "model.pt").exists()
        
        # Test metadata
        success = mock_write_model_metadata(export_path, mock_model, mock_config)
        assert success is True
        assert (export_path / "metadata.json").exists()
        
        # Test validation
        is_valid = mock_validate_model_bundle(export_path)
        assert is_valid is True
        
        # Test deployment package
        package_path = temp_export_dir / "package.zip"
        success = mock_create_deployment_package(export_path, package_path, mock_config)
        assert success is True
        assert package_path.exists()
        
        # Verify package contents
        with zipfile.ZipFile(package_path, 'r') as zf:
            files = zf.namelist()
            assert 'model.pt' in files
            assert 'metadata.json' in files


@pytest.mark.integration
class TestPolicyExportIntegration:
    """Integration tests for Policy Export."""
    
    @pytest.mark.skipif(export_torchscript_bundle is None, reason="Policy export not available")
    def test_full_export_pipeline(self, mock_model, mock_config, temp_export_dir):
        """Test full export pipeline integration."""
        # This would test with real trained models when available
        # For now, we'll skip if components aren't available
        pytest.skip("Full integration test requires trained model dependencies")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])