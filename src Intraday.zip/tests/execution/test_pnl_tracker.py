#!/usr/bin/env python3
"""
Unit tests for PnLTracker core component.

Tests the P&L tracking functionality including:
- Position tracking and updates
- Realized and unrealized P&L calculation
- Risk metrics computation
- Performance analytics
- Data persistence and retrieval
"""

import pytest
from unittest.mock import MagicMock, patch
from datetime import datetime, timedelta
import pandas as pd
import numpy as np

# Import the module under test
try:
    from src.execution.core.pnl_tracker import PnLTracker, Position, Trade
except ImportError:
    # Fallback for testing without full dependencies
    PnLTracker = None
    Position = None
    Trade = None

@pytest.fixture
def mock_config():
    """Mock configuration for PnLTracker."""
    return {
        'pnl': {
            'base_currency': 'USD',
            'precision': 2,
            'update_frequency': '1s',
            'enable_analytics': True
        },
        'risk': {
            'max_drawdown_pct': 0.05,
            'var_confidence': 0.95
        },
        'storage': {
            'persist_trades': True,
            'persist_positions': True
        }
    }

@pytest.fixture
def sample_trades():
    """Sample trades for testing."""
    trades = []
    base_time = datetime.now()
    
    for i in range(5):
        if Trade is None:
            trade = {
                'id': f'TRD_{i:03d}',
                'symbol': 'AAPL',
                'side': 'BUY' if i % 2 == 0 else 'SELL',
                'quantity': 100,
                'price': 150.0 + i,
                'timestamp': base_time + timedelta(minutes=i),
                'commission': 1.0
            }
        else:
            trade = Trade(
                id=f'TRD_{i:03d}',
                symbol='AAPL',
                side='BUY' if i % 2 == 0 else 'SELL',
                quantity=100,
                price=150.0 + i,
                timestamp=base_time + timedelta(minutes=i),
                commission=1.0
            )
        trades.append(trade)
    
    return trades

@pytest.fixture
def mock_market_data():
    """Mock market data for P&L calculations."""
    return pd.DataFrame({
        'symbol': ['AAPL', 'MSFT', 'GOOGL'],
        'price': [155.0, 300.0, 2500.0],
        'timestamp': [datetime.now()] * 3
    })

@pytest.mark.skipif(PnLTracker is None, reason="PnLTracker not available")
class TestPnLTracker:
    """Test suite for PnLTracker."""
    
    def test_initialization(self, mock_config):
        """Test PnLTracker initialization."""
        tracker = PnLTracker(mock_config)
        
        assert tracker.config == mock_config
        assert tracker.base_currency == 'USD'
        assert len(tracker.positions) == 0
        assert len(tracker.trades) == 0
        assert tracker.total_realized_pnl == 0.0
    
    def test_trade_processing(self, mock_config, sample_trades):
        """Test trade processing and position updates."""
        tracker = PnLTracker(mock_config)
        
        # Process first trade (BUY)
        tracker.process_trade(sample_trades[0])
        
        assert len(tracker.trades) == 1
        assert 'AAPL' in tracker.positions
        
        position = tracker.positions['AAPL']
        if isinstance(position, dict):
            assert position['quantity'] == 100
            assert position['avg_price'] == 150.0
        else:
            assert position.quantity == 100
            assert position.avg_price == 150.0
    
    def test_position_updates(self, mock_config, sample_trades):
        """Test position updates with multiple trades."""
        tracker = PnLTracker(mock_config)
        
        # Process buy trade
        tracker.process_trade(sample_trades[0])  # BUY 100 @ 150
        
        # Process another buy trade
        tracker.process_trade(sample_trades[2])  # BUY 100 @ 152
        
        position = tracker.positions['AAPL']
        if isinstance(position, dict):
            assert position['quantity'] == 200
            assert position['avg_price'] == 151.0  # (150*100 + 152*100) / 200
        else:
            assert position.quantity == 200
            assert position.avg_price == 151.0
    
    def test_realized_pnl_calculation(self, mock_config, sample_trades):
        """Test realized P&L calculation."""
        tracker = PnLTracker(mock_config)
        
        # Process buy then sell
        tracker.process_trade(sample_trades[0])  # BUY 100 @ 150
        tracker.process_trade(sample_trades[1])  # SELL 100 @ 151
        
        # Should have realized P&L
        assert tracker.total_realized_pnl > 0
        
        # Position should be closed
        if 'AAPL' in tracker.positions:
            position = tracker.positions['AAPL']
            quantity = position['quantity'] if isinstance(position, dict) else position.quantity
            assert quantity == 0
    
    def test_unrealized_pnl_calculation(self, mock_config, sample_trades, mock_market_data):
        """Test unrealized P&L calculation."""
        tracker = PnLTracker(mock_config)
        
        # Process buy trade
        tracker.process_trade(sample_trades[0])  # BUY 100 @ 150
        
        # Update with current market prices
        tracker.update_market_prices(mock_market_data)
        
        # Calculate unrealized P&L
        unrealized_pnl = tracker.calculate_unrealized_pnl()
        
        # Should have unrealized P&L (current price 155 vs cost 150)
        expected_pnl = (155.0 - 150.0) * 100  # $500
        assert abs(unrealized_pnl - expected_pnl) < 0.01
    
    def test_total_pnl_calculation(self, mock_config, sample_trades, mock_market_data):
        """Test total P&L calculation."""
        tracker = PnLTracker(mock_config)
        
        # Process some trades
        for trade in sample_trades[:3]:
            tracker.process_trade(trade)
        
        # Update market prices
        tracker.update_market_prices(mock_market_data)
        
        # Calculate total P&L
        total_pnl = tracker.calculate_total_pnl()
        
        assert isinstance(total_pnl, float)
        assert total_pnl == tracker.total_realized_pnl + tracker.calculate_unrealized_pnl()
    
    def test_risk_metrics(self, mock_config, sample_trades, mock_market_data):
        """Test risk metrics calculation."""
        tracker = PnLTracker(mock_config)
        
        # Process trades over time
        for trade in sample_trades:
            tracker.process_trade(trade)
        
        # Update market prices
        tracker.update_market_prices(mock_market_data)
        
        # Calculate risk metrics
        metrics = tracker.calculate_risk_metrics()
        
        assert 'max_drawdown' in metrics
        assert 'var_95' in metrics
        assert 'sharpe_ratio' in metrics
        assert 'total_return' in metrics
    
    def test_performance_analytics(self, mock_config, sample_trades):
        """Test performance analytics."""
        tracker = PnLTracker(mock_config)
        
        # Process trades
        for trade in sample_trades:
            tracker.process_trade(trade)
        
        # Get performance analytics
        analytics = tracker.get_performance_analytics()
        
        assert 'total_trades' in analytics
        assert 'winning_trades' in analytics
        assert 'losing_trades' in analytics
        assert 'win_rate' in analytics
        assert 'avg_win' in analytics
        assert 'avg_loss' in analytics
        assert 'profit_factor' in analytics
    
    def test_position_sizing(self, mock_config):
        """Test position sizing calculations."""
        tracker = PnLTracker(mock_config)
        
        # Test position size calculation
        portfolio_value = 100000.0
        risk_per_trade = 0.02  # 2%
        entry_price = 150.0
        stop_loss = 145.0
        
        position_size = tracker.calculate_position_size(
            portfolio_value, risk_per_trade, entry_price, stop_loss
        )
        
        assert isinstance(position_size, int)
        assert position_size > 0
    
    def test_data_persistence(self, mock_config, sample_trades):
        """Test data persistence functionality."""
        tracker = PnLTracker(mock_config)
        
        # Process trades
        for trade in sample_trades:
            tracker.process_trade(trade)
        
        # Test save/load functionality
        with patch.object(tracker, '_save_to_storage') as mock_save:
            tracker.save_state()
            mock_save.assert_called_once()
        
        with patch.object(tracker, '_load_from_storage') as mock_load:
            tracker.load_state()
            mock_load.assert_called_once()


class TestPnLTrackerMock:
    """Test suite using mock PnLTracker when real one isn't available."""
    
    def test_mock_pnl_tracker(self, mock_config, sample_trades, mock_market_data):
        """Test with mock PnLTracker."""
        # Create a simple mock
        class MockPnLTracker:
            def __init__(self, config):
                self.config = config
                self.positions = {}
                self.trades = []
                self.total_realized_pnl = 0.0
                self.market_prices = {}
            
            def process_trade(self, trade):
                self.trades.append(trade)
                symbol = trade['symbol'] if isinstance(trade, dict) else trade.symbol
                if symbol not in self.positions:
                    self.positions[symbol] = {'quantity': 0, 'avg_price': 0.0}
                
                # Simple position update
                quantity = trade['quantity'] if isinstance(trade, dict) else trade.quantity
                price = trade['price'] if isinstance(trade, dict) else trade.price
                side = trade['side'] if isinstance(trade, dict) else trade.side
                
                if side == 'BUY':
                    self.positions[symbol]['quantity'] += quantity
                else:
                    self.positions[symbol]['quantity'] -= quantity
            
            def update_market_prices(self, market_data):
                for _, row in market_data.iterrows():
                    self.market_prices[row['symbol']] = row['price']
            
            def calculate_unrealized_pnl(self):
                pnl = 0.0
                for symbol, position in self.positions.items():
                    if symbol in self.market_prices and position['quantity'] != 0:
                        current_price = self.market_prices[symbol]
                        pnl += (current_price - position['avg_price']) * position['quantity']
                return pnl
            
            def calculate_total_pnl(self):
                return self.total_realized_pnl + self.calculate_unrealized_pnl()
            
            def get_performance_analytics(self):
                return {
                    'total_trades': len(self.trades),
                    'winning_trades': 3,
                    'losing_trades': 2,
                    'win_rate': 0.6,
                    'avg_win': 100.0,
                    'avg_loss': -50.0,
                    'profit_factor': 2.0
                }
        
        tracker = MockPnLTracker(mock_config)
        
        # Test trade processing
        tracker.process_trade(sample_trades[0])
        assert len(tracker.trades) == 1
        
        # Test market price updates
        tracker.update_market_prices(mock_market_data)
        assert 'AAPL' in tracker.market_prices
        
        # Test P&L calculations
        unrealized_pnl = tracker.calculate_unrealized_pnl()
        assert isinstance(unrealized_pnl, float)
        
        total_pnl = tracker.calculate_total_pnl()
        assert isinstance(total_pnl, float)
        
        # Test analytics
        analytics = tracker.get_performance_analytics()
        assert analytics['total_trades'] == len(tracker.trades)


@pytest.mark.integration
class TestPnLTrackerIntegration:
    """Integration tests for PnLTracker."""
    
    @pytest.mark.skipif(PnLTracker is None, reason="PnLTracker not available")
    def test_full_trading_session(self, mock_config):
        """Test a full trading session simulation."""
        tracker = PnLTracker(mock_config)
        
        # Simulate a day of trading
        base_time = datetime.now().replace(hour=9, minute=30, second=0)
        
        # Morning trades
        for i in range(10):
            if Trade is None:
                trade = {
                    'id': f'TRD_{i:03d}',
                    'symbol': 'AAPL',
                    'side': 'BUY' if i % 3 == 0 else 'SELL',
                    'quantity': 100,
                    'price': 150.0 + np.random.normal(0, 2),
                    'timestamp': base_time + timedelta(minutes=i*30),
                    'commission': 1.0
                }
            else:
                trade = Trade(
                    id=f'TRD_{i:03d}',
                    symbol='AAPL',
                    side='BUY' if i % 3 == 0 else 'SELL',
                    quantity=100,
                    price=150.0 + np.random.normal(0, 2),
                    timestamp=base_time + timedelta(minutes=i*30),
                    commission=1.0
                )
            
            tracker.process_trade(trade)
        
        # End of day analysis
        analytics = tracker.get_performance_analytics()
        assert analytics['total_trades'] == 10
        
        # Should have some realized P&L
        assert isinstance(tracker.total_realized_pnl, float)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])