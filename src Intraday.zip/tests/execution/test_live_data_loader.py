#!/usr/bin/env python3
"""
Unit tests for LiveDataLoader core component.

Tests the live data loading functionality including:
- Real-time data feed connections
- Data validation and preprocessing
- Buffering and caching strategies
- Error handling and reconnection logic
- Performance monitoring
"""

import pytest
import asyncio
from unittest.mock import MagicMock, AsyncMock, patch
from datetime import datetime, timedelta
import pandas as pd
import numpy as np

# Import the module under test
try:
    from src.execution.core.live_data_loader import LiveDataLoader, DataFeed, MarketData
except ImportError:
    # Fallback for testing without full dependencies
    LiveDataLoader = None
    DataFeed = None
    MarketData = None

@pytest.fixture
def mock_config():
    """Mock configuration for LiveDataLoader."""
    return {
        'data': {
            'provider': 'IBKR',
            'symbols': ['AAPL', 'MSFT', 'GOOGL'],
            'update_frequency': '1s',
            'buffer_size': 1000,
            'enable_caching': True
        },
        'connection': {
            'timeout_seconds': 30,
            'retry_attempts': 3,
            'heartbeat_interval': 10
        },
        'quality': {
            'max_staleness_seconds': 5,
            'min_price_change': 0.01,
            'validate_timestamps': True
        }
    }

@pytest.fixture
def mock_data_feed():
    """Mock data feed for testing."""
    feed = MagicMock()
    feed.connect = AsyncMock()
    feed.disconnect = AsyncMock()
    feed.subscribe = AsyncMock()
    feed.get_latest_data = AsyncMock()
    return feed

@pytest.fixture
def sample_market_data():
    """Sample market data for testing."""
    base_time = datetime.now()
    
    data = []
    for i, symbol in enumerate(['AAPL', 'MSFT', 'GOOGL']):
        if MarketData is None:
            market_data = {
                'symbol': symbol,
                'price': 150.0 + i * 50,
                'bid': 149.95 + i * 50,
                'ask': 150.05 + i * 50,
                'volume': 1000 + i * 100,
                'timestamp': base_time + timedelta(seconds=i)
            }
        else:
            market_data = MarketData(
                symbol=symbol,
                price=150.0 + i * 50,
                bid=149.95 + i * 50,
                ask=150.05 + i * 50,
                volume=1000 + i * 100,
                timestamp=base_time + timedelta(seconds=i)
            )
        data.append(market_data)
    
    return data

@pytest.mark.skipif(LiveDataLoader is None, reason="LiveDataLoader not available")
class TestLiveDataLoader:
    """Test suite for LiveDataLoader."""
    
    def test_initialization(self, mock_config, mock_data_feed):
        """Test LiveDataLoader initialization."""
        loader = LiveDataLoader(mock_config, mock_data_feed)
        
        assert loader.config == mock_config
        assert loader.data_feed == mock_data_feed
        assert loader.symbols == ['AAPL', 'MSFT', 'GOOGL']
        assert loader.buffer_size == 1000
        assert len(loader.data_buffer) == 0
    
    @pytest.mark.asyncio
    async def test_connection_management(self, mock_config, mock_data_feed):
        """Test connection management."""
        loader = LiveDataLoader(mock_config, mock_data_feed)
        
        # Test connect
        await loader.connect()
        mock_data_feed.connect.assert_called_once()
        assert loader.is_connected is True
        
        # Test disconnect
        await loader.disconnect()
        mock_data_feed.disconnect.assert_called_once()
        assert loader.is_connected is False
    
    @pytest.mark.asyncio
    async def test_subscription_management(self, mock_config, mock_data_feed):
        """Test symbol subscription management."""
        loader = LiveDataLoader(mock_config, mock_data_feed)
        
        await loader.connect()
        
        # Test subscribe to symbols
        await loader.subscribe_symbols(['AAPL', 'MSFT'])
        mock_data_feed.subscribe.assert_called_with(['AAPL', 'MSFT'])
        
        # Test unsubscribe
        await loader.unsubscribe_symbols(['AAPL'])
        assert 'AAPL' not in loader.subscribed_symbols
    
    def test_data_validation(self, mock_config, mock_data_feed, sample_market_data):
        """Test data validation."""
        loader = LiveDataLoader(mock_config, mock_data_feed)
        
        # Test valid data
        valid_data = sample_market_data[0]
        is_valid, error = loader.validate_data(valid_data)
        assert is_valid is True
        assert error is None
        
        # Test invalid data - stale timestamp
        stale_data = sample_market_data[0]
        if isinstance(stale_data, dict):
            stale_data['timestamp'] = datetime.now() - timedelta(seconds=10)
        else:
            stale_data.timestamp = datetime.now() - timedelta(seconds=10)
        
        is_valid, error = loader.validate_data(stale_data)
        assert is_valid is False
        assert "stale" in error.lower()
    
    def test_data_buffering(self, mock_config, mock_data_feed, sample_market_data):
        """Test data buffering functionality."""
        loader = LiveDataLoader(mock_config, mock_data_feed)
        
        # Add data to buffer
        for data in sample_market_data:
            loader.add_to_buffer(data)
        
        assert len(loader.data_buffer) == len(sample_market_data)
        
        # Test buffer overflow
        for i in range(1500):  # Exceed buffer size
            if MarketData is None:
                data = {
                    'symbol': 'TEST',
                    'price': 100.0,
                    'timestamp': datetime.now()
                }
            else:
                data = MarketData(
                    symbol='TEST',
                    price=100.0,
                    timestamp=datetime.now()
                )
            loader.add_to_buffer(data)
        
        # Buffer should be limited to buffer_size
        assert len(loader.data_buffer) <= loader.buffer_size
    
    def test_latest_data_retrieval(self, mock_config, mock_data_feed, sample_market_data):
        """Test latest data retrieval."""
        loader = LiveDataLoader(mock_config, mock_data_feed)
        
        # Add sample data
        for data in sample_market_data:
            loader.add_to_buffer(data)
        
        # Get latest data for specific symbol
        latest_aapl = loader.get_latest_data('AAPL')
        assert latest_aapl is not None
        
        symbol = latest_aapl['symbol'] if isinstance(latest_aapl, dict) else latest_aapl.symbol
        assert symbol == 'AAPL'
        
        # Get latest data for all symbols
        latest_all = loader.get_latest_data()
        assert len(latest_all) == 3
    
    def test_historical_data_retrieval(self, mock_config, mock_data_feed, sample_market_data):
        """Test historical data retrieval from buffer."""
        loader = LiveDataLoader(mock_config, mock_data_feed)
        
        # Add timestamped data
        base_time = datetime.now()
        for i, data in enumerate(sample_market_data):
            if isinstance(data, dict):
                data['timestamp'] = base_time + timedelta(seconds=i)
            else:
                data.timestamp = base_time + timedelta(seconds=i)
            loader.add_to_buffer(data)
        
        # Get data for time range
        start_time = base_time
        end_time = base_time + timedelta(seconds=2)
        
        historical_data = loader.get_historical_data('AAPL', start_time, end_time)
        assert len(historical_data) > 0
    
    @pytest.mark.asyncio
    async def test_real_time_streaming(self, mock_config, mock_data_feed, sample_market_data):
        """Test real-time data streaming."""
        loader = LiveDataLoader(mock_config, mock_data_feed)
        
        # Mock streaming data
        async def mock_stream():
            for data in sample_market_data:
                yield data
                await asyncio.sleep(0.01)
        
        mock_data_feed.stream_data = mock_stream
        
        # Start streaming
        received_data = []
        
        async def data_handler(data):
            received_data.append(data)
        
        # This would normally run continuously
        stream_task = asyncio.create_task(loader.start_streaming(data_handler))
        await asyncio.sleep(0.1)  # Let it stream some data
        stream_task.cancel()
        
        try:
            await stream_task
        except asyncio.CancelledError:
            pass
        
        assert len(received_data) > 0
    
    def test_error_handling(self, mock_config, mock_data_feed):
        """Test error handling in data loading."""
        loader = LiveDataLoader(mock_config, mock_data_feed)
        
        # Mock connection error
        mock_data_feed.connect.side_effect = Exception("Connection failed")
        
        with patch.object(loader.logger, 'error') as mock_log:
            asyncio.run(loader.connect())
            mock_log.assert_called()
            assert loader.is_connected is False
    
    def test_reconnection_logic(self, mock_config, mock_data_feed):
        """Test automatic reconnection logic."""
        loader = LiveDataLoader(mock_config, mock_data_feed)
        
        # Mock connection to fail then succeed
        mock_data_feed.connect.side_effect = [
            Exception("Connection failed"),
            Exception("Still failing"),
            None  # Success
        ]
        
        with patch.object(loader, '_should_retry', return_value=True):
            asyncio.run(loader.connect_with_retry())
            assert mock_data_feed.connect.call_count == 3
    
    def test_performance_monitoring(self, mock_config, mock_data_feed, sample_market_data):
        """Test performance monitoring."""
        loader = LiveDataLoader(mock_config, mock_data_feed)
        
        # Process some data
        for data in sample_market_data:
            loader.add_to_buffer(data)
            loader._record_data_latency(datetime.now(), datetime.now())
        
        metrics = loader.get_performance_metrics()
        
        assert 'total_messages' in metrics
        assert 'avg_latency_ms' in metrics
        assert 'buffer_utilization' in metrics
        assert 'connection_uptime' in metrics
    
    def test_data_quality_monitoring(self, mock_config, mock_data_feed, sample_market_data):
        """Test data quality monitoring."""
        loader = LiveDataLoader(mock_config, mock_data_feed)
        
        # Add good and bad data
        good_data = sample_market_data[0]
        loader.add_to_buffer(good_data)
        
        # Add stale data
        stale_data = sample_market_data[1]
        if isinstance(stale_data, dict):
            stale_data['timestamp'] = datetime.now() - timedelta(seconds=10)
        else:
            stale_data.timestamp = datetime.now() - timedelta(seconds=10)
        
        loader.add_to_buffer(stale_data)  # Should be rejected
        
        quality_metrics = loader.get_data_quality_metrics()
        
        assert 'valid_messages' in quality_metrics
        assert 'invalid_messages' in quality_metrics
        assert 'staleness_violations' in quality_metrics


class TestLiveDataLoaderMock:
    """Test suite using mock LiveDataLoader when real one isn't available."""
    
    def test_mock_live_data_loader(self, mock_config, mock_data_feed, sample_market_data):
        """Test with mock LiveDataLoader."""
        # Create a simple mock
        class MockLiveDataLoader:
            def __init__(self, config, data_feed):
                self.config = config
                self.data_feed = data_feed
                self.symbols = config['data']['symbols']
                self.data_buffer = []
                self.is_connected = False
            
            async def connect(self):
                self.is_connected = True
            
            async def disconnect(self):
                self.is_connected = False
            
            def add_to_buffer(self, data):
                self.data_buffer.append(data)
                if len(self.data_buffer) > 1000:
                    self.data_buffer.pop(0)
            
            def get_latest_data(self, symbol=None):
                if not self.data_buffer:
                    return None
                
                if symbol:
                    for data in reversed(self.data_buffer):
                        data_symbol = data['symbol'] if isinstance(data, dict) else data.symbol
                        if data_symbol == symbol:
                            return data
                    return None
                else:
                    return self.data_buffer[-3:]  # Last 3 items
            
            def validate_data(self, data):
                timestamp = data['timestamp'] if isinstance(data, dict) else data.timestamp
                if datetime.now() - timestamp > timedelta(seconds=5):
                    return False, "Data is stale"
                return True, None
            
            def get_performance_metrics(self):
                return {
                    'total_messages': len(self.data_buffer),
                    'avg_latency_ms': 2.5,
                    'buffer_utilization': len(self.data_buffer) / 1000,
                    'connection_uptime': 0.99
                }
        
        loader = MockLiveDataLoader(mock_config, mock_data_feed)
        
        # Test connection
        asyncio.run(loader.connect())
        assert loader.is_connected is True
        
        # Test data buffering
        loader.add_to_buffer(sample_market_data[0])
        assert len(loader.data_buffer) == 1
        
        # Test data retrieval
        latest = loader.get_latest_data('AAPL')
        assert latest is not None
        
        # Test validation
        is_valid, error = loader.validate_data(sample_market_data[0])
        assert is_valid is True
        
        # Test metrics
        metrics = loader.get_performance_metrics()
        assert metrics['total_messages'] == 1


@pytest.mark.integration
class TestLiveDataLoaderIntegration:
    """Integration tests for LiveDataLoader."""
    
    @pytest.mark.skipif(LiveDataLoader is None, reason="LiveDataLoader not available")
    def test_full_integration(self, mock_config):
        """Test full integration with real data feeds."""
        # This would test with real data feeds when available
        # For now, we'll skip if components aren't available
        pytest.skip("Full integration test requires real data feed connections")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])