# tests/chaos/__init__.py
"""Chaos engineering tests package."""