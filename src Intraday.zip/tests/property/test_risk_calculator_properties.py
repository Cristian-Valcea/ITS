# tests/property/test_risk_calculator_properties.py
"""
Property-Based Tests for Risk Calculators.

Tests mathematical properties and invariants that should always hold:
- Tightening thresholds should never increase allowed risk
- VaR calculations should be monotonic with confidence levels
- Stress test results should be consistent across scenarios
- Risk limits should be properly enforced under all conditions

Uses Hypothesis for property-based testing to generate thousands of test cases.
"""

import pytest
import numpy as np
import pandas as pd
from hypothesis import given, strategies as st, settings, assume, example
from hypothesis.extra.pandas import data_frames, columns
from decimal import Decimal
import math
from pathlib import Path
import sys
from typing import Dict, List, Any, Optional
import logging

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent / 'src'))

from risk.risk_calculators import (
    VaRCalculator, StressTestCalculator, PositionSizeCalculator,
    CorrelationCalculator, VolatilityCalculator, DrawdownCalculator
)
from risk.risk_sensors import RiskSensorManager
from features.technical_indicators import RSICalculator, EMACalculator, VWAPCalculator


# Hypothesis strategies for generating test data
price_strategy = st.floats(min_value=0.01, max_value=10000.0, allow_nan=False, allow_infinity=False)
quantity_strategy = st.integers(min_value=1, max_value=1000000)
confidence_strategy = st.floats(min_value=0.01, max_value=0.99, allow_nan=False)
threshold_strategy = st.floats(min_value=0.0, max_value=1.0, allow_nan=False)
volatility_strategy = st.floats(min_value=0.001, max_value=2.0, allow_nan=False)

# Market data strategy
market_data_strategy = data_frames([
    columns(['timestamp'], dtype='datetime64[ns]'),
    columns(['symbol'], dtype=str),
    columns(['price'], elements=price_strategy),
    columns(['volume'], elements=st.integers(min_value=1, max_value=1000000)),
    columns(['bid'], elements=price_strategy),
    columns(['ask'], elements=price_strategy)
], min_size=10, max_size=1000)

# Position strategy
position_strategy = st.fixed_dictionaries({
    'symbol': st.text(min_size=1, max_size=10, alphabet=st.characters(whitelist_categories=('Lu',))),
    'quantity': quantity_strategy,
    'price': price_strategy,
    'side': st.sampled_from(['BUY', 'SELL'])
})

# Portfolio strategy
portfolio_strategy = st.lists(position_strategy, min_size=1, max_size=50)


class TestVaRCalculatorProperties:
    """Property-based tests for VaR Calculator."""
    
    def setup_method(self):
        """Setup VaR calculator for testing."""
        self.var_calculator = VaRCalculator({
            'confidence_levels': [0.95, 0.99],
            'lookback_period': 252,
            'method': 'historical'
        })
    
    @given(
        returns=st.lists(
            st.floats(min_value=-0.5, max_value=0.5, allow_nan=False),
            min_size=50, max_size=1000
        ),
        confidence1=confidence_strategy,
        confidence2=confidence_strategy
    )
    @settings(max_examples=100, deadline=5000)
    def test_var_monotonicity_with_confidence(self, returns, confidence1, confidence2):
        """Test that VaR increases with confidence level (monotonicity property)."""
        assume(len(returns) >= 50)
        assume(confidence1 != confidence2)
        assume(all(not math.isnan(r) and not math.isinf(r) for r in returns))
        
        returns_array = np.array(returns)
        
        var1 = self.var_calculator.calculate_historical_var(returns_array, confidence1)
        var2 = self.var_calculator.calculate_historical_var(returns_array, confidence2)
        
        # Higher confidence should give higher (more negative) VaR
        if confidence1 > confidence2:
            assert var1 <= var2, f"VaR should increase with confidence: {var1} <= {var2}"
        else:
            assert var1 >= var2, f"VaR should increase with confidence: {var1} >= {var2}"
    
    @given(
        returns=st.lists(
            st.floats(min_value=-0.1, max_value=0.1, allow_nan=False),
            min_size=100, max_size=500
        ),
        confidence=confidence_strategy
    )
    @settings(max_examples=50, deadline=5000)
    def test_var_scale_invariance(self, returns, confidence):
        """Test that VaR scales linearly with position size."""
        assume(len(returns) >= 100)
        assume(all(not math.isnan(r) and not math.isinf(r) for r in returns))
        
        returns_array = np.array(returns)
        
        var_1x = self.var_calculator.calculate_historical_var(returns_array, confidence)
        var_2x = self.var_calculator.calculate_historical_var(returns_array * 2, confidence)
        
        # VaR should scale linearly with position size
        assert abs(var_2x - 2 * var_1x) < abs(var_1x) * 0.01, \
            f"VaR should scale linearly: {var_2x} ≈ {2 * var_1x}"
    
    @given(
        portfolio=portfolio_strategy,
        confidence=confidence_strategy
    )
    @settings(max_examples=50, deadline=10000)
    def test_var_subadditivity(self, portfolio, confidence):
        """Test that portfolio VaR ≤ sum of individual VaRs (subadditivity)."""
        assume(len(portfolio) >= 2)
        assume(all(pos['price'] > 0 and pos['quantity'] > 0 for pos in portfolio))
        
        # Calculate individual VaRs
        individual_vars = []
        for position in portfolio:
            # Generate synthetic returns for this position
            returns = np.random.normal(0, 0.02, 252)  # 2% daily volatility
            var = self.var_calculator.calculate_historical_var(returns, confidence)
            individual_vars.append(abs(var) * position['quantity'] * position['price'])
        
        # Calculate portfolio VaR (simplified)
        portfolio_returns = np.random.normal(0, 0.015, 252)  # Diversified portfolio
        portfolio_var = self.var_calculator.calculate_historical_var(portfolio_returns, confidence)
        portfolio_value = sum(pos['quantity'] * pos['price'] for pos in portfolio)
        portfolio_var_absolute = abs(portfolio_var) * portfolio_value
        
        # Portfolio VaR should be less than or equal to sum of individual VaRs
        sum_individual_vars = sum(individual_vars)
        assert portfolio_var_absolute <= sum_individual_vars * 1.1, \
            f"Portfolio VaR should be subadditive: {portfolio_var_absolute} <= {sum_individual_vars}"
    
    @given(
        base_returns=st.lists(
            st.floats(min_value=-0.1, max_value=0.1, allow_nan=False),
            min_size=100, max_size=300
        ),
        threshold_old=threshold_strategy,
        threshold_new=threshold_strategy
    )
    @settings(max_examples=100, deadline=5000)
    def test_tightening_threshold_reduces_allowed_risk(self, base_returns, threshold_old, threshold_new):
        """Test that tightening thresholds never increases allowed risk."""
        assume(len(base_returns) >= 100)
        assume(threshold_new < threshold_old)  # Tightening threshold
        assume(all(not math.isnan(r) and not math.isinf(r) for r in base_returns))
        
        returns_array = np.array(base_returns)
        
        # Calculate allowed risk with old threshold
        var_old = self.var_calculator.calculate_historical_var(returns_array, 1 - threshold_old)
        allowed_risk_old = abs(var_old)
        
        # Calculate allowed risk with new (tighter) threshold
        var_new = self.var_calculator.calculate_historical_var(returns_array, 1 - threshold_new)
        allowed_risk_new = abs(var_new)
        
        # Tightening threshold should reduce allowed risk
        assert allowed_risk_new <= allowed_risk_old * 1.01, \
            f"Tightening threshold should reduce allowed risk: {allowed_risk_new} <= {allowed_risk_old}"


class TestStressTestCalculatorProperties:
    """Property-based tests for Stress Test Calculator."""
    
    def setup_method(self):
        """Setup stress test calculator."""
        self.stress_calculator = StressTestCalculator({
            'scenarios': {
                'market_crash': {'equity_shock': -0.3, 'volatility_shock': 2.0},
                'interest_rate_shock': {'rate_shock': 0.02, 'duration_shock': 1.5},
                'liquidity_crisis': {'spread_shock': 0.005, 'volume_shock': -0.5}
            }
        })
    
    @given(
        portfolio=portfolio_strategy,
        shock_magnitude=st.floats(min_value=0.1, max_value=2.0, allow_nan=False)
    )
    @settings(max_examples=50, deadline=10000)
    def test_stress_test_monotonicity(self, portfolio, shock_magnitude):
        """Test that larger shocks produce larger losses."""
        assume(len(portfolio) >= 1)
        assume(all(pos['price'] > 0 and pos['quantity'] > 0 for pos in portfolio))
        
        # Create two scenarios with different shock magnitudes
        scenario_small = {'equity_shock': -shock_magnitude * 0.5}
        scenario_large = {'equity_shock': -shock_magnitude}
        
        loss_small = self.stress_calculator.calculate_scenario_loss(portfolio, scenario_small)
        loss_large = self.stress_calculator.calculate_scenario_loss(portfolio, scenario_large)
        
        # Larger shock should produce larger loss
        assert loss_large >= loss_small, \
            f"Larger shock should produce larger loss: {loss_large} >= {loss_small}"
    
    @given(
        portfolio=portfolio_strategy,
        shock=st.floats(min_value=-0.5, max_value=-0.01, allow_nan=False)
    )
    @settings(max_examples=50, deadline=10000)
    def test_stress_test_linearity(self, portfolio, shock):
        """Test approximate linearity of stress test results."""
        assume(len(portfolio) >= 1)
        assume(all(pos['price'] > 0 and pos['quantity'] > 0 for pos in portfolio))
        
        scenario_1x = {'equity_shock': shock}
        scenario_2x = {'equity_shock': shock * 2}
        
        loss_1x = self.stress_calculator.calculate_scenario_loss(portfolio, scenario_1x)
        loss_2x = self.stress_calculator.calculate_scenario_loss(portfolio, scenario_2x)
        
        # For small shocks, losses should be approximately linear
        if abs(shock) < 0.1:
            expected_loss_2x = loss_1x * 2
            tolerance = abs(loss_1x) * 0.2  # 20% tolerance
            assert abs(loss_2x - expected_loss_2x) <= tolerance, \
                f"Stress test should be approximately linear: {loss_2x} ≈ {expected_loss_2x}"
    
    @given(
        portfolio=portfolio_strategy
    )
    @settings(max_examples=30, deadline=10000)
    def test_stress_test_worst_case_property(self, portfolio):
        """Test that worst-case scenario is indeed the worst."""
        assume(len(portfolio) >= 1)
        assume(all(pos['price'] > 0 and pos['quantity'] > 0 for pos in portfolio))
        
        scenarios = {
            'mild': {'equity_shock': -0.05},
            'moderate': {'equity_shock': -0.15},
            'severe': {'equity_shock': -0.30}
        }
        
        losses = {}
        for name, scenario in scenarios.items():
            losses[name] = self.stress_calculator.calculate_scenario_loss(portfolio, scenario)
        
        # Worst case should be the maximum loss
        worst_case_loss = max(losses.values())
        assert losses['severe'] == worst_case_loss, \
            f"Severe scenario should be worst case: {losses['severe']} == {worst_case_loss}"


class TestPositionSizeCalculatorProperties:
    """Property-based tests for Position Size Calculator."""
    
    def setup_method(self):
        """Setup position size calculator."""
        self.position_calculator = PositionSizeCalculator({
            'max_position_pct': 0.1,  # 10% max position size
            'risk_per_trade': 0.02,   # 2% risk per trade
            'kelly_fraction': 0.25    # 25% of Kelly criterion
        })
    
    @given(
        account_value=st.floats(min_value=10000, max_value=10000000, allow_nan=False),
        price=price_strategy,
        volatility=volatility_strategy,
        max_risk_pct=st.floats(min_value=0.001, max_value=0.1, allow_nan=False)
    )
    @settings(max_examples=100, deadline=5000)
    def test_position_size_risk_constraint(self, account_value, price, volatility, max_risk_pct):
        """Test that position size respects risk constraints."""
        assume(account_value > 0 and price > 0 and volatility > 0)
        
        position_size = self.position_calculator.calculate_position_size(
            account_value=account_value,
            price=price,
            volatility=volatility,
            max_risk_pct=max_risk_pct
        )
        
        # Position value should not exceed risk constraint
        position_value = position_size * price
        max_position_value = account_value * max_risk_pct
        
        assert position_value <= max_position_value * 1.01, \
            f"Position size should respect risk constraint: {position_value} <= {max_position_value}"
    
    @given(
        account_value=st.floats(min_value=10000, max_value=1000000, allow_nan=False),
        price=price_strategy,
        volatility1=volatility_strategy,
        volatility2=volatility_strategy
    )
    @settings(max_examples=100, deadline=5000)
    def test_position_size_volatility_inverse_relationship(self, account_value, price, volatility1, volatility2):
        """Test that position size is inversely related to volatility."""
        assume(account_value > 0 and price > 0)
        assume(volatility1 > 0 and volatility2 > 0)
        assume(volatility1 != volatility2)
        
        position1 = self.position_calculator.calculate_position_size(
            account_value=account_value,
            price=price,
            volatility=volatility1
        )
        
        position2 = self.position_calculator.calculate_position_size(
            account_value=account_value,
            price=price,
            volatility=volatility2
        )
        
        # Higher volatility should result in smaller position size
        if volatility1 > volatility2:
            assert position1 <= position2, \
                f"Higher volatility should give smaller position: {position1} <= {position2}"
        else:
            assert position1 >= position2, \
                f"Lower volatility should give larger position: {position1} >= {position2}"
    
    @given(
        account_value1=st.floats(min_value=10000, max_value=500000, allow_nan=False),
        account_value2=st.floats(min_value=10000, max_value=500000, allow_nan=False),
        price=price_strategy,
        volatility=volatility_strategy
    )
    @settings(max_examples=100, deadline=5000)
    def test_position_size_account_value_scaling(self, account_value1, account_value2, price, volatility):
        """Test that position size scales with account value."""
        assume(account_value1 > 0 and account_value2 > 0)
        assume(price > 0 and volatility > 0)
        assume(account_value1 != account_value2)
        
        position1 = self.position_calculator.calculate_position_size(
            account_value=account_value1,
            price=price,
            volatility=volatility
        )
        
        position2 = self.position_calculator.calculate_position_size(
            account_value=account_value2,
            price=price,
            volatility=volatility
        )
        
        # Position size should scale approximately with account value
        ratio_accounts = account_value2 / account_value1
        ratio_positions = position2 / position1 if position1 > 0 else float('inf')
        
        if position1 > 0 and position2 > 0:
            assert abs(ratio_positions - ratio_accounts) / ratio_accounts < 0.1, \
                f"Position size should scale with account value: {ratio_positions} ≈ {ratio_accounts}"


class TestVolatilityCalculatorProperties:
    """Property-based tests for Volatility Calculator."""
    
    def setup_method(self):
        """Setup volatility calculator."""
        self.volatility_calculator = VolatilityCalculator({
            'method': 'ewma',
            'lambda': 0.94,
            'min_periods': 20
        })
    
    @given(
        prices=st.lists(
            price_strategy,
            min_size=50, max_size=500
        ),
        window1=st.integers(min_value=10, max_value=50),
        window2=st.integers(min_value=10, max_value=50)
    )
    @settings(max_examples=50, deadline=10000)
    def test_volatility_window_size_effect(self, prices, window1, window2):
        """Test effect of window size on volatility calculation."""
        assume(len(prices) >= max(window1, window2) + 10)
        assume(all(p > 0 for p in prices))
        assume(window1 != window2)
        
        price_series = pd.Series(prices)
        
        vol1 = self.volatility_calculator.calculate_rolling_volatility(price_series, window1)
        vol2 = self.volatility_calculator.calculate_rolling_volatility(price_series, window2)
        
        # Both volatilities should be positive
        assert all(v >= 0 for v in vol1.dropna()), "Volatility should be non-negative"
        assert all(v >= 0 for v in vol2.dropna()), "Volatility should be non-negative"
        
        # Longer window should generally produce smoother (less extreme) volatility
        if len(vol1.dropna()) > 0 and len(vol2.dropna()) > 0:
            vol1_std = vol1.dropna().std()
            vol2_std = vol2.dropna().std()
            
            if window1 > window2:
                assert vol1_std <= vol2_std * 1.5, \
                    f"Longer window should produce smoother volatility: {vol1_std} <= {vol2_std}"
    
    @given(
        returns=st.lists(
            st.floats(min_value=-0.1, max_value=0.1, allow_nan=False),
            min_size=100, max_size=300
        ),
        scale_factor=st.floats(min_value=0.5, max_value=2.0, allow_nan=False)
    )
    @settings(max_examples=50, deadline=5000)
    def test_volatility_scale_invariance(self, returns, scale_factor):
        """Test that volatility scales with return magnitude."""
        assume(len(returns) >= 100)
        assume(all(not math.isnan(r) and not math.isinf(r) for r in returns))
        assume(scale_factor > 0)
        
        returns_array = np.array(returns)
        scaled_returns = returns_array * scale_factor
        
        vol_original = np.std(returns_array)
        vol_scaled = np.std(scaled_returns)
        
        # Volatility should scale linearly with return magnitude
        expected_vol_scaled = vol_original * scale_factor
        assert abs(vol_scaled - expected_vol_scaled) < vol_original * 0.01, \
            f"Volatility should scale linearly: {vol_scaled} ≈ {expected_vol_scaled}"


class TestCorrelationCalculatorProperties:
    """Property-based tests for Correlation Calculator."""
    
    def setup_method(self):
        """Setup correlation calculator."""
        self.correlation_calculator = CorrelationCalculator({
            'method': 'pearson',
            'min_periods': 30
        })
    
    @given(
        returns1=st.lists(
            st.floats(min_value=-0.1, max_value=0.1, allow_nan=False),
            min_size=50, max_size=200
        ),
        returns2=st.lists(
            st.floats(min_value=-0.1, max_value=0.1, allow_nan=False),
            min_size=50, max_size=200
        )
    )
    @settings(max_examples=50, deadline=5000)
    def test_correlation_bounds(self, returns1, returns2):
        """Test that correlation is bounded between -1 and 1."""
        assume(len(returns1) == len(returns2))
        assume(len(returns1) >= 50)
        assume(all(not math.isnan(r) and not math.isinf(r) for r in returns1))
        assume(all(not math.isnan(r) and not math.isinf(r) for r in returns2))
        
        series1 = pd.Series(returns1)
        series2 = pd.Series(returns2)
        
        correlation = self.correlation_calculator.calculate_correlation(series1, series2)
        
        # Correlation should be bounded
        assert -1 <= correlation <= 1, f"Correlation should be bounded: -1 <= {correlation} <= 1"
    
    @given(
        returns=st.lists(
            st.floats(min_value=-0.1, max_value=0.1, allow_nan=False),
            min_size=50, max_size=200
        )
    )
    @settings(max_examples=50, deadline=5000)
    def test_correlation_self_identity(self, returns):
        """Test that correlation of series with itself is 1."""
        assume(len(returns) >= 50)
        assume(all(not math.isnan(r) and not math.isinf(r) for r in returns))
        assume(np.std(returns) > 1e-10)  # Non-constant series
        
        series = pd.Series(returns)
        correlation = self.correlation_calculator.calculate_correlation(series, series)
        
        # Self-correlation should be 1
        assert abs(correlation - 1.0) < 1e-10, f"Self-correlation should be 1: {correlation}"
    
    @given(
        returns1=st.lists(
            st.floats(min_value=-0.1, max_value=0.1, allow_nan=False),
            min_size=50, max_size=200
        ),
        returns2=st.lists(
            st.floats(min_value=-0.1, max_value=0.1, allow_nan=False),
            min_size=50, max_size=200
        )
    )
    @settings(max_examples=50, deadline=5000)
    def test_correlation_symmetry(self, returns1, returns2):
        """Test that correlation is symmetric."""
        assume(len(returns1) == len(returns2))
        assume(len(returns1) >= 50)
        assume(all(not math.isnan(r) and not math.isinf(r) for r in returns1))
        assume(all(not math.isnan(r) and not math.isinf(r) for r in returns2))
        
        series1 = pd.Series(returns1)
        series2 = pd.Series(returns2)
        
        corr_12 = self.correlation_calculator.calculate_correlation(series1, series2)
        corr_21 = self.correlation_calculator.calculate_correlation(series2, series1)
        
        # Correlation should be symmetric
        assert abs(corr_12 - corr_21) < 1e-10, f"Correlation should be symmetric: {corr_12} == {corr_21}"


class TestRiskLimitProperties:
    """Property-based tests for risk limit enforcement."""
    
    @given(
        position_size=st.floats(min_value=1, max_value=1000000, allow_nan=False),
        price=price_strategy,
        limit_old=st.floats(min_value=10000, max_value=1000000, allow_nan=False),
        limit_new=st.floats(min_value=10000, max_value=1000000, allow_nan=False)
    )
    @settings(max_examples=100, deadline=5000)
    def test_tightening_limits_reduce_allowed_positions(self, position_size, price, limit_old, limit_new):
        """Test that tightening limits never allows larger positions."""
        assume(position_size > 0 and price > 0)
        assume(limit_new < limit_old)  # Tightening limit
        
        position_value = position_size * price
        
        # Check if position is allowed under old limit
        allowed_old = position_value <= limit_old
        
        # Check if position is allowed under new (tighter) limit
        allowed_new = position_value <= limit_new
        
        # If position was rejected under old limit, it should be rejected under new limit
        # If position was allowed under new limit, it should be allowed under old limit
        if not allowed_old:
            assert not allowed_new, "Tightening limits should not allow previously rejected positions"
        
        if allowed_new:
            assert allowed_old, "Tightening limits should not reject previously allowed positions"
    
    @given(
        var_estimate=st.floats(min_value=1000, max_value=100000, allow_nan=False),
        confidence1=confidence_strategy,
        confidence2=confidence_strategy,
        limit=st.floats(min_value=50000, max_value=500000, allow_nan=False)
    )
    @settings(max_examples=100, deadline=5000)
    def test_var_limit_consistency(self, var_estimate, confidence1, confidence2, limit):
        """Test VaR limit consistency across confidence levels."""
        assume(confidence1 != confidence2)
        assume(var_estimate > 0 and limit > 0)
        
        # Adjust VaR estimate for different confidence levels
        # Higher confidence should give higher VaR (more conservative)
        if confidence1 > confidence2:
            var1 = var_estimate
            var2 = var_estimate * 0.8  # Lower confidence = lower VaR
        else:
            var1 = var_estimate * 0.8
            var2 = var_estimate
        
        # Check limit compliance
        compliant1 = var1 <= limit
        compliant2 = var2 <= limit
        
        # If higher confidence VaR is compliant, lower confidence should also be compliant
        if confidence1 > confidence2 and compliant1:
            assert compliant2, "Lower confidence VaR should be compliant if higher confidence is"
        elif confidence2 > confidence1 and compliant2:
            assert compliant1, "Lower confidence VaR should be compliant if higher confidence is"


class TestTechnicalIndicatorProperties:
    """Property-based tests for technical indicators used in risk calculations."""
    
    def setup_method(self):
        """Setup technical indicators."""
        self.rsi_calculator = RSICalculator({'period': 14})
        self.ema_calculator = EMACalculator({'period': 20})
        self.vwap_calculator = VWAPCalculator({})
    
    @given(
        prices=st.lists(
            price_strategy,
            min_size=50, max_size=300
        )
    )
    @settings(max_examples=50, deadline=5000)
    def test_rsi_bounds(self, prices):
        """Test that RSI is bounded between 0 and 100."""
        assume(len(prices) >= 50)
        assume(all(p > 0 for p in prices))
        assume(len(set(prices)) > 1)  # Not all prices the same
        
        price_series = pd.Series(prices)
        rsi_values = self.rsi_calculator.calculate(price_series)
        
        # RSI should be bounded between 0 and 100
        valid_rsi = rsi_values.dropna()
        if len(valid_rsi) > 0:
            assert all(0 <= rsi <= 100 for rsi in valid_rsi), \
                f"RSI should be bounded: 0 <= RSI <= 100"
    
    @given(
        prices=st.lists(
            price_strategy,
            min_size=50, max_size=300
        )
    )
    @settings(max_examples=50, deadline=5000)
    def test_ema_trend_following(self, prices):
        """Test that EMA follows price trends."""
        assume(len(prices) >= 50)
        assume(all(p > 0 for p in prices))
        
        price_series = pd.Series(prices)
        ema_values = self.ema_calculator.calculate(price_series)
        
        # EMA should be smoother than price series
        if len(ema_values.dropna()) > 10:
            price_volatility = price_series.pct_change().std()
            ema_volatility = ema_values.pct_change().std()
            
            # EMA should be less volatile than prices
            assert ema_volatility <= price_volatility * 1.1, \
                f"EMA should be smoother than prices: {ema_volatility} <= {price_volatility}"
    
    @given(
        market_data=market_data_strategy
    )
    @settings(max_examples=30, deadline=10000)
    def test_vwap_volume_weighting(self, market_data):
        """Test that VWAP properly weights by volume."""
        assume(len(market_data) >= 20)
        assume(all(market_data['price'] > 0))
        assume(all(market_data['volume'] > 0))
        
        vwap_values = self.vwap_calculator.calculate(market_data)
        
        if len(vwap_values.dropna()) > 0:
            # VWAP should be within reasonable range of prices
            min_price = market_data['price'].min()
            max_price = market_data['price'].max()
            
            valid_vwap = vwap_values.dropna()
            assert all(min_price * 0.9 <= vwap <= max_price * 1.1 for vwap in valid_vwap), \
                f"VWAP should be within price range: {min_price} <= VWAP <= {max_price}"


if __name__ == "__main__":
    # Run property-based tests
    pytest.main([
        __file__,
        "-v",
        "--tb=short",
        "-x"  # Stop on first failure for debugging
    ])