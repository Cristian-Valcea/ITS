# tests/property/__init__.py
"""Property-based tests package."""