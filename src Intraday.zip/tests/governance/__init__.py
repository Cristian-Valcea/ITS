# tests/governance/__init__.py
"""Governance and compliance tests package."""