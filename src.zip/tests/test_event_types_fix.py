#!/usr/bin/env python3
"""
Test to verify that the duplicate EventType/EventPriority/RiskEvent issue is resolved.

This test ensures that:
1. Only one definition of each class exists
2. isinstance() checks work across modules
3. Equality checks work across modules
4. All imports resolve to the same class objects
"""

import sys
import os

# Add project root to path
sys.path.insert(0, os.path.dirname(__file__))

def test_single_class_definitions():
    """Test that we only have one definition of each class."""
    print("🧪 Testing Single Class Definitions")
    print("-" * 50)
    
    # Import from different modules
    from src.risk.event_types import EventType as ET1, EventPriority as EP1, RiskEvent as RE1
    from src.risk.event_bus import EventType as ET2, EventPriority as EP2, RiskEvent as RE2
    from src.risk import EventType as ET3, EventPriority as EP3, RiskEvent as RE3
    from src.risk.risk_agent_v2 import EventType as ET4, EventPriority as EP4, RiskEvent as RE4
    
    # Test that all imports resolve to the same class objects
    print(f"EventType identity checks:")
    print(f"  event_types.EventType is event_bus.EventType: {ET1 is ET2}")
    print(f"  event_types.EventType is risk.__init__.EventType: {ET1 is ET3}")
    print(f"  event_types.EventType is risk_agent_v2.EventType: {ET1 is ET4}")
    
    print(f"EventPriority identity checks:")
    print(f"  event_types.EventPriority is event_bus.EventPriority: {EP1 is EP2}")
    print(f"  event_types.EventPriority is risk.__init__.EventPriority: {EP1 is EP3}")
    print(f"  event_types.EventPriority is risk_agent_v2.EventPriority: {EP1 is EP4}")
    
    print(f"RiskEvent identity checks:")
    print(f"  event_types.RiskEvent is event_bus.RiskEvent: {RE1 is RE2}")
    print(f"  event_types.RiskEvent is risk.__init__.RiskEvent: {RE1 is RE3}")
    print(f"  event_types.RiskEvent is risk_agent_v2.RiskEvent: {RE1 is RE4}")
    
    # All should be True
    all_same = all([
        ET1 is ET2, ET1 is ET3, ET1 is ET4,
        EP1 is EP2, EP1 is EP3, EP1 is EP4,
        RE1 is RE2, RE1 is RE3, RE1 is RE4
    ])
    
    print(f"\n✅ All class identities match: {all_same}")
    return all_same


def test_isinstance_checks():
    """Test that isinstance checks work across modules."""
    print("\n🧪 Testing isinstance() Checks")
    print("-" * 50)
    
    from src.risk.event_types import EventType, EventPriority, RiskEvent
    
    # Create instances
    event_type = EventType.MARKET_DATA
    priority = EventPriority.HIGH
    event = RiskEvent(event_type=event_type, priority=priority)
    
    # Test isinstance from different import paths
    from src.risk.event_bus import EventType as ET_Bus, EventPriority as EP_Bus, RiskEvent as RE_Bus
    from src.risk import EventType as ET_Risk, EventPriority as EP_Risk, RiskEvent as RE_Risk
    
    print(f"isinstance(event_type, ET_Bus): {isinstance(event_type, ET_Bus)}")
    print(f"isinstance(event_type, ET_Risk): {isinstance(event_type, ET_Risk)}")
    print(f"isinstance(priority, EP_Bus): {isinstance(priority, EP_Bus)}")
    print(f"isinstance(priority, EP_Risk): {isinstance(priority, EP_Risk)}")
    print(f"isinstance(event, RE_Bus): {isinstance(event, RE_Bus)}")
    print(f"isinstance(event, RE_Risk): {isinstance(event, RE_Risk)}")
    
    all_isinstance_work = all([
        isinstance(event_type, ET_Bus),
        isinstance(event_type, ET_Risk),
        isinstance(priority, EP_Bus),
        isinstance(priority, EP_Risk),
        isinstance(event, RE_Bus),
        isinstance(event, RE_Risk)
    ])
    
    print(f"\n✅ All isinstance checks pass: {all_isinstance_work}")
    return all_isinstance_work


def test_equality_checks():
    """Test that equality checks work across modules."""
    print("\n🧪 Testing Equality Checks")
    print("-" * 50)
    
    from src.risk.event_types import EventType, EventPriority, RiskEvent
    
    # Create instances from different import paths
    from src.risk.event_bus import EventType as ET_Bus, EventPriority as EP_Bus
    from src.risk import EventType as ET_Risk, EventPriority as EP_Risk
    
    # Test enum equality
    et1 = EventType.MARKET_DATA
    et2 = ET_Bus.MARKET_DATA
    et3 = ET_Risk.MARKET_DATA
    
    ep1 = EventPriority.HIGH
    ep2 = EP_Bus.HIGH
    ep3 = EP_Risk.HIGH
    
    print(f"EventType.MARKET_DATA equality:")
    print(f"  event_types == event_bus: {et1 == et2}")
    print(f"  event_types == risk.__init__: {et1 == et3}")
    print(f"  event_bus == risk.__init__: {et2 == et3}")
    
    print(f"EventPriority.HIGH equality:")
    print(f"  event_types == event_bus: {ep1 == ep2}")
    print(f"  event_types == risk.__init__: {ep1 == ep3}")
    print(f"  event_bus == risk.__init__: {ep2 == ep3}")
    
    all_equality_work = all([
        et1 == et2, et1 == et3, et2 == et3,
        ep1 == ep2, ep1 == ep3, ep2 == ep3
    ])
    
    print(f"\n✅ All equality checks pass: {all_equality_work}")
    return all_equality_work


def test_event_creation_and_processing():
    """Test that events can be created and processed across modules."""
    print("\n🧪 Testing Event Creation and Processing")
    print("-" * 50)
    
    from src.risk.event_types import EventType, EventPriority, RiskEvent
    
    # Create event
    event = RiskEvent(
        event_type=EventType.RISK_CALCULATION,
        priority=EventPriority.CRITICAL,
        source="test_sensor",
        data={"value": 42}
    )
    
    print(f"Created event: {event.event_id}")
    print(f"Event type: {event.event_type}")
    print(f"Priority: {event.priority}")
    print(f"Source: {event.source}")
    
    # Test processing methods
    event.start_processing()
    import time
    time.sleep(0.001)  # 1ms
    event.end_processing()
    
    latency = event.get_processing_latency_us()
    total_latency = event.get_total_latency_us()
    
    print(f"Processing latency: {latency:.2f}µs")
    print(f"Total latency: {total_latency:.2f}µs")
    
    # Test that event can be used with different imports
    from src.risk.event_bus import RiskEvent as RE_Bus
    from src.risk import RiskEvent as RE_Risk
    
    is_bus_event = isinstance(event, RE_Bus)
    is_risk_event = isinstance(event, RE_Risk)
    
    print(f"Event isinstance(RE_Bus): {is_bus_event}")
    print(f"Event isinstance(RE_Risk): {is_risk_event}")
    
    processing_works = all([
        latency is not None,
        latency > 0,
        total_latency > 0,
        is_bus_event,
        is_risk_event
    ])
    
    print(f"\n✅ Event processing works: {processing_works}")
    return processing_works


def main():
    """Run all tests to verify the duplicate class issue is resolved."""
    print("🚀 EVENT TYPES DUPLICATE CLASS FIX VALIDATION")
    print("=" * 70)
    
    tests = [
        ("Single Class Definitions", test_single_class_definitions),
        ("isinstance() Checks", test_isinstance_checks),
        ("Equality Checks", test_equality_checks),
        ("Event Creation and Processing", test_event_creation_and_processing)
    ]
    
    passed = 0
    failed = 0
    
    for test_name, test_func in tests:
        try:
            result = test_func()
            if result:
                print(f"✅ {test_name}: PASSED")
                passed += 1
            else:
                print(f"❌ {test_name}: FAILED")
                failed += 1
        except Exception as e:
            print(f"❌ {test_name}: FAILED with exception: {e}")
            import traceback
            traceback.print_exc()
            failed += 1
    
    print(f"\n{'='*70}")
    print(f"📊 TEST SUMMARY")
    print(f"{'='*70}")
    print(f"✅ Passed: {passed}")
    print(f"❌ Failed: {failed}")
    print(f"📈 Total:  {passed + failed}")
    
    if failed == 0:
        print(f"\n🎉 ALL TESTS PASSED!")
        print("✅ Duplicate class issue has been resolved!")
        print("✅ All imports now resolve to the same class objects")
        print("✅ isinstance() and equality checks work across modules")
        print("✅ Event creation and processing work correctly")
        return True
    else:
        print(f"\n❌ Some tests failed. The duplicate class issue may not be fully resolved.")
        return False


if __name__ == "__main__":
    success = main()
    if not success:
        sys.exit(1)