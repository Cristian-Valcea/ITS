# tests/governance/test_governance_integration.py
"""
Integration tests for governance and compliance system.

Tests the complete governance workflow including:
- Immutable audit trails
- Model lineage tracking with dataset hashing
- Four-eyes release approval process
"""

import pytest
import asyncio
import json
import tempfile
import pandas as pd
import numpy as np
from datetime import datetime, timezone, timedelta
from pathlib import Path
import hashlib
import sys
import os

# Add src to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent.parent / 'src'))

from governance.audit_immutable import ImmutableAuditSink, EnhancedAuditSink
from governance.model_lineage import ModelLineageTracker, DatasetHasher
from governance.release_approval import FourEyesReleaseGate, ApprovalWorkflow, ApprovalType, ApprovalStatus


@pytest.fixture
def temp_storage():
    """Create temporary storage for tests."""
    with tempfile.TemporaryDirectory() as temp_dir:
        yield Path(temp_dir)


@pytest.fixture
def sample_dataset():
    """Create sample dataset for testing."""
    np.random.seed(42)
    data = {
        'timestamp': pd.date_range('2024-01-01', periods=1000, freq='1min'),
        'price': 100 + np.cumsum(np.random.randn(1000) * 0.1),
        'volume': np.random.randint(100, 1000, 1000),
        'returns': np.random.randn(1000) * 0.02
    }
    return pd.DataFrame(data)


@pytest.fixture
def governance_config(temp_storage):
    """Create governance configuration for testing."""
    return {
        'immutable_config': {
            's3_worm_enabled': False,
            'kafka_enabled': False,
            'local_worm_path': str(temp_storage / 'audit_worm')
        },
        'lineage_storage_path': str(temp_storage / 'model_lineage'),
        'approval_storage_path': str(temp_storage / 'approvals'),
        'github_enabled': False,
        'servicenow_enabled': False,
        'approval_groups': {
            'senior_developers': ['dev1', 'dev2'],
            'risk_managers': ['risk1', 'risk2']
        },
        'approval_policies': {
            'MODEL_DEPLOYMENT': {
                'minimum_approvals': 2,
                'required_approvers': [],
                'approval_groups': ['senior_developers', 'risk_managers'],
                'expires_hours': 24
            }
        }
    }


class TestImmutableAuditTrail:
    """Test immutable audit trail functionality."""
    
    @pytest.mark.asyncio
    async def test_audit_record_creation(self, governance_config):
        """Test creation of immutable audit records."""
        audit_sink = ImmutableAuditSink(governance_config['immutable_config'])
        
        # Write audit record
        record_hash = await audit_sink.write_audit_record(
            event_type="RISK_DECISION",
            component="RiskAgent",
            user_id="trader1",
            session_id="session123",
            action="BLOCK_TRADE",
            details={
                'symbol': 'AAPL',
                'quantity': 100,
                'reason': 'VaR limit exceeded'
            },
            risk_impact="HIGH",
            compliance_tags=['RISK_MANAGEMENT', 'TRADING_DECISION']
        )
        
        assert record_hash is not None
        assert len(record_hash) == 64  # SHA-256 hash length
    
    @pytest.mark.asyncio
    async def test_audit_chain_integrity(self, governance_config):
        """Test audit chain integrity verification."""
        audit_sink = ImmutableAuditSink(governance_config['immutable_config'])
        
        # Write multiple audit records
        for i in range(5):
            await audit_sink.write_audit_record(
                event_type="TEST_EVENT",
                component="TestComponent",
                user_id=f"user{i}",
                session_id=f"session{i}",
                action=f"ACTION_{i}",
                details={'test_data': i},
                risk_impact="LOW"
            )
        
        # Verify chain integrity
        is_valid = await audit_sink.verify_audit_chain(0, 4)
        assert is_valid is True
    
    @pytest.mark.asyncio
    async def test_compliance_report_generation(self, governance_config):
        """Test compliance report generation."""
        audit_sink = ImmutableAuditSink(governance_config['immutable_config'])
        
        # Write audit records with different compliance tags
        await audit_sink.write_audit_record(
            event_type="RISK_DECISION",
            component="RiskAgent",
            user_id="trader1",
            session_id="session1",
            action="ALLOW_TRADE",
            details={'symbol': 'AAPL'},
            compliance_tags=['RISK_MANAGEMENT']
        )
        
        await audit_sink.write_audit_record(
            event_type="MODEL_DEPLOYMENT",
            component="ModelDeployment",
            user_id="dev1",
            session_id="session2",
            action="DEPLOY_MODEL",
            details={'model_id': 'model123'},
            compliance_tags=['MODEL_GOVERNANCE']
        )
        
        # Generate compliance report
        start_date = datetime.now(timezone.utc) - timedelta(hours=1)
        end_date = datetime.now(timezone.utc) + timedelta(hours=1)
        
        report = await audit_sink.generate_compliance_report(
            start_date, end_date, ['RISK_MANAGEMENT']
        )
        
        assert report['total_records'] == 1
        assert 'RiskAgent' in report['records_by_component']
        assert report['chain_integrity_verified'] is True


class TestModelLineageTracking:
    """Test model lineage tracking functionality."""
    
    def test_dataset_hashing(self, sample_dataset, temp_storage):
        """Test dataset hashing for lineage tracking."""
        hasher = DatasetHasher()
        
        # Hash DataFrame
        fingerprint = hasher.hash_dataframe(sample_dataset, "test_dataset")
        
        assert fingerprint.dataset_name == "test_dataset"
        assert len(fingerprint.sha256_hash) == 64
        assert fingerprint.row_count == 1000
        assert fingerprint.column_count == 4
        assert 'timestamp' in fingerprint.columns
        assert 'price' in fingerprint.columns
        
        # Hash should be deterministic
        fingerprint2 = hasher.hash_dataframe(sample_dataset, "test_dataset")
        assert fingerprint.sha256_hash == fingerprint2.sha256_hash
    
    def test_csv_file_hashing(self, sample_dataset, temp_storage):
        """Test CSV file hashing."""
        hasher = DatasetHasher()
        
        # Save dataset as CSV
        csv_file = temp_storage / "test_data.csv"
        sample_dataset.to_csv(csv_file, index=False)
        
        # Hash CSV file
        fingerprint = hasher.hash_csv_file(csv_file, "csv_dataset")
        
        assert fingerprint.dataset_name == "csv_dataset"
        assert fingerprint.dataset_path == str(csv_file.absolute())
        assert len(fingerprint.sha256_hash) == 64
        assert fingerprint.row_count == 1000
    
    def test_model_training_session(self, sample_dataset, temp_storage):
        """Test complete model training session tracking."""
        lineage_tracker = ModelLineageTracker(str(temp_storage / 'lineage'))
        
        # Start training session
        model_id = lineage_tracker.start_training_session(
            model_name="test_model",
            model_type="neural_network",
            training_config={'epochs': 100, 'batch_size': 32},
            created_by="dev1"
        )
        
        assert model_id is not None
        assert "test_model" in model_id
        
        # Record dataset usage
        train_fingerprint = lineage_tracker.record_dataset_usage(
            model_id=model_id,
            dataset=sample_dataset,
            dataset_name="training_data",
            dataset_type="training",
            transformations=["normalize", "feature_engineering"]
        )
        
        assert train_fingerprint.dataset_name == "training_data"
        assert "normalize" in train_fingerprint.transformations_applied
        
        # Create mock model file
        model_file = temp_storage / "model.pt"
        model_file.write_text("mock model content")
        
        # Record model artifact
        model_hash = lineage_tracker.record_model_artifact(
            model_id=model_id,
            model_file_path=model_file,
            model_version="1.0.0"
        )
        
        assert len(model_hash) == 64
        
        # Complete training session
        lineage = lineage_tracker.complete_training_session(
            model_id=model_id,
            model_version="1.0.0",
            hyperparameters={'learning_rate': 0.001, 'dropout': 0.2},
            training_metrics={'loss': 0.1, 'accuracy': 0.95},
            validation_metrics={'loss': 0.15, 'accuracy': 0.92},
            feature_columns=['price', 'volume', 'returns'],
            target_columns=['future_return'],
            random_seed=42
        )
        
        assert lineage.model_id == model_id
        assert lineage.model_name == "test_model"
        assert len(lineage.training_datasets) == 1
        assert lineage.training_datasets[0].dataset_name == "training_data"
        assert lineage.random_seed == 42
        assert lineage.reproducibility_hash is not None
    
    def test_reproducibility_validation(self, sample_dataset, temp_storage):
        """Test model reproducibility validation."""
        lineage_tracker = ModelLineageTracker(str(temp_storage / 'lineage'))
        
        # Create and complete training session
        model_id = lineage_tracker.start_training_session(
            model_name="repro_test",
            model_type="test",
            training_config={},
            created_by="dev1"
        )
        
        original_fingerprint = lineage_tracker.record_dataset_usage(
            model_id=model_id,
            dataset=sample_dataset,
            dataset_name="original_data",
            dataset_type="training"
        )
        
        # Create mock model file
        model_file = temp_storage / "model.pt"
        model_file.write_text("mock model")
        lineage_tracker.record_model_artifact(model_id, model_file)
        
        lineage_tracker.complete_training_session(
            model_id=model_id,
            model_version="1.0.0",
            hyperparameters={},
            training_metrics={},
            validation_metrics={},
            random_seed=42
        )
        
        # Test reproducibility with same dataset
        is_reproducible = lineage_tracker.validate_reproducibility(
            model_id, [original_fingerprint]
        )
        assert is_reproducible is True
        
        # Test reproducibility with different dataset
        different_dataset = sample_dataset.copy()
        different_dataset['price'] = different_dataset['price'] * 1.1  # Modify data
        
        different_fingerprint = DatasetHasher().hash_dataframe(
            different_dataset, "different_data"
        )
        
        is_reproducible = lineage_tracker.validate_reproducibility(
            model_id, [different_fingerprint]
        )
        assert is_reproducible is False


class TestFourEyesReleaseApproval:
    """Test four-eyes release approval system."""
    
    @pytest.mark.asyncio
    async def test_approval_request_creation(self, governance_config):
        """Test creation of approval requests."""
        release_gate = FourEyesReleaseGate(governance_config)
        
        # Create approval request
        request_id = await release_gate.create_approval_request(
            approval_type=ApprovalType.MODEL_DEPLOYMENT,
            title="Deploy Test Model",
            description="Deploy test model to production",
            requested_by="dev1",
            change_details={
                'model_id': 'test_model_123',
                'model_hash': 'abc123def456',
                'environment': 'production',
                'rollback_plan': {'available': True}
            },
            artifacts=[{
                'type': 'model_file',
                'path': '/models/test_model.pt',
                'hash': 'abc123def456'
            }]
        )
        
        assert request_id is not None
        assert "MODEL_DEPLOYMENT" in request_id
        
        # Check request status
        request = await release_gate.get_approval_status(request_id)
        assert request is not None
        assert request.status == ApprovalStatus.PENDING
        assert request.title == "Deploy Test Model"
        assert request.minimum_approvals == 2
    
    @pytest.mark.asyncio
    async def test_approval_workflow(self, governance_config):
        """Test complete approval workflow."""
        release_gate = FourEyesReleaseGate(governance_config)
        
        # Create approval request
        request_id = await release_gate.create_approval_request(
            approval_type=ApprovalType.MODEL_DEPLOYMENT,
            title="Deploy Production Model",
            description="Deploy model to production environment",
            requested_by="dev1",
            change_details={
                'model_id': 'prod_model_456',
                'model_hash': 'def789ghi012',
                'environment': 'production'
            }
        )
        
        # First approval
        success = await release_gate.submit_approval(
            request_id=request_id,
            approver_id="dev2",
            approver_name="Senior Developer 2",
            decision="APPROVE",
            comments="Code review passed, metrics look good",
            approval_authority="senior_developers"
        )
        assert success is True
        
        # Check status (should still be pending - need 2 approvals)
        request = await release_gate.get_approval_status(request_id)
        assert request.status == ApprovalStatus.PENDING
        assert len(request.approvals) == 1
        
        # Second approval
        success = await release_gate.submit_approval(
            request_id=request_id,
            approver_id="risk1",
            approver_name="Risk Manager 1",
            decision="APPROVE",
            comments="Risk assessment approved",
            approval_authority="risk_managers"
        )
        assert success is True
        
        # Check final status (should be approved)
        request = await release_gate.get_approval_status(request_id)
        assert request.status == ApprovalStatus.APPROVED
        assert len(request.approvals) == 2
    
    @pytest.mark.asyncio
    async def test_approval_rejection(self, governance_config):
        """Test approval rejection workflow."""
        release_gate = FourEyesReleaseGate(governance_config)
        
        # Create approval request
        request_id = await release_gate.create_approval_request(
            approval_type=ApprovalType.MODEL_DEPLOYMENT,
            title="Deploy Risky Model",
            description="Deploy model with high risk",
            requested_by="dev1",
            change_details={'model_id': 'risky_model'}
        )
        
        # Reject the request
        success = await release_gate.submit_approval(
            request_id=request_id,
            approver_id="risk1",
            approver_name="Risk Manager 1",
            decision="REJECT",
            comments="Risk assessment failed - model performance below threshold",
            approval_authority="risk_managers"
        )
        assert success is True
        
        # Check status (should be rejected)
        request = await release_gate.get_approval_status(request_id)
        assert request.status == ApprovalStatus.REJECTED
        assert len(request.rejections) == 1
        assert "performance below threshold" in request.rejections[0]['comments']
    
    @pytest.mark.asyncio
    async def test_pending_approvals_query(self, governance_config):
        """Test querying pending approvals for specific approver."""
        release_gate = FourEyesReleaseGate(governance_config)
        
        # Create multiple approval requests
        request_ids = []
        for i in range(3):
            request_id = await release_gate.create_approval_request(
                approval_type=ApprovalType.MODEL_DEPLOYMENT,
                title=f"Deploy Model {i}",
                description=f"Deploy test model {i}",
                requested_by="dev1",
                change_details={'model_id': f'model_{i}'}
            )
            request_ids.append(request_id)
        
        # Get pending approvals for dev2
        pending = await release_gate.get_pending_approvals("dev2")
        assert len(pending) == 3
        
        # Approve one request
        await release_gate.submit_approval(
            request_id=request_ids[0],
            approver_id="dev2",
            approver_name="Senior Developer 2",
            decision="APPROVE",
            comments="Approved",
            approval_authority="senior_developers"
        )
        
        # Check pending approvals again (should be 2 for dev2)
        pending = await release_gate.get_pending_approvals("dev2")
        assert len(pending) == 2


class TestApprovalWorkflow:
    """Test high-level approval workflow."""
    
    @pytest.mark.asyncio
    async def test_model_deployment_approval_workflow(self, governance_config):
        """Test complete model deployment approval workflow."""
        workflow = ApprovalWorkflow(governance_config)
        
        # Request model deployment approval
        request_id = await workflow.request_model_deployment_approval(
            model_id="production_model_v2",
            model_path="/models/production_model_v2.pt",
            model_hash="abcdef123456789",
            dataset_hashes=["dataset1_hash", "dataset2_hash"],
            performance_metrics={
                'accuracy': 0.95,
                'precision': 0.93,
                'recall': 0.94,
                'f1_score': 0.935
            },
            requested_by="ml_engineer1",
            target_environment="production"
        )
        
        assert request_id is not None
        
        # Check initial status
        is_approved = await workflow.is_deployment_approved(request_id)
        assert is_approved is False
        
        # Approve deployment
        success = await workflow.approve_deployment(
            request_id=request_id,
            approver_id="dev2",
            approver_name="Senior Developer 2",
            comments="Model metrics meet requirements"
        )
        assert success is True
        
        # Second approval
        success = await workflow.approve_deployment(
            request_id=request_id,
            approver_id="risk1",
            approver_name="Risk Manager 1",
            comments="Risk assessment passed"
        )
        assert success is True
        
        # Check final approval status
        is_approved = await workflow.is_deployment_approved(request_id)
        assert is_approved is True


class TestGovernanceIntegration:
    """Test integration between governance components."""
    
    @pytest.mark.asyncio
    async def test_end_to_end_governance_workflow(self, sample_dataset, governance_config):
        """Test complete end-to-end governance workflow."""
        # Initialize all governance components
        enhanced_audit = EnhancedAuditSink(governance_config)
        lineage_tracker = ModelLineageTracker(governance_config['lineage_storage_path'])
        approval_workflow = ApprovalWorkflow(governance_config)
        
        # 1. Start model training with lineage tracking
        model_id = lineage_tracker.start_training_session(
            model_name="governance_test_model",
            model_type="neural_network",
            training_config={'epochs': 50, 'learning_rate': 0.001},
            created_by="data_scientist1"
        )
        
        # 2. Record dataset usage with hashing
        train_fingerprint = lineage_tracker.record_dataset_usage(
            model_id=model_id,
            dataset=sample_dataset,
            dataset_name="market_data_train",
            dataset_type="training",
            transformations=["normalization", "feature_selection"]
        )
        
        # 3. Create and record model artifact
        model_file = Path(governance_config['lineage_storage_path']) / "test_model.pt"
        model_file.parent.mkdir(parents=True, exist_ok=True)
        model_file.write_text("mock trained model content")
        
        model_hash = lineage_tracker.record_model_artifact(
            model_id=model_id,
            model_file_path=model_file,
            model_version="1.0.0"
        )
        
        # 4. Complete training session
        lineage = lineage_tracker.complete_training_session(
            model_id=model_id,
            model_version="1.0.0",
            hyperparameters={'learning_rate': 0.001, 'dropout': 0.2},
            training_metrics={'loss': 0.05, 'accuracy': 0.96},
            validation_metrics={'loss': 0.08, 'accuracy': 0.94},
            feature_columns=['price', 'volume'],
            target_columns=['future_return'],
            random_seed=42
        )
        
        # 5. Audit model training completion
        audit_hash = await enhanced_audit.audit_model_deployment({
            'model_id': model_id,
            'model_hash': model_hash,
            'dataset_hashes': [train_fingerprint.sha256_hash],
            'performance_metrics': lineage.validation_metrics,
            'deployed_by': 'data_scientist1',
            'deployment_session': 'session_123'
        })
        
        # 6. Request deployment approval
        approval_request_id = await approval_workflow.request_model_deployment_approval(
            model_id=model_id,
            model_path=str(model_file),
            model_hash=model_hash,
            dataset_hashes=[train_fingerprint.sha256_hash],
            performance_metrics=lineage.validation_metrics,
            requested_by="data_scientist1",
            target_environment="production"
        )
        
        # 7. Approve deployment (first approval)
        await approval_workflow.approve_deployment(
            request_id=approval_request_id,
            approver_id="dev2",
            approver_name="Senior Developer 2",
            comments="Model lineage complete, performance metrics acceptable"
        )
        
        # 8. Approve deployment (second approval)
        await approval_workflow.approve_deployment(
            request_id=approval_request_id,
            approver_id="risk1",
            approver_name="Risk Manager 1",
            comments="Risk assessment passed, dataset provenance verified"
        )
        
        # 9. Verify deployment is approved
        is_approved = await approval_workflow.is_deployment_approved(approval_request_id)
        assert is_approved is True
        
        # 10. Audit successful deployment
        deployment_audit_hash = await enhanced_audit.audit_model_deployment({
            'model_id': model_id,
            'model_hash': model_hash,
            'approval_request_id': approval_request_id,
            'deployment_status': 'APPROVED',
            'deployed_by': 'deployment_system',
            'deployment_timestamp': datetime.now(timezone.utc).isoformat()
        })
        
        # Verify all components worked together
        assert model_id is not None
        assert len(model_hash) == 64
        assert len(audit_hash) == 64
        assert len(deployment_audit_hash) == 64
        assert approval_request_id is not None
        assert is_approved is True
        
        # Verify lineage is complete
        retrieved_lineage = lineage_tracker.get_model_lineage(model_id)
        assert retrieved_lineage is not None
        assert retrieved_lineage.model_id == model_id
        assert len(retrieved_lineage.training_datasets) == 1
        assert retrieved_lineage.training_datasets[0].sha256_hash == train_fingerprint.sha256_hash


if __name__ == "__main__":
    pytest.main([__file__, "-v"])