#!/usr/bin/env python3
"""
Simple test to check if imports work correctly
"""

try:
    print("Testing numpy import...")
    import numpy as np
    print(f"✅ NumPy {np.__version__} imported successfully")
    
    print("Testing pandas import...")
    import pandas as pd
    print(f"✅ Pandas {pd.__version__} imported successfully")
    
    print("Testing sklearn import...")
    from sklearn.preprocessing import StandardScaler
    print("✅ Sklearn imported successfully")
    
    print("Testing our column_names import...")
    from src.column_names import COL_OPEN, COL_HIGH, COL_LOW, COL_CLOSE, COL_VOLUME
    print(f"✅ Column names imported: {COL_OPEN}, {COL_HIGH}, {COL_LOW}, {COL_CLOSE}, {COL_VOLUME}")
    
    print("Testing data_agent import...")
    from src.agents.data_agent import DataAgent
    print("✅ DataAgent imported successfully")
    
    print("Testing feature_agent import...")
    from src.agents.feature_agent import FeatureAgent
    print("✅ FeatureAgent imported successfully")
    
    print("\n🎉 All imports successful!")
    
except Exception as e:
    print(f"❌ Import failed: {e}")
    import traceback
    traceback.print_exc()