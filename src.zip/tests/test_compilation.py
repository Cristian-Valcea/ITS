#!/usr/bin/env python3
"""
Simple compilation test for the integrated trading system
"""

import sys
import os
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

def test_basic_imports():
    """Test basic Python dependencies"""
    try:
        import yaml
        import numpy as np
        import pandas as pd
        from datetime import datetime, timedelta
        print("✅ Basic dependencies imported successfully")
        return True
    except ImportError as e:
        print(f"❌ Basic import error: {e}")
        return False

def test_project_imports():
    """Test project-specific imports"""
    try:
        from src.column_names import COL_CLOSE, COL_OPEN, COL_HIGH, COL_LOW, COL_VOLUME
        print("✅ Column names imported successfully")
        return True
    except ImportError as e:
        print(f"❌ Column names import error: {e}")
        return False

def test_orchestrator_import():
    """Test orchestrator agent import"""
    try:
        from src.execution.orchestrator_agent import OrchestratorAgent
        print("✅ OrchestratorAgent imported successfully")
        return True
    except ImportError as e:
        print(f"❌ OrchestratorAgent import error: {e}")
        return False

def main():
    """Run all compilation tests"""
    print("=== Integrated Trading System Compilation Test ===")
    
    tests = [
        ("Basic Dependencies", test_basic_imports),
        ("Project Imports", test_project_imports),
        ("Orchestrator Agent", test_orchestrator_import),
    ]
    
    passed = 0
    total = len(tests)
    
    for test_name, test_func in tests:
        print(f"\nTesting {test_name}...")
        if test_func():
            passed += 1
        else:
            print(f"❌ {test_name} test failed")
    
    print(f"\n=== Test Results: {passed}/{total} tests passed ===")
    
    if passed == total:
        print("🎉 All compilation tests PASSED! System is ready to run.")
        return 0
    else:
        print("⚠️  Some tests failed. Please check dependencies and imports.")
        return 1

if __name__ == "__main__":
    exit(main())