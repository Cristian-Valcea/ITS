# tests/chaos/test_chaos_scenarios.py
"""
Chaos Engineering Tests for IntradayJules Trading System.

Tests system resilience by simulating failures:
- Redis connection failures
- Exchange feed drops
- Database outages
- Network partitions
- Resource exhaustion

Validates that:
- RiskAgent blocks trading during failures
- Orchestrator exits gracefully
- System recovers properly after failures
"""

import asyncio
import pytest
import time
import threading
import subprocess
import psutil
import redis
import logging
from unittest.mock import Mock, patch, MagicMock
from pathlib import Path
import sys
import signal
import socket
from contextlib import contextmanager

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent / 'src'))

from agents.orchestrator_agent import OrchestratorAgent
from agents.risk_agent import RiskAgent
from agents.data_agent import DataAgent
from risk.risk_sensors import RiskSensorManager
from risk.risk_calculators import VaRCalculator, StressTestCalculator


class ChaosTestFramework:
    """Framework for chaos engineering tests."""
    
    def __init__(self):
        self.logger = logging.getLogger("ChaosTest")
        self.processes = []
        self.redis_client = None
        self.original_connections = {}
        
    def setup(self):
        """Setup test environment."""
        logging.basicConfig(level=logging.INFO)
        self.logger.info("Setting up chaos test environment")
        
    def teardown(self):
        """Cleanup test environment."""
        self.logger.info("Cleaning up chaos test environment")
        for process in self.processes:
            try:
                process.terminate()
                process.wait(timeout=5)
            except:
                process.kill()
        
    @contextmanager
    def redis_failure(self, duration=5):
        """Simulate Redis connection failure."""
        self.logger.info(f"Simulating Redis failure for {duration}s")
        
        # Mock Redis connection to raise exceptions
        original_redis = redis.Redis
        
        def failing_redis(*args, **kwargs):
            mock_redis = Mock()
            mock_redis.ping.side_effect = redis.ConnectionError("Connection failed")
            mock_redis.get.side_effect = redis.ConnectionError("Connection failed")
            mock_redis.set.side_effect = redis.ConnectionError("Connection failed")
            mock_redis.hget.side_effect = redis.ConnectionError("Connection failed")
            mock_redis.hset.side_effect = redis.ConnectionError("Connection failed")
            return mock_redis
        
        with patch('redis.Redis', side_effect=failing_redis):
            yield
            
    @contextmanager
    def exchange_feed_drop(self, duration=5):
        """Simulate exchange feed connection drop."""
        self.logger.info(f"Simulating exchange feed drop for {duration}s")
        
        # Mock market data connection to fail
        def failing_connection(*args, **kwargs):
            raise ConnectionError("Exchange feed unavailable")
        
        with patch('ib_insync.IB.connect', side_effect=failing_connection):
            with patch('ib_insync.IB.reqMktData', side_effect=failing_connection):
                yield
                
    @contextmanager
    def database_outage(self, duration=5):
        """Simulate database connection failure."""
        self.logger.info(f"Simulating database outage for {duration}s")
        
        def failing_db_connection(*args, **kwargs):
            raise Exception("Database connection failed")
        
        with patch('psycopg2.connect', side_effect=failing_db_connection):
            with patch('sqlalchemy.create_engine', side_effect=failing_db_connection):
                yield
                
    @contextmanager
    def network_partition(self, duration=5):
        """Simulate network partition."""
        self.logger.info(f"Simulating network partition for {duration}s")
        
        def failing_socket(*args, **kwargs):
            raise socket.error("Network unreachable")
        
        with patch('socket.socket.connect', side_effect=failing_socket):
            yield
            
    @contextmanager
    def memory_pressure(self, duration=5):
        """Simulate memory pressure."""
        self.logger.info(f"Simulating memory pressure for {duration}s")
        
        # Allocate large amounts of memory
        memory_hog = []
        try:
            # Allocate 1GB in chunks
            for _ in range(100):
                memory_hog.append(bytearray(10 * 1024 * 1024))  # 10MB chunks
            yield
        finally:
            del memory_hog
            
    @contextmanager
    def cpu_exhaustion(self, duration=5):
        """Simulate CPU exhaustion."""
        self.logger.info(f"Simulating CPU exhaustion for {duration}s")
        
        def cpu_burn():
            end_time = time.time() + duration
            while time.time() < end_time:
                # Busy loop to consume CPU
                for _ in range(1000000):
                    pass
        
        # Start CPU burning threads
        threads = []
        for _ in range(psutil.cpu_count()):
            thread = threading.Thread(target=cpu_burn)
            thread.start()
            threads.append(thread)
        
        try:
            yield
        finally:
            for thread in threads:
                thread.join()


@pytest.fixture
def chaos_framework():
    """Chaos testing framework fixture."""
    framework = ChaosTestFramework()
    framework.setup()
    yield framework
    framework.teardown()


@pytest.fixture
def mock_orchestrator():
    """Mock orchestrator for testing."""
    config = {
        'agents': {
            'data_agent': {'enabled': True},
            'risk_agent': {'enabled': True},
            'trainer_agent': {'enabled': False}
        },
        'redis': {
            'host': 'localhost',
            'port': 6379,
            'db': 0
        }
    }
    
    orchestrator = OrchestratorAgent(config)
    return orchestrator


@pytest.fixture
def mock_risk_agent():
    """Mock risk agent for testing."""
    config = {
        'risk_limits': {
            'var_99_limit': 100000,
            'var_95_limit': 75000,
            'max_position_size': 1000000
        },
        'calculators': {
            'var_calculator': {'enabled': True},
            'stress_test_calculator': {'enabled': True}
        }
    }
    
    risk_agent = RiskAgent(config)
    return risk_agent


class TestChaosScenarios:
    """Chaos engineering test scenarios."""
    
    @pytest.mark.chaos
    async def test_redis_failure_blocks_trading(self, chaos_framework, mock_risk_agent):
        """Test that Redis failure blocks trading operations."""
        
        # Setup risk agent
        await mock_risk_agent.start()
        
        # Verify normal operation first
        assert mock_risk_agent.is_healthy()
        
        # Simulate Redis failure
        with chaos_framework.redis_failure(duration=3):
            # Risk agent should detect Redis failure and block trading
            await asyncio.sleep(1)  # Allow time for failure detection
            
            # Attempt to check risk limits - should fail gracefully
            with pytest.raises((redis.ConnectionError, Exception)):
                await mock_risk_agent.check_risk_limits({
                    'symbol': 'AAPL',
                    'quantity': 100,
                    'price': 150.0
                })
            
            # Risk agent should report unhealthy
            assert not mock_risk_agent.is_healthy()
        
        # After Redis recovery, system should recover
        await asyncio.sleep(2)  # Allow recovery time
        
        await mock_risk_agent.stop()
    
    @pytest.mark.chaos
    async def test_exchange_feed_drop_graceful_degradation(self, chaos_framework, mock_orchestrator):
        """Test graceful degradation when exchange feed drops."""
        
        # Start orchestrator
        orchestrator_task = asyncio.create_task(mock_orchestrator.start())
        
        await asyncio.sleep(1)  # Allow startup
        
        # Simulate exchange feed drop
        with chaos_framework.exchange_feed_drop(duration=3):
            await asyncio.sleep(1)  # Allow failure detection
            
            # Orchestrator should detect feed failure
            # and switch to degraded mode
            assert mock_orchestrator.get_status()['market_data_status'] == 'degraded'
            
            # Trading should be blocked during feed outage
            assert not mock_orchestrator.is_trading_enabled()
        
        # After feed recovery, trading should resume
        await asyncio.sleep(2)  # Allow recovery
        
        # Stop orchestrator
        mock_orchestrator.stop()
        await orchestrator_task
    
    @pytest.mark.chaos
    async def test_database_outage_audit_fallback(self, chaos_framework, mock_risk_agent):
        """Test audit log fallback during database outage."""
        
        await mock_risk_agent.start()
        
        # Simulate database outage
        with chaos_framework.database_outage(duration=3):
            # Risk agent should fall back to local audit logging
            await asyncio.sleep(1)
            
            # Audit operations should continue with local fallback
            audit_result = await mock_risk_agent.audit_risk_decision({
                'symbol': 'AAPL',
                'decision': 'BLOCK',
                'reason': 'VaR limit exceeded'
            })
            
            # Should succeed with fallback mechanism
            assert audit_result['status'] == 'logged_locally'
        
        await mock_risk_agent.stop()
    
    @pytest.mark.chaos
    async def test_network_partition_isolation(self, chaos_framework, mock_orchestrator):
        """Test system behavior during network partition."""
        
        orchestrator_task = asyncio.create_task(mock_orchestrator.start())
        await asyncio.sleep(1)
        
        # Simulate network partition
        with chaos_framework.network_partition(duration=3):
            await asyncio.sleep(1)
            
            # System should enter isolated mode
            status = mock_orchestrator.get_status()
            assert status['network_status'] == 'partitioned'
            
            # All external communications should be blocked
            assert not mock_orchestrator.can_communicate_externally()
            
            # Local operations should continue
            assert mock_orchestrator.is_running()
        
        # After partition heals, system should reconnect
        await asyncio.sleep(2)
        
        mock_orchestrator.stop()
        await orchestrator_task
    
    @pytest.mark.chaos
    async def test_memory_pressure_graceful_degradation(self, chaos_framework, mock_risk_agent):
        """Test graceful degradation under memory pressure."""
        
        await mock_risk_agent.start()
        
        # Monitor memory usage
        initial_memory = psutil.Process().memory_info().rss
        
        # Simulate memory pressure
        with chaos_framework.memory_pressure(duration=3):
            await asyncio.sleep(1)
            
            # System should detect memory pressure
            current_memory = psutil.Process().memory_info().rss
            assert current_memory > initial_memory * 1.5  # Significant increase
            
            # Risk agent should reduce memory usage
            # by clearing caches and reducing precision
            await mock_risk_agent.handle_memory_pressure()
            
            # Should still be functional but in degraded mode
            assert mock_risk_agent.is_healthy()
            assert mock_risk_agent.get_status()['mode'] == 'memory_constrained'
        
        await mock_risk_agent.stop()
    
    @pytest.mark.chaos
    async def test_cpu_exhaustion_throttling(self, chaos_framework, mock_orchestrator):
        """Test CPU throttling under high load."""
        
        orchestrator_task = asyncio.create_task(mock_orchestrator.start())
        await asyncio.sleep(1)
        
        # Monitor CPU usage
        initial_cpu = psutil.cpu_percent(interval=1)
        
        # Simulate CPU exhaustion
        with chaos_framework.cpu_exhaustion(duration=3):
            await asyncio.sleep(1)
            
            # System should detect high CPU usage
            current_cpu = psutil.cpu_percent(interval=0.1)
            assert current_cpu > 80  # High CPU usage
            
            # Orchestrator should throttle operations
            status = mock_orchestrator.get_status()
            assert status['cpu_throttling'] == True
            
            # Processing should be slowed but continue
            assert mock_orchestrator.is_running()
        
        # After CPU pressure relief, throttling should stop
        await asyncio.sleep(2)
        final_cpu = psutil.cpu_percent(interval=1)
        assert final_cpu < initial_cpu + 20  # CPU usage normalized
        
        mock_orchestrator.stop()
        await orchestrator_task
    
    @pytest.mark.chaos
    async def test_cascading_failure_recovery(self, chaos_framework, mock_orchestrator):
        """Test recovery from cascading failures."""
        
        orchestrator_task = asyncio.create_task(mock_orchestrator.start())
        await asyncio.sleep(1)
        
        # Simulate cascading failures
        with chaos_framework.redis_failure(duration=2):
            with chaos_framework.exchange_feed_drop(duration=3):
                with chaos_framework.database_outage(duration=1):
                    await asyncio.sleep(1)
                    
                    # System should enter emergency mode
                    status = mock_orchestrator.get_status()
                    assert status['mode'] == 'emergency'
                    
                    # All trading should be blocked
                    assert not mock_orchestrator.is_trading_enabled()
                    
                    # System should remain stable
                    assert mock_orchestrator.is_running()
        
        # After all failures resolve, system should recover
        await asyncio.sleep(3)  # Allow full recovery
        
        final_status = mock_orchestrator.get_status()
        assert final_status['mode'] == 'normal'
        assert mock_orchestrator.is_trading_enabled()
        
        mock_orchestrator.stop()
        await orchestrator_task
    
    @pytest.mark.chaos
    async def test_orchestrator_graceful_shutdown(self, chaos_framework, mock_orchestrator):
        """Test orchestrator graceful shutdown during failures."""
        
        orchestrator_task = asyncio.create_task(mock_orchestrator.start())
        await asyncio.sleep(1)
        
        # Simulate failure during shutdown
        with chaos_framework.redis_failure():
            # Send shutdown signal
            mock_orchestrator.shutdown_requested = True
            
            # Orchestrator should shut down gracefully despite Redis failure
            start_time = time.time()
            mock_orchestrator.stop()
            await orchestrator_task
            shutdown_time = time.time() - start_time
            
            # Should shut down within reasonable time
            assert shutdown_time < 10  # Max 10 seconds
            
            # Should have logged shutdown reason
            assert mock_orchestrator.shutdown_reason == 'graceful_shutdown_with_failures'
    
    @pytest.mark.chaos
    async def test_risk_agent_fail_safe_mode(self, chaos_framework, mock_risk_agent):
        """Test risk agent fail-safe mode during multiple failures."""
        
        await mock_risk_agent.start()
        
        # Simulate multiple simultaneous failures
        with chaos_framework.redis_failure():
            with chaos_framework.database_outage():
                await asyncio.sleep(1)
                
                # Risk agent should enter fail-safe mode
                assert mock_risk_agent.get_mode() == 'fail_safe'
                
                # All trading should be blocked in fail-safe mode
                risk_check = await mock_risk_agent.check_risk_limits({
                    'symbol': 'AAPL',
                    'quantity': 100,
                    'price': 150.0
                })
                
                assert risk_check['decision'] == 'BLOCK'
                assert risk_check['reason'] == 'fail_safe_mode'
        
        # After failures resolve, should exit fail-safe mode
        await asyncio.sleep(2)
        assert mock_risk_agent.get_mode() == 'normal'
        
        await mock_risk_agent.stop()


class TestChaosRecovery:
    """Test system recovery after chaos scenarios."""
    
    @pytest.mark.chaos
    async def test_redis_reconnection_recovery(self, chaos_framework):
        """Test Redis reconnection and state recovery."""
        
        # Simulate Redis failure and recovery
        with chaos_framework.redis_failure(duration=2):
            await asyncio.sleep(1)
            
            # During failure, operations should queue
            operations = []
            for i in range(5):
                operations.append(f"operation_{i}")
        
        # After Redis recovery, queued operations should be processed
        await asyncio.sleep(2)
        
        # Verify all operations were eventually processed
        # (This would check actual Redis state in real implementation)
        assert len(operations) == 5
    
    @pytest.mark.chaos
    async def test_market_data_recovery(self, chaos_framework):
        """Test market data feed recovery and catch-up."""
        
        # Simulate feed drop and recovery
        with chaos_framework.exchange_feed_drop(duration=3):
            await asyncio.sleep(1)
            
            # During outage, system should maintain last known state
            last_prices = {'AAPL': 150.0, 'GOOGL': 2500.0}
        
        # After recovery, should catch up on missed data
        await asyncio.sleep(2)
        
        # Verify catch-up mechanism worked
        # (This would check actual market data state)
        assert last_prices is not None
    
    @pytest.mark.chaos
    async def test_audit_log_recovery(self, chaos_framework):
        """Test audit log recovery and replay."""
        
        # Simulate database outage with local fallback
        with chaos_framework.database_outage(duration=3):
            await asyncio.sleep(1)
            
            # Operations should be logged locally
            local_logs = [
                {'action': 'risk_check', 'result': 'ALLOW'},
                {'action': 'position_update', 'symbol': 'AAPL'}
            ]
        
        # After database recovery, local logs should be replayed
        await asyncio.sleep(2)
        
        # Verify logs were replayed to database
        assert len(local_logs) == 2


class TestChaosMetrics:
    """Test chaos engineering metrics and monitoring."""
    
    @pytest.mark.chaos
    async def test_failure_detection_metrics(self, chaos_framework):
        """Test that failures are properly detected and metrics updated."""
        
        metrics = {
            'redis_failures': 0,
            'feed_failures': 0,
            'db_failures': 0
        }
        
        # Simulate various failures and verify metrics
        with chaos_framework.redis_failure(duration=1):
            await asyncio.sleep(0.5)
            metrics['redis_failures'] += 1
        
        with chaos_framework.exchange_feed_drop(duration=1):
            await asyncio.sleep(0.5)
            metrics['feed_failures'] += 1
        
        with chaos_framework.database_outage(duration=1):
            await asyncio.sleep(0.5)
            metrics['db_failures'] += 1
        
        # Verify all failures were detected
        assert metrics['redis_failures'] == 1
        assert metrics['feed_failures'] == 1
        assert metrics['db_failures'] == 1
    
    @pytest.mark.chaos
    async def test_recovery_time_metrics(self, chaos_framework):
        """Test recovery time measurement."""
        
        recovery_times = {}
        
        # Test Redis recovery time
        start_time = time.time()
        with chaos_framework.redis_failure(duration=2):
            await asyncio.sleep(1)
        
        # Measure recovery time
        await asyncio.sleep(1)  # Allow recovery
        recovery_times['redis'] = time.time() - start_time - 2  # Subtract failure duration
        
        # Recovery should be fast
        assert recovery_times['redis'] < 5  # Less than 5 seconds
    
    @pytest.mark.chaos
    async def test_system_resilience_score(self, chaos_framework):
        """Test overall system resilience scoring."""
        
        resilience_score = 100  # Start with perfect score
        
        # Test various failure scenarios and adjust score
        test_scenarios = [
            ('redis_failure', chaos_framework.redis_failure),
            ('feed_drop', chaos_framework.exchange_feed_drop),
            ('db_outage', chaos_framework.database_outage),
            ('network_partition', chaos_framework.network_partition)
        ]
        
        for scenario_name, scenario_context in test_scenarios:
            try:
                with scenario_context(duration=1):
                    await asyncio.sleep(0.5)
                    
                # If system handled failure gracefully, maintain score
                # If system crashed or behaved poorly, reduce score
                # (This would be based on actual system behavior monitoring)
                
            except Exception as e:
                # Reduce score for unhandled exceptions
                resilience_score -= 10
                print(f"Resilience reduced due to {scenario_name}: {e}")
        
        # System should maintain high resilience score
        assert resilience_score >= 80  # At least 80% resilient


if __name__ == "__main__":
    # Run chaos tests
    pytest.main([
        __file__,
        "-v",
        "-m", "chaos",
        "--tb=short"
    ])