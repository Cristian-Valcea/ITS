"""
Test FeatureStore concurrency improvements with PostgreSQL advisory locks.

This test validates that the advisory lock implementation eliminates
row-lock contention when multiple workers access the same symbol/date combinations.
"""

import pytest
import pandas as pd
import numpy as np
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import tempfile
import os
from unittest.mock import patch

# Test imports
import sys
sys.path.append('src')

from shared.feature_store import FeatureStore
from shared.db_pool import is_available as pg_available, close_pool
from shared.db_locker import symbol_to_lock_key


class TestFeatureStoreConcurrency:
    """Test FeatureStore concurrency with advisory locks."""
    
    @pytest.fixture
    def temp_feature_store(self):
        """Create a temporary FeatureStore for testing."""
        with tempfile.TemporaryDirectory() as temp_dir:
            # Set environment for test
            os.environ["FEATURE_STORE_PATH"] = temp_dir
            
            # Create FeatureStore instance
            fs = FeatureStore(root=temp_dir)
            
            yield fs
            
            # Cleanup
            if hasattr(fs, 'db'):
                fs.db.close()
            close_pool()
    
    @pytest.fixture
    def sample_data(self):
        """Create sample OHLCV data for testing."""
        dates = pd.date_range('2023-01-01', periods=100, freq='1min')
        np.random.seed(42)  # Reproducible data
        
        data = pd.DataFrame({
            'open': 100 + np.random.randn(100).cumsum() * 0.1,
            'high': 100 + np.random.randn(100).cumsum() * 0.1 + 0.5,
            'low': 100 + np.random.randn(100).cumsum() * 0.1 - 0.5,
            'close': 100 + np.random.randn(100).cumsum() * 0.1,
            'volume': np.random.randint(1000, 10000, 100)
        }, index=dates)
        
        # Ensure high >= low >= close relationships
        data['high'] = np.maximum(data['high'], data[['open', 'close']].max(axis=1))
        data['low'] = np.minimum(data['low'], data[['open', 'close']].min(axis=1))
        
        return data
    
    def dummy_feature_compute(self, df: pd.DataFrame, config: dict) -> pd.DataFrame:
        """Dummy feature computation function."""
        # Simulate some computation time
        time.sleep(0.01)  # 10ms computation
        
        return pd.DataFrame({
            'sma_5': df['close'].rolling(5).mean(),
            'sma_10': df['close'].rolling(10).mean(),
            'rsi': np.random.rand(len(df)) * 100,  # Dummy RSI
            'volume_sma': df['volume'].rolling(5).mean()
        }, index=df.index)
    
    def test_symbol_to_lock_key_consistency(self):
        """Test that symbol_to_lock_key produces consistent results."""
        symbol = "AAPL"
        
        # Should produce same key multiple times
        key1 = symbol_to_lock_key(symbol)
        key2 = symbol_to_lock_key(symbol)
        key3 = symbol_to_lock_key(symbol)
        
        assert key1 == key2 == key3
        assert isinstance(key1, int)
        
        # Different symbols should produce different keys
        key_googl = symbol_to_lock_key("GOOGL")
        key_msft = symbol_to_lock_key("MSFT")
        
        assert key1 != key_googl != key_msft
    
    def test_single_worker_cache_behavior(self, temp_feature_store, sample_data):
        """Test basic cache behavior with single worker."""
        fs = temp_feature_store
        config = {'test': 'single_worker'}
        symbol = "TEST_SINGLE"
        
        # First call should be a cache miss
        start_time = time.time()
        result1 = fs.get_or_compute(symbol, sample_data, config, self.dummy_feature_compute)
        miss_time = time.time() - start_time
        
        assert result1 is not None
        assert len(result1) == len(sample_data)
        assert 'sma_5' in result1.columns
        
        # Second call should be a cache hit (much faster)
        start_time = time.time()
        result2 = fs.get_or_compute(symbol, sample_data, config, self.dummy_feature_compute)
        hit_time = time.time() - start_time
        
        assert result2 is not None
        assert len(result2) == len(result1)
        
        # Cache hit should be significantly faster
        assert hit_time < miss_time / 2, f"Hit time {hit_time:.3f}s should be much less than miss time {miss_time:.3f}s"
    
    def test_concurrent_same_symbol_access(self, temp_feature_store, sample_data):
        """Test concurrent access to the same symbol (main contention scenario)."""
        fs = temp_feature_store
        config = {'test': 'concurrent_same_symbol'}
        symbol = "AAPL"  # Same symbol for all workers
        num_workers = 8
        
        def worker_task(worker_id: int) -> dict:
            """Task executed by each worker."""
            start_time = time.time()
            try:
                result = fs.get_or_compute(symbol, sample_data, config, self.dummy_feature_compute)
                end_time = time.time()
                
                return {
                    'worker_id': worker_id,
                    'success': True,
                    'duration': end_time - start_time,
                    'result_rows': len(result) if result is not None else 0,
                    'error': None
                }
            except Exception as e:
                end_time = time.time()
                return {
                    'worker_id': worker_id,
                    'success': False,
                    'duration': end_time - start_time,
                    'result_rows': 0,
                    'error': str(e)
                }
        
        # Execute concurrent workers
        start_time = time.time()
        with ThreadPoolExecutor(max_workers=num_workers) as executor:
            futures = [executor.submit(worker_task, i) for i in range(num_workers)]
            results = [future.result() for future in as_completed(futures)]
        total_time = time.time() - start_time
        
        # Analyze results
        successful_results = [r for r in results if r['success']]
        failed_results = [r for r in results if not r['success']]
        
        print(f"\nConcurrency Test Results:")
        print(f"Total workers: {num_workers}")
        print(f"Successful: {len(successful_results)}")
        print(f"Failed: {len(failed_results)}")
        print(f"Total time: {total_time:.3f}s")
        
        if successful_results:
            durations = [r['duration'] for r in successful_results]
            print(f"Duration stats: min={min(durations):.3f}s, max={max(durations):.3f}s, avg={np.mean(durations):.3f}s")
            print(f"P99 duration: {np.percentile(durations, 99):.3f}s")
        
        if failed_results:
            print("Failures:")
            for r in failed_results:
                print(f"  Worker {r['worker_id']}: {r['error']}")
        
        # Assertions
        assert len(successful_results) >= num_workers - 1, "Most workers should succeed"
        
        if fs.use_pg_manifest:
            # With PostgreSQL + advisory locks, p99 should be reasonable
            if successful_results:
                p99_duration = np.percentile([r['duration'] for r in successful_results], 99)
                assert p99_duration < 1.0, f"P99 duration {p99_duration:.3f}s should be < 1.0s with advisory locks"
        
        # All successful results should have same number of rows
        if successful_results:
            expected_rows = successful_results[0]['result_rows']
            for result in successful_results:
                assert result['result_rows'] == expected_rows
    
    def test_concurrent_different_symbols(self, temp_feature_store, sample_data):
        """Test concurrent access to different symbols (should be fast)."""
        fs = temp_feature_store
        config = {'test': 'concurrent_different_symbols'}
        symbols = ["AAPL", "GOOGL", "MSFT", "TSLA", "AMZN", "META", "NVDA", "NFLX"]
        num_workers = len(symbols)
        
        def worker_task(worker_id: int) -> dict:
            """Task executed by each worker with different symbol."""
            symbol = symbols[worker_id]
            start_time = time.time()
            try:
                result = fs.get_or_compute(symbol, sample_data, config, self.dummy_feature_compute)
                end_time = time.time()
                
                return {
                    'worker_id': worker_id,
                    'symbol': symbol,
                    'success': True,
                    'duration': end_time - start_time,
                    'result_rows': len(result) if result is not None else 0,
                    'error': None
                }
            except Exception as e:
                end_time = time.time()
                return {
                    'worker_id': worker_id,
                    'symbol': symbol,
                    'success': False,
                    'duration': end_time - start_time,
                    'result_rows': 0,
                    'error': str(e)
                }
        
        # Execute concurrent workers
        start_time = time.time()
        with ThreadPoolExecutor(max_workers=num_workers) as executor:
            futures = [executor.submit(worker_task, i) for i in range(num_workers)]
            results = [future.result() for future in as_completed(futures)]
        total_time = time.time() - start_time
        
        # Analyze results
        successful_results = [r for r in results if r['success']]
        failed_results = [r for r in results if not r['success']]
        
        print(f"\nDifferent Symbols Test Results:")
        print(f"Total workers: {num_workers}")
        print(f"Successful: {len(successful_results)}")
        print(f"Failed: {len(failed_results)}")
        print(f"Total time: {total_time:.3f}s")
        
        if successful_results:
            durations = [r['duration'] for r in successful_results]
            print(f"Duration stats: min={min(durations):.3f}s, max={max(durations):.3f}s, avg={np.mean(durations):.3f}s")
        
        # Assertions
        assert len(successful_results) == num_workers, "All workers should succeed with different symbols"
        
        # Different symbols should not contend, so should be relatively fast
        if successful_results:
            max_duration = max(r['duration'] for r in successful_results)
            assert max_duration < 0.5, f"Max duration {max_duration:.3f}s should be < 0.5s for different symbols"
    
    @pytest.mark.skipif(not pg_available(), reason="PostgreSQL not available")
    def test_postgresql_advisory_locks_enabled(self, temp_feature_store):
        """Test that PostgreSQL advisory locks are properly enabled."""
        fs = temp_feature_store
        
        # Should use PostgreSQL manifest when available
        assert fs.use_pg_manifest, "Should use PostgreSQL manifest when available"
        
        # Test lock key generation
        lock_key = symbol_to_lock_key("AAPL")
        assert isinstance(lock_key, int)
        assert lock_key != 0
    
    def test_fallback_to_duckdb(self):
        """Test fallback to DuckDB when PostgreSQL is not available."""
        with tempfile.TemporaryDirectory() as temp_dir:
            # Mock PostgreSQL as unavailable
            with patch('shared.feature_store.pg_available', return_value=False):
                fs = FeatureStore(root=temp_dir)
                
                # Should fallback to DuckDB
                assert not fs.use_pg_manifest, "Should fallback to DuckDB when PostgreSQL unavailable"
                assert hasattr(fs, 'db'), "Should have DuckDB connection"
    
    def test_performance_comparison(self, temp_feature_store, sample_data):
        """Compare performance between PostgreSQL and DuckDB backends."""
        if not pg_available():
            pytest.skip("PostgreSQL not available for performance comparison")
        
        config = {'test': 'performance_comparison'}
        symbol = "PERF_TEST"
        num_iterations = 5
        
        # Test with current backend
        fs = temp_feature_store
        backend_name = "PostgreSQL" if fs.use_pg_manifest else "DuckDB"
        
        durations = []
        for i in range(num_iterations):
            # Use different config each time to avoid cache hits
            test_config = {**config, 'iteration': i}
            
            start_time = time.time()
            result = fs.get_or_compute(f"{symbol}_{i}", sample_data, test_config, self.dummy_feature_compute)
            duration = time.time() - start_time
            durations.append(duration)
            
            assert result is not None
            assert len(result) == len(sample_data)
        
        avg_duration = np.mean(durations)
        print(f"\n{backend_name} Performance:")
        print(f"Average duration: {avg_duration:.3f}s")
        print(f"Min duration: {min(durations):.3f}s")
        print(f"Max duration: {max(durations):.3f}s")
        
        # Performance should be reasonable
        assert avg_duration < 1.0, f"Average duration {avg_duration:.3f}s should be < 1.0s"


if __name__ == "__main__":
    # Run specific test for development
    import logging
    logging.basicConfig(level=logging.INFO)
    
    test = TestFeatureStoreConcurrency()
    
    # Create fixtures manually for standalone testing
    import tempfile
    with tempfile.TemporaryDirectory() as temp_dir:
        os.environ["FEATURE_STORE_PATH"] = temp_dir
        fs = FeatureStore(root=temp_dir)
        
        # Create sample data
        dates = pd.date_range('2023-01-01', periods=50, freq='1min')
        data = pd.DataFrame({
            'open': 100 + np.random.randn(50).cumsum() * 0.1,
            'high': 100 + np.random.randn(50).cumsum() * 0.1 + 0.5,
            'low': 100 + np.random.randn(50).cumsum() * 0.1 - 0.5,
            'close': 100 + np.random.randn(50).cumsum() * 0.1,
            'volume': np.random.randint(1000, 10000, 50)
        }, index=dates)
        
        print("Running concurrency test...")
        test.test_concurrent_same_symbol_access(fs, data)
        
        if hasattr(fs, 'db'):
            fs.db.close()
        close_pool()