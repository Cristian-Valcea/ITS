"""
Simple test for vectorized environment implementation.
"""

import pytest
import tempfile
import multiprocessing as mp
from pathlib import Path

def test_optimal_n_envs():
    """Test calculation of optimal number of environments."""
    try:
        from src.training.core.env_builder import get_optimal_n_envs
        
        # Test with more symbols than CPUs
        symbols = [f"SYMBOL_{i}" for i in range(20)]
        n_envs = get_optimal_n_envs(symbols, max_envs=8)
        
        assert 1 <= n_envs <= 8
        assert n_envs <= len(symbols)
        assert n_envs <= mp.cpu_count()
        
        print(f"✅ Optimal environments test passed: {n_envs} environments")
        return True
        
    except ImportError as e:
        print(f"⚠️  Import failed: {e}")
        return False
    except Exception as e:
        print(f"❌ Test failed: {e}")
        return False

def test_trainer_agent_methods():
    """Test that TrainerAgent has vectorized environment methods."""
    try:
        from src.training.trainer_agent import TrainerAgent
        
        config = {
            'algorithm': 'DQN',
            'environment': {
                'observation_feature_cols': ['close', 'volume'],
                'initial_balance': 100000,
                'action_type': 'discrete'
            },
            'training': {
                'total_timesteps': 1000
            }
        }
        
        trainer = TrainerAgent(config)
        
        # Test that vectorized methods exist
        assert hasattr(trainer, 'create_vectorized_env')
        assert hasattr(trainer, 'get_recommended_n_envs')
        
        # Test recommended environments calculation
        symbols = ["EURUSD", "GBPUSD", "USDJPY"]
        n_envs = trainer.get_recommended_n_envs(symbols)
        
        assert isinstance(n_envs, int)
        assert 1 <= n_envs <= len(symbols)
        
        print(f"✅ TrainerAgent methods test passed: {n_envs} recommended environments")
        return True
        
    except Exception as e:
        print(f"❌ TrainerAgent test failed: {e}")
        return False

def test_env_builder_smoke():
    """Test environment builder smoke test."""
    try:
        # Test that we can import the module
        from src.training.core.env_builder import build_vec_env, build_single_env
        
        print("✅ Environment builder import successful")
        return True
        
    except ImportError as e:
        print(f"⚠️  Environment builder import failed: {e}")
        return False

def test_sb3_availability():
    """Test SB3 vectorized environment availability."""
    try:
        from stable_baselines3.common.vec_env import ShmemVecEnv, VecMonitor, DummyVecEnv
        print("✅ SB3 vectorized environments available")
        return True
    except ImportError:
        print("⚠️  SB3 vectorized environments not available (requires SB3 1.8+)")
        return False

if __name__ == "__main__":
    """Run simple tests."""
    print("Running simple vectorized environment tests...")
    
    tests = [
        test_sb3_availability,
        test_env_builder_smoke,
        test_optimal_n_envs,
        test_trainer_agent_methods
    ]
    
    passed = 0
    total = len(tests)
    
    for test in tests:
        print(f"\n--- {test.__name__} ---")
        try:
            if test():
                passed += 1
        except Exception as e:
            print(f"❌ {test.__name__} failed: {e}")
    
    print(f"\n📊 Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All tests passed!")
    else:
        print("⚠️  Some tests failed - check output above")