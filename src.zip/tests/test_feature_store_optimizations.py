# tests/test_feature_store_optimizations.py
"""
Tests for feature store optimizations:
1. Disk GC cron - delete parquet files not referenced in manifest > N weeks
2. Hash footer only for tick-data - avoids large in-memory hash
3. Wrap INSERT in BEGIN EXCLUSIVE - for parallel trainers sharing cache
"""

import pytest
import tempfile
import pandas as pd
import numpy as np
import threading
import time
import json
from datetime import datetime, timedelta
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import sys
import os

# Add src to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

try:
    from shared.feature_store_optimized import OptimizedFeatureStore
    from shared.disk_gc_service import DiskGarbageCollector
    OPTIMIZATIONS_AVAILABLE = True
except ImportError as e:
    OPTIMIZATIONS_AVAILABLE = False
    print(f"Optimization modules not available: {e}")


@pytest.mark.skipif(not OPTIMIZATIONS_AVAILABLE, reason="Optimization modules not available")
class TestFeatureStoreOptimizations:
    """Test feature store optimizations."""
    
    def create_large_dataset(self, rows: int = 100000) -> pd.DataFrame:
        """Create a large dataset for testing."""
        np.random.seed(42)
        
        # Create realistic tick data
        start_time = pd.Timestamp('2024-01-01 09:30:00')
        timestamps = pd.date_range(start_time, periods=rows, freq='1s')
        
        # Simulate realistic market data
        price_base = 100.0
        price_walk = np.cumsum(np.random.randn(rows) * 0.01)
        
        data = {
            'timestamp': timestamps,
            'price': price_base + price_walk,
            'bid': price_base + price_walk - np.random.uniform(0.01, 0.05, rows),
            'ask': price_base + price_walk + np.random.uniform(0.01, 0.05, rows),
            'volume': np.random.randint(100, 10000, rows),
            'trade_count': np.random.randint(1, 100, rows)
        }
        
        df = pd.DataFrame(data)
        df.set_index('timestamp', inplace=True)
        return df
    
    def test_footer_only_hashing_optimization(self):
        """Test that large datasets use footer-only hashing."""
        with tempfile.TemporaryDirectory() as temp_dir:
            # Create optimized feature store
            store = OptimizedFeatureStore(
                root=temp_dir,
                tick_data_threshold_mb=1  # Low threshold for testing
            )
            
            # Create large dataset (should trigger footer hashing)
            large_df = self.create_large_dataset(50000)  # ~50k rows
            
            # Mock compute function
            def compute_features(raw_df, config):
                return raw_df.copy()
            
            config = {'test': True}
            
            # This should use footer hashing
            result = store.get_or_compute('TEST', large_df, config, compute_features)
            
            assert result is not None
            assert len(result) == len(large_df)
            
            # Check that hash optimization was used
            assert store.metrics['hash_optimizations'] > 0
            
            # Verify cache entry was created with footer hash method
            stats = store.get_cache_stats()
            assert stats['footer_hash_optimizations'] > 0
    
    def test_exclusive_transaction_locking(self):
        """Test that parallel trainers can safely write to cache."""
        with tempfile.TemporaryDirectory() as temp_dir:
            store = OptimizedFeatureStore(root=temp_dir)
            
            # Create test dataset
            test_df = self.create_large_dataset(1000)
            
            def compute_features(raw_df, config):
                # Simulate some computation time
                time.sleep(0.1)
                return raw_df.copy()
            
            # Function to simulate parallel trainer
            def parallel_trainer(trainer_id: int):
                try:
                    config = {'trainer_id': trainer_id, 'test': True}
                    result = store.get_or_compute(f'SYMBOL_{trainer_id}', test_df, config, compute_features)
                    return {'trainer_id': trainer_id, 'success': True, 'rows': len(result)}
                except Exception as e:
                    return {'trainer_id': trainer_id, 'success': False, 'error': str(e)}
            
            # Run multiple parallel trainers
            num_trainers = 5
            with ThreadPoolExecutor(max_workers=num_trainers) as executor:
                futures = [executor.submit(parallel_trainer, i) for i in range(num_trainers)]
                results = [future.result() for future in as_completed(futures)]
            
            # All trainers should succeed
            successful = [r for r in results if r['success']]
            failed = [r for r in results if not r['success']]
            
            assert len(successful) == num_trainers, f"Failed trainers: {failed}"
            
            # Check cache stats
            stats = store.get_cache_stats()
            assert stats['total_entries'] == num_trainers
    
    def test_garbage_collection_service(self):
        """Test standalone garbage collection service."""
        with tempfile.TemporaryDirectory() as temp_dir:
            # Create feature store and add some entries
            store = OptimizedFeatureStore(root=temp_dir, enable_gc=False)
            
            # Add some cache entries
            test_df = self.create_large_dataset(1000)
            
            def compute_features(raw_df, config):
                return raw_df.copy()
            
            # Create multiple cache entries
            for i in range(5):
                config = {'symbol': f'TEST_{i}'}
                store.get_or_compute(f'TEST_{i}', test_df, config, compute_features)
            
            # Create some orphaned files (not in manifest)
            orphaned_file = Path(temp_dir) / "orphaned.parquet.zst"
            orphaned_file.write_bytes(b"fake parquet data")
            
            # Initialize garbage collector
            gc = DiskGarbageCollector(
                cache_root=temp_dir,
                retention_weeks=0,  # Delete everything for testing
                dry_run=True  # Don't actually delete in test
            )
            
            # Run garbage collection
            results = gc.run_garbage_collection()
            
            assert results['status'] == 'success'
            assert results['dry_run'] is True
            
            # Should find orphaned files
            orphan_results = results['orphaned_files_cleanup']
            assert orphan_results['files_deleted'] >= 1
            
            # Should find old entries
            old_results = results['old_entries_cleanup']
            assert old_results['manifest_entries_deleted'] >= 0
    
    def test_cache_integrity_validation(self):
        """Test cache integrity validation."""
        with tempfile.TemporaryDirectory() as temp_dir:
            store = OptimizedFeatureStore(root=temp_dir, enable_gc=False)
            
            # Add cache entry
            test_df = self.create_large_dataset(1000)
            
            def compute_features(raw_df, config):
                return raw_df.copy()
            
            config = {'test': True}
            store.get_or_compute('TEST', test_df, config, compute_features)
            
            # Validate integrity (should pass)
            integrity = store.validate_cache_integrity()
            assert integrity['integrity_ok'] is True
            assert integrity['missing_files'] == 0
            
            # Corrupt cache by deleting a file
            cache_files = list(Path(temp_dir).glob('*.parquet.zst'))
            if cache_files:
                cache_files[0].unlink()
                
                # Validate integrity (should fail)
                integrity = store.validate_cache_integrity()
                assert integrity['integrity_ok'] is False
                assert integrity['missing_files'] > 0
    
    def test_performance_metrics(self):
        """Test performance metrics collection."""
        with tempfile.TemporaryDirectory() as temp_dir:
            store = OptimizedFeatureStore(root=temp_dir, enable_gc=False)
            
            test_df = self.create_large_dataset(1000)
            
            def compute_features(raw_df, config):
                return raw_df.copy()
            
            config = {'test': True}
            
            # First call should be cache miss
            store.get_or_compute('TEST', test_df, config, compute_features)
            assert store.metrics['cache_misses'] == 1
            assert store.metrics['cache_hits'] == 0
            
            # Second call should be cache hit
            store.get_or_compute('TEST', test_df, config, compute_features)
            assert store.metrics['cache_misses'] == 1
            assert store.metrics['cache_hits'] == 1
            
            # Get comprehensive stats
            stats = store.get_cache_stats()
            assert 'cache_hits' in stats
            assert 'cache_misses' in stats
            assert stats['total_entries'] > 0
    
    def test_automatic_garbage_collection(self):
        """Test automatic garbage collection scheduling."""
        with tempfile.TemporaryDirectory() as temp_dir:
            # Create store with GC enabled but very short retention
            store = OptimizedFeatureStore(
                root=temp_dir,
                enable_gc=True,
                gc_retention_weeks=0  # Immediate cleanup for testing
            )
            
            # Add cache entry
            test_df = self.create_large_dataset(1000)
            
            def compute_features(raw_df, config):
                return raw_df.copy()
            
            config = {'test': True}
            store.get_or_compute('TEST', test_df, config, compute_features)
            
            # Force GC run
            gc_results = store.force_garbage_collection()
            assert gc_results['status'] == 'completed'
            
            # Check GC metrics
            assert store.metrics['gc_runs'] > 0
            
            # Cleanup
            store.cleanup_and_shutdown()
    
    def test_disk_gc_service_cli(self):
        """Test disk GC service command line interface."""
        with tempfile.TemporaryDirectory() as temp_dir:
            # Create feature store and add entries
            store = OptimizedFeatureStore(root=temp_dir, enable_gc=False)
            
            test_df = self.create_large_dataset(1000)
            
            def compute_features(raw_df, config):
                return raw_df.copy()
            
            config = {'test': True}
            store.get_or_compute('TEST', test_df, config, compute_features)
            
            # Test overview functionality
            gc = DiskGarbageCollector(cache_root=temp_dir, dry_run=True)
            overview = gc.get_cache_overview()
            
            assert 'cache_root' in overview
            assert 'manifest_entries' in overview
            assert overview['manifest_entries'] > 0
            assert 'total_size_mb' in overview
    
    def test_concurrent_cache_access(self):
        """Test concurrent access to cache from multiple threads."""
        with tempfile.TemporaryDirectory() as temp_dir:
            store = OptimizedFeatureStore(root=temp_dir)
            
            test_df = self.create_large_dataset(5000)
            
            def compute_features(raw_df, config):
                # Simulate computation time
                time.sleep(0.05)
                result = raw_df.copy()
                result['computed'] = True
                return result
            
            def worker_thread(thread_id: int, iterations: int):
                results = []
                for i in range(iterations):
                    try:
                        config = {'thread_id': thread_id, 'iteration': i}
                        symbol = f'THREAD_{thread_id}_ITER_{i}'
                        result = store.get_or_compute(symbol, test_df, config, compute_features)
                        results.append({
                            'thread_id': thread_id,
                            'iteration': i,
                            'success': True,
                            'rows': len(result)
                        })
                    except Exception as e:
                        results.append({
                            'thread_id': thread_id,
                            'iteration': i,
                            'success': False,
                            'error': str(e)
                        })
                return results
            
            # Run concurrent workers
            num_threads = 3
            iterations_per_thread = 3
            
            with ThreadPoolExecutor(max_workers=num_threads) as executor:
                futures = [
                    executor.submit(worker_thread, thread_id, iterations_per_thread)
                    for thread_id in range(num_threads)
                ]
                
                all_results = []
                for future in as_completed(futures):
                    all_results.extend(future.result())
            
            # Check results
            successful = [r for r in all_results if r['success']]
            failed = [r for r in all_results if not r['success']]
            
            expected_total = num_threads * iterations_per_thread
            assert len(successful) == expected_total, f"Expected {expected_total} successful, got {len(successful)}. Failed: {failed}"
            
            # Verify cache stats
            stats = store.get_cache_stats()
            assert stats['total_entries'] == expected_total


@pytest.mark.skipif(not OPTIMIZATIONS_AVAILABLE, reason="Optimization modules not available")
class TestProductionOptimizations:
    """Test production-grade optimizations."""
    
    def test_memory_efficient_large_dataset_processing(self):
        """Test memory efficiency with very large datasets."""
        with tempfile.TemporaryDirectory() as temp_dir:
            store = OptimizedFeatureStore(
                root=temp_dir,
                tick_data_threshold_mb=0.1  # Very low threshold for testing
            )
            
            # Create dataset that would be large in parquet format
            rows = 10000
            np.random.seed(42)
            
            # Create wide dataset (many columns)
            data = {}
            for i in range(50):  # 50 columns
                data[f'feature_{i}'] = np.random.randn(rows)
            
            timestamps = pd.date_range('2024-01-01', periods=rows, freq='1s')
            df = pd.DataFrame(data, index=timestamps)
            
            def compute_features(raw_df, config):
                # Simulate feature computation
                result = raw_df.copy()
                result['computed_feature'] = result.mean(axis=1)
                return result
            
            config = {'wide_features': True}
            
            # This should trigger footer hashing optimization
            result = store.get_or_compute('WIDE_DATA', df, config, compute_features)
            
            assert result is not None
            assert len(result) == rows
            assert 'computed_feature' in result.columns
            
            # Verify optimization was used
            assert store.metrics['hash_optimizations'] > 0
    
    def test_database_locking_under_stress(self):
        """Test database locking under high concurrent load."""
        with tempfile.TemporaryDirectory() as temp_dir:
            store = OptimizedFeatureStore(root=temp_dir, max_workers=10)
            
            test_df = pd.DataFrame({
                'price': np.random.randn(1000),
                'volume': np.random.randint(100, 1000, 1000)
            }, index=pd.date_range('2024-01-01', periods=1000, freq='1s'))
            
            def compute_features(raw_df, config):
                time.sleep(0.01)  # Small delay to increase contention
                return raw_df.copy()
            
            def stress_worker(worker_id: int):
                results = []
                for i in range(10):  # Each worker does 10 operations
                    try:
                        config = {'worker': worker_id, 'op': i}
                        symbol = f'STRESS_{worker_id}_{i}'
                        result = store.get_or_compute(symbol, test_df, config, compute_features)
                        results.append(True)
                    except Exception as e:
                        print(f"Worker {worker_id} operation {i} failed: {e}")
                        results.append(False)
                return results
            
            # High concurrency stress test
            num_workers = 20
            with ThreadPoolExecutor(max_workers=num_workers) as executor:
                futures = [executor.submit(stress_worker, i) for i in range(num_workers)]
                all_results = []
                for future in as_completed(futures):
                    all_results.extend(future.result())
            
            # All operations should succeed
            success_rate = sum(all_results) / len(all_results)
            assert success_rate > 0.95, f"Success rate too low: {success_rate:.2%}"
            
            # Verify final state
            stats = store.get_cache_stats()
            assert stats['total_entries'] > 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])