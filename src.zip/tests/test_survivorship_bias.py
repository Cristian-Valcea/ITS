# tests/test_survivorship_bias.py
"""
Test suite for survivorship bias elimination components.
"""
import sys
import pathlib
import tempfile
import os
import unittest
from datetime import datetime, timedelta

# Add project root to path
project_root = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(project_root / "src"))

from data.survivorship_bias_handler import (
    SurvivorshipBiasHandler, 
    DelistingEvent, 
    DelistingReason,
    create_sample_delisting_data
)


class TestSurvivorshipBiasHandler(unittest.TestCase):
    """Test cases for SurvivorshipBiasHandler."""
    
    def setUp(self):
        """Set up test database."""
        self.temp_db = tempfile.NamedTemporaryFile(suffix='.db', delete=False)
        self.db_path = self.temp_db.name
        self.temp_db.close()
        
        self.handler = SurvivorshipBiasHandler(self.db_path)
        
        # Add sample delisting events
        self.sample_events = create_sample_delisting_data()
        for event in self.sample_events:
            self.handler.add_delisting_event(event)
    
    def tearDown(self):
        """Clean up test database."""
        self.handler.close()
        if os.path.exists(self.db_path):
            os.unlink(self.db_path)
    
    def test_add_delisting_event(self):
        """Test adding delisting events."""
        event = DelistingEvent(
            symbol="TEST",
            delist_date=datetime(2020, 1, 1),
            reason_code=DelistingReason.BANKRUPTCY.value,
            reason_desc="Test bankruptcy",
            final_price=0.0,
            recovery_rate=0.0
        )
        
        result = self.handler.add_delisting_event(event)
        self.assertTrue(result)
        
        # Verify event was added
        events = self.handler.get_delisting_events(symbol="TEST")
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0].symbol, "TEST")
    
    def test_is_symbol_active(self):
        """Test symbol activity checking."""
        # ENRN delisted on 2001-11-28
        self.assertTrue(self.handler.is_symbol_active("ENRN", datetime(2001, 11, 27)))
        self.assertFalse(self.handler.is_symbol_active("ENRN", datetime(2001, 11, 29)))
        
        # Non-existent symbol should be active
        self.assertTrue(self.handler.is_symbol_active("AAPL", datetime(2020, 1, 1)))
    
    def test_point_in_time_universe(self):
        """Test point-in-time universe construction."""
        test_universe = {"AAPL", "GOOGL", "ENRN", "LEH", "BEAR"}
        
        # Test before major delistings (2008-01-01)
        snapshot_2008 = self.handler.get_point_in_time_universe(
            as_of_date=datetime(2008, 1, 1),
            base_universe=test_universe
        )
        
        # ENRN should be delisted by 2008, but LEH and BEAR should be active
        self.assertNotIn("ENRN", snapshot_2008.active_symbols)
        self.assertIn("LEH", snapshot_2008.active_symbols)
        self.assertIn("BEAR", snapshot_2008.active_symbols)
        
        # Test after financial crisis (2009-01-01)
        snapshot_2009 = self.handler.get_point_in_time_universe(
            as_of_date=datetime(2009, 1, 1),
            base_universe=test_universe
        )
        
        # LEH and BEAR should be delisted by 2009
        self.assertNotIn("LEH", snapshot_2009.active_symbols)
        self.assertNotIn("BEAR", snapshot_2009.active_symbols)
        
        # Survival rate should be lower in 2009
        self.assertLess(snapshot_2009.survivorship_rate, snapshot_2008.survivorship_rate)
    
    def test_get_delisting_events(self):
        """Test retrieving delisting events."""
        # Get all events
        all_events = self.handler.get_delisting_events()
        self.assertEqual(len(all_events), len(self.sample_events))
        
        # Get events for specific symbol
        enrn_events = self.handler.get_delisting_events(symbol="ENRN")
        self.assertEqual(len(enrn_events), 1)
        self.assertEqual(enrn_events[0].symbol, "ENRN")
        
        # Get events in date range
        crisis_events = self.handler.get_delisting_events(
            start_date=datetime(2008, 1, 1),
            end_date=datetime(2008, 12, 31)
        )
        # Should include BEAR and LEH
        crisis_symbols = {event.symbol for event in crisis_events}
        self.assertIn("BEAR", crisis_symbols)
        self.assertIn("LEH", crisis_symbols)
    
    def test_generate_bias_report(self):
        """Test bias report generation."""
        test_universe = {"AAPL", "GOOGL", "ENRN", "WCOM", "LEH", "BEAR"}
        
        report = self.handler.generate_bias_report(
            start_date=datetime(2000, 1, 1),
            end_date=datetime(2010, 1, 1),
            base_universe=test_universe
        )
        
        # Check report structure
        self.assertIn('universe_stats', report)
        self.assertIn('delisting_breakdown', report)
        self.assertIn('recommendations', report)
        
        # Check universe stats
        stats = report['universe_stats']
        self.assertEqual(stats['total_symbols'], len(test_universe))
        self.assertGreater(stats['delisted_symbols'], 0)
        self.assertLess(stats['survivorship_rate'], 1.0)
        
        # Check delisting breakdown
        breakdown = report['delisting_breakdown']
        self.assertIn(DelistingReason.BANKRUPTCY.value, breakdown)
        self.assertIn(DelistingReason.MERGER.value, breakdown)
    
    def test_statistics(self):
        """Test handler statistics."""
        stats = self.handler.get_statistics()
        
        self.assertIn('total_delisting_events', stats)
        self.assertIn('reason_breakdown', stats)
        self.assertEqual(stats['total_delisting_events'], len(self.sample_events))
        
        # Check reason breakdown
        breakdown = stats['reason_breakdown']
        self.assertGreater(len(breakdown), 0)


class TestDelistingEvent(unittest.TestCase):
    """Test cases for DelistingEvent dataclass."""
    
    def test_delisting_event_creation(self):
        """Test creating delisting events."""
        event = DelistingEvent(
            symbol="TEST",
            delist_date=datetime(2020, 1, 1),
            reason_code="100",
            reason_desc="Test bankruptcy",
            final_price=0.50,
            recovery_rate=0.10
        )
        
        self.assertEqual(event.symbol, "TEST")
        self.assertEqual(event.reason_code, "100")
        self.assertEqual(event.final_price, 0.50)
        self.assertEqual(event.recovery_rate, 0.10)
        self.assertIsNotNone(event.created_at)
    
    def test_merger_event(self):
        """Test merger delisting event."""
        event = DelistingEvent(
            symbol="TARGET",
            delist_date=datetime(2020, 1, 1),
            reason_code="200",
            reason_desc="Acquired by ACQUIRER",
            acquirer_symbol="ACQUIRER",
            exchange_ratio=0.5
        )
        
        self.assertEqual(event.acquirer_symbol, "ACQUIRER")
        self.assertEqual(event.exchange_ratio, 0.5)


def run_integration_test():
    """Run a simple integration test."""
    print("Running survivorship bias integration test...")
    
    # Create temporary database
    with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
        db_path = f.name
    
    try:
        # Initialize handler
        handler = SurvivorshipBiasHandler(db_path)
        
        # Add sample data
        events = create_sample_delisting_data()
        for event in events:
            handler.add_delisting_event(event)
        
        print(f"✅ Added {len(events)} delisting events")
        
        # Test point-in-time universe
        test_universe = {"AAPL", "GOOGL", "MSFT", "ENRN", "WCOM", "LEH", "BEAR"}
        
        snapshot = handler.get_point_in_time_universe(
            as_of_date=datetime(2008, 1, 1),
            base_universe=test_universe
        )
        
        print(f"✅ Point-in-time universe: {len(snapshot.active_symbols)}/{len(test_universe)} active")
        print(f"✅ Survival rate: {snapshot.survivorship_rate:.1%}")
        
        # Generate bias report
        report = handler.generate_bias_report(
            start_date=datetime(2000, 1, 1),
            end_date=datetime(2010, 1, 1),
            base_universe=test_universe
        )
        
        print(f"✅ Bias report generated:")
        print(f"   Total symbols: {report['universe_stats']['total_symbols']}")
        print(f"   Delisted: {report['universe_stats']['delisted_symbols']}")
        print(f"   Survival rate: {report['universe_stats']['survivorship_rate']:.1%}")
        
        handler.close()
        print("✅ Integration test completed successfully!")
        
    finally:
        if os.path.exists(db_path):
            os.unlink(db_path)


if __name__ == "__main__":
    # Run integration test first
    run_integration_test()
    
    print("\nRunning unit tests...")
    unittest.main(verbosity=2)