import numpy as np, asyncio, pytest
from risk.agent.risk_agent_v2 import RiskAgentV2
from risk.event_bus import RiskEventBus, RiskEvent, EventType, EventPriority

@pytest.mark.asyncio
async def test_market_crash_scenario():
    bus = RiskEventBus()
    agent = RiskAgentV2.default()           # add a @classmethod that wires calculators + policy
    bus.register_handler(agent)

    # craft a synthetic 8 % down-tick that breaches VaR
    crash_prices = np.linspace(100, 92, 252)
    event = RiskEvent(
        event_type   = EventType.MARKET_DATA,
        priority     = EventPriority.HIGH,
        source       = "test",
        data         = {"price_series": crash_prices}
    )
    await bus.publish(event)
    await asyncio.sleep(0.05)               # give handlers time

    kill_events = [e for e in bus.flushed_events
                     if e.event_type == EventType.KILL_SWITCH]
    assert kill_events, "Expected kill-switch on crash scenario"

