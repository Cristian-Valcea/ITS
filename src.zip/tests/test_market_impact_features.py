"""
Test suite for market impact features implementation.

Tests cover:
1. Basic market impact feature calculations
2. Feature calculator integration
3. Live data processing performance
4. Risk integration
5. End-to-end integration
"""

import pytest
import pandas as pd
import numpy as np
import time
from unittest.mock import Mock, patch

# Import modules to test
from src.shared.market_impact import (
    calc_market_impact_features,
    calc_market_impact_features_fast,
    validate_book_data,
    get_available_levels
)
from src.features.market_impact_calculator import MarketImpactCalculator
from src.execution.core.live_data_loader import LiveDataLoader
from src.risk.calculators.market_impact_calculator import MarketImpactRiskCalculator


class TestMarketImpactFeatures:
    """Test basic market impact feature calculations."""
    
    def test_impact_feature_basic(self):
        """Test basic market impact calculation as specified in requirements."""
        # Sample data from requirements
        book = pd.Series({
            "bid_px1": 1.1998, "bid_sz1": 500_000,
            "ask_px1": 1.2000, "ask_sz1": 400_000
        })
        mid = 1.1999
        
        features = calc_market_impact_features(book, mid)
        
        # Test spread calculation
        expected_spread = (1.2000 - 1.1998) / 1.1999 * 10_000
        assert abs(features["spread_bps"] - expected_spread) < 0.01
        
        # Test queue imbalance bounds
        assert -1 <= features["queue_imbalance"] <= 1
        
        # Test that all features are present
        assert "spread_bps" in features
        assert "queue_imbalance" in features
        assert "impact_10k" in features
        assert "kyle_lambda" in features
    
    def test_spread_calculation(self):
        """Test spread calculation accuracy."""
        book = pd.Series({
            "bid_px1": 100.0, "bid_sz1": 1000,
            "ask_px1": 100.2, "ask_sz1": 1000
        })
        mid = 100.1
        
        features = calc_market_impact_features(book, mid)
        
        # Spread should be (100.2 - 100.0) / 100.1 * 10000 = 19.98 bps
        expected_spread = 0.2 / 100.1 * 10_000
        assert abs(features["spread_bps"] - expected_spread) < 0.01
    
    def test_queue_imbalance_calculation(self):
        """Test queue imbalance calculation."""
        # Balanced book
        book_balanced = pd.Series({
            "bid_px1": 100.0, "bid_sz1": 1000,
            "ask_px1": 100.1, "ask_sz1": 1000
        })
        features = calc_market_impact_features(book_balanced, 100.05)
        assert abs(features["queue_imbalance"]) < 0.01
        
        # Bid-heavy book
        book_bid_heavy = pd.Series({
            "bid_px1": 100.0, "bid_sz1": 2000,
            "ask_px1": 100.1, "ask_sz1": 1000
        })
        features = calc_market_impact_features(book_bid_heavy, 100.05)
        assert features["queue_imbalance"] > 0  # Positive imbalance
        
        # Ask-heavy book
        book_ask_heavy = pd.Series({
            "bid_px1": 100.0, "bid_sz1": 1000,
            "ask_px1": 100.1, "ask_sz1": 2000
        })
        features = calc_market_impact_features(book_ask_heavy, 100.05)
        assert features["queue_imbalance"] < 0  # Negative imbalance
    
    def test_market_impact_calculation(self):
        """Test market impact calculation for different notionals."""
        # Multi-level book
        book = pd.Series({
            "bid_px1": 100.0, "bid_sz1": 1000,
            "ask_px1": 100.1, "ask_sz1": 1000,
            "bid_px2": 99.9, "bid_sz2": 2000,
            "ask_px2": 100.2, "ask_sz2": 2000,
        })
        mid = 100.05
        
        # Small notional should have minimal impact
        features_small = calc_market_impact_features(book, mid, notional=1_000)
        
        # Large notional should have higher impact
        features_large = calc_market_impact_features(book, mid, notional=50_000)
        
        assert features_large["impact_10k"] >= features_small["impact_10k"]
    
    def test_kyle_lambda_calculation(self):
        """Test Kyle's lambda calculation."""
        book = pd.Series({
            "bid_px1": 100.0, "bid_sz1": 1000,
            "ask_px1": 100.1, "ask_sz1": 1000
        })
        
        # Without previous data, Kyle's lambda should be NaN
        features = calc_market_impact_features(book, 100.05)
        assert np.isnan(features["kyle_lambda"])
        
        # With previous data
        features = calc_market_impact_features(
            book, 100.05, last_mid=100.0, signed_vol=1000
        )
        assert not np.isnan(features["kyle_lambda"])
        assert features["kyle_lambda"] > 0
    
    def test_invalid_data_handling(self):
        """Test handling of invalid or missing data."""
        # Empty book
        empty_book = pd.Series({})
        features = calc_market_impact_features(empty_book, 100.0)
        assert features["spread_bps"] == 0.0
        assert features["queue_imbalance"] == 0.0
        
        # Invalid prices
        invalid_book = pd.Series({
            "bid_px1": -1.0, "bid_sz1": 1000,
            "ask_px1": 0.0, "ask_sz1": 1000
        })
        features = calc_market_impact_features(invalid_book, 100.0)
        assert features["spread_bps"] == 0.0


class TestMarketImpactCalculator:
    """Test the feature calculator integration."""
    
    def test_calculator_initialization(self):
        """Test calculator initialization."""
        config = {
            'notional_amount': 10_000,
            'enable_kyle_lambda': True
        }
        
        calculator = MarketImpactCalculator(config)
        assert calculator.name == "market_impact"
        assert calculator.notional_amount == 10_000
        assert calculator.enable_kyle_lambda is True
    
    def test_calculator_feature_computation(self):
        """Test feature computation through calculator."""
        config = {'notional_amount': 10_000}
        calculator = MarketImpactCalculator(config)
        
        # Create test data
        df = pd.DataFrame({
            'bid_px1': [100.0, 100.1],
            'bid_sz1': [1000, 1100],
            'ask_px1': [100.1, 100.2],
            'ask_sz1': [1000, 1200],
            'mid': [100.05, 100.15]
        })
        
        result = calculator.calculate(df)
        
        # Check that features were added
        assert 'spread_bps' in result.columns
        assert 'queue_imbalance' in result.columns
        assert 'impact_10k' in result.columns
        assert 'kyle_lambda' in result.columns
        
        # Check that values are reasonable
        assert all(result['spread_bps'] >= 0)
        assert all(abs(result['queue_imbalance']) <= 1)
    
    def test_calculator_missing_columns(self):
        """Test calculator behavior with missing columns."""
        config = {}
        calculator = MarketImpactCalculator(config)
        
        # DataFrame without required columns
        df = pd.DataFrame({
            'price': [100.0, 100.1],
            'volume': [1000, 1100]
        })
        
        result = calculator.calculate(df)
        
        # Should return original DataFrame with default features
        assert 'spread_bps' in result.columns
        assert all(result['spread_bps'] == 0.0)


class TestLiveDataProcessing:
    """Test live data processing performance and functionality."""
    
    def test_fast_calculation_performance(self):
        """Test that fast calculation meets latency requirements (<10 μs)."""
        # Test data
        bid_px1, bid_sz1 = 100.0, 1000
        ask_px1, ask_sz1 = 100.1, 1000
        mid = 100.05
        
        # Warm up
        for _ in range(100):
            calc_market_impact_features_fast(bid_px1, bid_sz1, ask_px1, ask_sz1, mid)
        
        # Time the calculation
        start_time = time.perf_counter_ns()
        for _ in range(1000):
            spread_bps, queue_imbalance = calc_market_impact_features_fast(
                bid_px1, bid_sz1, ask_px1, ask_sz1, mid
            )
        end_time = time.perf_counter_ns()
        
        # Calculate average time per call in microseconds
        avg_time_us = (end_time - start_time) / 1000 / 1000
        
        print(f"Average fast calculation time: {avg_time_us:.2f} μs")
        assert avg_time_us < 10.0, f"Fast calculation too slow: {avg_time_us:.2f} μs"
        
        # Verify results are reasonable
        assert 0 <= spread_bps <= 1000
        assert -1 <= queue_imbalance <= 1
    
    def test_live_data_loader_integration(self):
        """Test live data loader market impact processing."""
        config = {'cache_dir': 'test_cache'}
        loader = LiveDataLoader(config)
        
        # Mock order book snapshot
        book_snapshot = {
            'bid_px1': 100.0, 'bid_sz1': 1000,
            'ask_px1': 100.1, 'ask_sz1': 1200,
            'bid_px2': 99.9, 'bid_sz2': 2000,
            'ask_px2': 100.2, 'ask_sz2': 1800
        }
        
        # Test fast processing (critical path)
        features = loader.process_live_market_data(book_snapshot, "TEST", include_heavy_features=False)
        
        assert 'spread_bps' in features
        assert 'queue_imbalance' in features
        assert 'mid' in features
        assert 'impact_10k' not in features  # Should not be included in fast mode
        
        # Test full processing (monitoring path)
        features_full = loader.process_live_market_data(book_snapshot, "TEST", include_heavy_features=True)
        
        assert 'spread_bps' in features_full
        assert 'queue_imbalance' in features_full
        assert 'impact_10k' in features_full
        assert 'kyle_lambda' in features_full


class TestRiskIntegration:
    """Test risk system integration."""
    
    def test_market_impact_risk_calculator(self):
        """Test market impact risk calculator."""
        config = {
            'max_spread_bps': 50.0,
            'max_impact_threshold': 0.001,
            'min_queue_balance': -0.8,
            'max_queue_balance': 0.8
        }
        
        calculator = MarketImpactRiskCalculator(config)
        
        # Test low risk scenario
        low_risk_data = {
            'spread_bps': 10.0,
            'queue_imbalance': 0.1,
            'impact_10k': 0.0005,
            'kyle_lambda': 1e-7
        }
        
        result = calculator.calculate(low_risk_data)
        assert result['risk_level'] == 'LOW'
        assert result['action'] == 'ALLOW'
        
        # Test high risk scenario
        high_risk_data = {
            'spread_bps': 100.0,  # Above threshold
            'queue_imbalance': 0.9,  # Above threshold
            'impact_10k': 0.002,  # Above threshold
            'kyle_lambda': 1e-5  # Above threshold
        }
        
        result = calculator.calculate(high_risk_data)
        assert result['risk_level'] == 'HIGH'
        assert result['action'] == 'THROTTLE'
    
    def test_risk_score_calculation(self):
        """Test risk score calculation."""
        config = {
            'max_spread_bps': 50.0,
            'max_impact_threshold': 0.001
        }
        
        calculator = MarketImpactRiskCalculator(config)
        
        # Test zero risk
        zero_risk_data = {
            'spread_bps': 0.0,
            'queue_imbalance': 0.0,
            'impact_10k': 0.0,
            'kyle_lambda': 0.0
        }
        
        result = calculator.calculate(zero_risk_data)
        assert result['risk_score'] == 0.0
        
        # Test maximum risk
        max_risk_data = {
            'spread_bps': 100.0,  # 2x threshold
            'queue_imbalance': 1.0,  # Maximum imbalance
            'impact_10k': 0.002,  # 2x threshold
            'kyle_lambda': 2e-6  # 2x threshold
        }
        
        result = calculator.calculate(max_risk_data)
        assert result['risk_score'] >= 80.0  # Should be high risk score


class TestDataValidation:
    """Test data validation and utility functions."""
    
    def test_book_data_validation(self):
        """Test order book data validation."""
        # Valid book data
        valid_book = pd.Series({
            "bid_px1": 100.0, "bid_sz1": 1000,
            "ask_px1": 100.1, "ask_sz1": 1000
        })
        assert validate_book_data(valid_book) is True
        
        # Invalid book data (missing columns)
        invalid_book = pd.Series({
            "price": 100.0, "volume": 1000
        })
        assert validate_book_data(invalid_book) is False
    
    def test_available_levels_detection(self):
        """Test detection of available order book levels."""
        # Single level book
        single_level = pd.Series({
            "bid_px1": 100.0, "bid_sz1": 1000,
            "ask_px1": 100.1, "ask_sz1": 1000
        })
        assert get_available_levels(single_level) == 1
        
        # Multi-level book
        multi_level = pd.Series({
            "bid_px1": 100.0, "bid_sz1": 1000,
            "ask_px1": 100.1, "ask_sz1": 1000,
            "bid_px2": 99.9, "bid_sz2": 2000,
            "ask_px2": 100.2, "ask_sz2": 2000,
            "bid_px3": 99.8, "bid_sz3": 3000,
            "ask_px3": 100.3, "ask_sz3": 3000
        })
        assert get_available_levels(multi_level) == 3


class TestEndToEndIntegration:
    """Test end-to-end integration scenarios."""
    
    def test_data_agent_enhancement(self):
        """Test DataAgent order book enhancement."""
        # This would require mocking the DataAgent
        # For now, test the enhancement logic directly
        
        # Sample OHLCV data
        ohlcv_data = pd.DataFrame({
            'Open': [100.0, 100.1],
            'High': [100.2, 100.3],
            'Low': [99.8, 99.9],
            'Close': [100.1, 100.2],
            'Volume': [10000, 12000]
        })
        
        # Mock DataAgent enhancement
        from src.agents.data_agent import DataAgent
        
        # This would be tested with proper mocking in a real scenario
        # For now, verify the enhancement method exists
        config = {'data_dir_raw': 'test_data'}
        agent = DataAgent(config)
        
        assert hasattr(agent, 'enhance_data_with_order_book')
        assert hasattr(agent, '_simulate_order_book_levels')
        assert hasattr(agent, '_add_market_impact_features')
    
    def test_feature_pipeline_integration(self):
        """Test integration with feature pipeline."""
        # Test that MarketImpact calculator is registered
        from src.features import get_global_registry
        
        registry = get_global_registry()
        calculator_class = registry.get_calculator_class('MarketImpact')
        
        assert calculator_class is not None
        
        # Test calculator creation
        config = {'notional_amount': 10_000}
        calculator = registry.create_calculator('MarketImpact', config)
        
        assert calculator is not None
        assert calculator.name == 'market_impact'


# Performance test for latency requirements
def test_latency_performance():
    """Test that level-5 snapshot computation is under 10 μs."""
    # Create level-5 order book data
    book_data = {}
    for level in range(1, 6):
        book_data[f'bid_px{level}'] = 100.0 - (level - 1) * 0.01
        book_data[f'bid_sz{level}'] = 1000 * level
        book_data[f'ask_px{level}'] = 100.1 + (level - 1) * 0.01
        book_data[f'ask_sz{level}'] = 1000 * level
    
    book_series = pd.Series(book_data)
    mid = 100.05
    
    # Warm up
    for _ in range(100):
        calc_market_impact_features(book_series, mid)
    
    # Time the calculation
    start_time = time.perf_counter_ns()
    for _ in range(1000):
        features = calc_market_impact_features(book_series, mid)
    end_time = time.perf_counter_ns()
    
    # Calculate average time per call in microseconds
    avg_time_us = (end_time - start_time) / 1000 / 1000
    
    print(f"Average level-5 calculation time: {avg_time_us:.2f} μs")
    assert avg_time_us < 10.0, f"Level-5 calculation too slow: {avg_time_us:.2f} μs"


if __name__ == "__main__":
    # Run basic tests
    pytest.main([__file__, "-v"])