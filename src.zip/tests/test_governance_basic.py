# tests/test_governance_basic.py
"""
Basic governance system validation tests.
"""

import pytest
import tempfile
import pandas as pd
import numpy as np
from datetime import datetime, timezone
from pathlib import Path
import sys
import os

# Add src to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

try:
    from governance.audit_immutable import ImmutableAuditSink
    from governance.model_lineage import DatasetHasher, ModelLineageTracker
    from governance.release_approval import FourEyesReleaseGate, ApprovalType
    GOVERNANCE_AVAILABLE = True
except ImportError as e:
    GOVERNANCE_AVAILABLE = False
    print(f"Governance modules not available: {e}")


@pytest.mark.skipif(not GOVERNANCE_AVAILABLE, reason="Governance modules not available")
class TestGovernanceBasic:
    """Basic governance system tests."""
    
    def test_dataset_hashing(self):
        """Test basic dataset hashing functionality."""
        # Create sample dataset
        np.random.seed(42)
        data = {
            'price': [100, 101, 99, 102, 98],
            'volume': [1000, 1100, 900, 1200, 800]
        }
        df = pd.DataFrame(data)
        
        # Hash dataset
        hasher = DatasetHasher()
        fingerprint = hasher.hash_dataframe(df, "test_dataset")
        
        assert fingerprint.dataset_name == "test_dataset"
        assert len(fingerprint.sha256_hash) == 64  # SHA-256 length
        assert fingerprint.row_count == 5
        assert fingerprint.column_count == 2
        assert 'price' in fingerprint.columns
        assert 'volume' in fingerprint.columns
        
        # Hash should be deterministic
        fingerprint2 = hasher.hash_dataframe(df, "test_dataset")
        assert fingerprint.sha256_hash == fingerprint2.sha256_hash
    
    @pytest.mark.asyncio
    async def test_immutable_audit_basic(self):
        """Test basic immutable audit functionality."""
        with tempfile.TemporaryDirectory() as temp_dir:
            config = {
                's3_worm_enabled': False,
                'kafka_enabled': False,
                'local_worm_path': temp_dir
            }
            
            audit_sink = ImmutableAuditSink(config)
            
            # Write audit record
            record_hash = await audit_sink.write_audit_record(
                event_type="TEST_EVENT",
                component="TestComponent",
                user_id="test_user",
                session_id="test_session",
                action="TEST_ACTION",
                details={'test': 'data'},
                risk_impact="LOW"
            )
            
            assert record_hash is not None
            assert len(record_hash) == 64  # SHA-256 hash
    
    def test_model_lineage_basic(self):
        """Test basic model lineage functionality."""
        with tempfile.TemporaryDirectory() as temp_dir:
            lineage_tracker = ModelLineageTracker(temp_dir)
            
            # Start training session
            model_id = lineage_tracker.start_training_session(
                model_name="test_model",
                model_type="test",
                training_config={'test': True},
                created_by="test_user"
            )
            
            assert model_id is not None
            assert "test_model" in model_id
            
            # Check session directory was created
            session_dir = Path(temp_dir) / model_id
            assert session_dir.exists()
            
            # Check session info file
            session_info_file = session_dir / "session_info.json"
            assert session_info_file.exists()
    
    @pytest.mark.asyncio
    async def test_approval_system_basic(self):
        """Test basic approval system functionality."""
        with tempfile.TemporaryDirectory() as temp_dir:
            config = {
                'storage_path': temp_dir,
                'github_enabled': False,
                'servicenow_enabled': False,
                'approval_groups': {
                    'test_group': ['test_user1', 'test_user2']
                },
                'approval_policies': {
                    'MODEL_DEPLOYMENT': {
                        'minimum_approvals': 1,
                        'required_approvers': [],
                        'approval_groups': ['test_group'],
                        'expires_hours': 24
                    }
                }
            }
            
            release_gate = FourEyesReleaseGate(config)
            
            # Create approval request
            request_id = await release_gate.create_approval_request(
                approval_type=ApprovalType.MODEL_DEPLOYMENT,
                title="Test Deployment",
                description="Test deployment request",
                requested_by="test_requester",
                change_details={'test': 'deployment'}
            )
            
            assert request_id is not None
            assert "MODEL_DEPLOYMENT" in request_id
            
            # Check request was created
            request = await release_gate.get_approval_status(request_id)
            assert request is not None
            assert request.title == "Test Deployment"


def test_governance_imports():
    """Test that governance modules can be imported."""
    try:
        from governance.audit_immutable import ImmutableAuditSink
        from governance.model_lineage import DatasetHasher
        from governance.release_approval import FourEyesReleaseGate
        assert True
    except ImportError:
        pytest.skip("Governance modules not available")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])