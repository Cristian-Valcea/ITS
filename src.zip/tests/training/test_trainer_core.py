#!/usr/bin/env python3
"""
Unit tests for TrainerCore component.

Tests the core training functionality including:
- Model creation and management
- Training orchestration
- Risk advisor integration
- Hardware optimization
- Training state management
"""

import pytest
from unittest.mock import MagicMock, patch
from datetime import datetime
import tempfile
import shutil
from pathlib import Path

# Import the module under test
try:
    from src.training.core.trainer_core import TrainerCore
except ImportError:
    # Fallback for testing without full dependencies
    TrainerCore = None

@pytest.fixture
def mock_config():
    """Mock configuration for TrainerCore."""
    return {
        'algorithm': 'DQN',
        'model_save_dir': 'test_models',
        'log_dir': 'test_logs',
        'algo_params': {
            'learning_rate': 0.001,
            'buffer_size': 10000,
            'batch_size': 32
        },
        'training_params': {
            'total_timesteps': 1000,
            'checkpoint_freq': 100,
            'log_interval': 10
        },
        'risk_config': {
            'enabled': True,
            'penalty_weight': 0.1,
            'early_stop_threshold': 0.8
        }
    }

@pytest.fixture
def temp_dirs():
    """Create temporary directories for testing."""
    temp_dir = Path(tempfile.mkdtemp())
    model_dir = temp_dir / "models"
    log_dir = temp_dir / "logs"
    
    model_dir.mkdir()
    log_dir.mkdir()
    
    yield {
        'temp_dir': temp_dir,
        'model_dir': model_dir,
        'log_dir': log_dir
    }
    
    # Cleanup
    shutil.rmtree(temp_dir, ignore_errors=True)

@pytest.mark.skipif(TrainerCore is None, reason="TrainerCore not available")
class TestTrainerCore:
    """Test suite for TrainerCore."""
    
    def test_initialization(self, mock_config):
        """Test TrainerCore initialization."""
        core = TrainerCore(mock_config)
        
        assert core.config == mock_config
        assert core.algorithm_name == 'DQN'
        assert core.model is None
        assert core.training_env is None
        assert core.risk_advisor is None
    
    def test_algorithm_validation(self):
        """Test algorithm validation."""
        # Test valid algorithm
        valid_config = {'algorithm': 'DQN', 'algo_params': {}, 'training_params': {}}
        core = TrainerCore(valid_config)
        assert core.algorithm_name == 'DQN'
        
        # Test invalid algorithm
        invalid_config = {'algorithm': 'INVALID', 'algo_params': {}, 'training_params': {}}
        with pytest.raises(ValueError, match="Unsupported algorithm"):
            TrainerCore(invalid_config)
    
    def test_hardware_info_logging(self, mock_config):
        """Test hardware info logging."""
        core = TrainerCore(mock_config)
        
        with patch.object(core.logger, 'info') as mock_log:
            core.log_hardware_info()
            
            # Should log CPU, memory, and GPU info
            assert mock_log.call_count >= 3
            
            # Check for expected log messages
            log_calls = [call[0][0] for call in mock_log.call_args_list]
            assert any('CPU' in msg for msg in log_calls)
            assert any('Memory' in msg for msg in log_calls)
    
    def test_model_creation(self, mock_config, temp_dirs):
        """Test model creation."""
        mock_config['model_save_dir'] = str(temp_dirs['model_dir'])
        mock_config['log_dir'] = str(temp_dirs['log_dir'])
        
        core = TrainerCore(mock_config)
        
        # Mock environment
        mock_env = MagicMock()
        mock_env.observation_space = MagicMock()
        mock_env.action_space = MagicMock()
        
        with patch('src.training.core.trainer_core.DQN') as mock_dqn:
            mock_model = MagicMock()
            mock_dqn.return_value = mock_model
            
            model = core.create_model(mock_env)
            
            assert model is not None
            assert core.model == model
            mock_dqn.assert_called_once()
    
    def test_risk_advisor_integration(self, mock_config):
        """Test risk advisor integration."""
        core = TrainerCore(mock_config)
        
        # Mock risk advisor
        mock_risk_advisor = MagicMock()
        mock_risk_advisor.evaluate.return_value = {'overall_risk': 0.3}
        
        core.set_risk_advisor(mock_risk_advisor)
        assert core.risk_advisor == mock_risk_advisor
        
        # Test risk evaluation
        mock_obs = {'observation': [1, 2, 3]}
        risk_score = core.evaluate_risk(mock_obs)
        
        assert risk_score == 0.3
        mock_risk_advisor.evaluate.assert_called_once_with(mock_obs)
    
    def test_training_state_management(self, mock_config, temp_dirs):
        """Test training state management."""
        mock_config['model_save_dir'] = str(temp_dirs['model_dir'])
        
        core = TrainerCore(mock_config)
        
        # Test state saving
        state = {
            'timesteps': 500,
            'episode': 10,
            'best_reward': 100.0
        }
        
        core.save_training_state(state)
        
        # Test state loading
        loaded_state = core.load_training_state()
        assert loaded_state == state
    
    def test_checkpoint_management(self, mock_config, temp_dirs):
        """Test checkpoint management."""
        mock_config['model_save_dir'] = str(temp_dirs['model_dir'])
        
        core = TrainerCore(mock_config)
        
        # Mock model
        mock_model = MagicMock()
        core.model = mock_model
        
        # Test checkpoint saving
        checkpoint_path = core.save_checkpoint(timesteps=500)
        
        assert checkpoint_path is not None
        assert Path(checkpoint_path).exists()
        mock_model.save.assert_called_once()
    
    def test_training_callbacks(self, mock_config):
        """Test training callbacks setup."""
        core = TrainerCore(mock_config)
        
        # Mock environment and model
        mock_env = MagicMock()
        mock_model = MagicMock()
        core.model = mock_model
        
        callbacks = core.setup_callbacks(mock_env)
        
        assert isinstance(callbacks, list)
        assert len(callbacks) > 0
    
    def test_training_orchestration(self, mock_config, temp_dirs):
        """Test training orchestration."""
        mock_config['model_save_dir'] = str(temp_dirs['model_dir'])
        mock_config['log_dir'] = str(temp_dirs['log_dir'])
        
        core = TrainerCore(mock_config)
        
        # Mock environment and model
        mock_env = MagicMock()
        mock_model = MagicMock()
        mock_model.learn.return_value = mock_model
        
        with patch.object(core, 'create_model', return_value=mock_model):
            with patch.object(core, 'setup_callbacks', return_value=[]):
                result = core.train(mock_env)
                
                assert result is not None
                mock_model.learn.assert_called_once()
    
    def test_model_evaluation(self, mock_config):
        """Test model evaluation."""
        core = TrainerCore(mock_config)
        
        # Mock model and environment
        mock_model = MagicMock()
        mock_env = MagicMock()
        core.model = mock_model
        
        # Mock evaluation results
        mock_model.predict.return_value = ([1], None)
        mock_env.step.return_value = ([0, 1, 2], 10.0, False, {})
        mock_env.reset.return_value = [0, 1, 2]
        
        metrics = core.evaluate_model(mock_env, n_episodes=1)
        
        assert 'mean_reward' in metrics
        assert 'std_reward' in metrics
        assert 'episode_lengths' in metrics
    
    def test_hyperparameter_optimization(self, mock_config):
        """Test hyperparameter optimization integration."""
        core = TrainerCore(mock_config)
        
        # Mock optimization function
        def mock_objective(trial):
            return 0.5  # Mock objective value
        
        with patch('src.training.core.trainer_core.optuna') as mock_optuna:
            mock_study = MagicMock()
            mock_study.best_params = {'learning_rate': 0.001}
            mock_optuna.create_study.return_value = mock_study
            
            best_params = core.optimize_hyperparameters(mock_objective, n_trials=10)
            
            assert best_params == {'learning_rate': 0.001}
            mock_study.optimize.assert_called_once()
    
    def test_error_handling(self, mock_config):
        """Test error handling in training."""
        core = TrainerCore(mock_config)
        
        # Test with invalid environment
        with pytest.raises(ValueError, match="Environment cannot be None"):
            core.train(None)
        
        # Test model creation failure
        mock_env = MagicMock()
        
        with patch('src.training.core.trainer_core.DQN', side_effect=Exception("Model creation failed")):
            with pytest.raises(Exception, match="Model creation failed"):
                core.create_model(mock_env)


class TestTrainerCoreMock:
    """Test suite using mock TrainerCore when real one isn't available."""
    
    def test_mock_trainer_core(self, mock_config, temp_dirs):
        """Test with mock TrainerCore."""
        # Create a simple mock
        class MockTrainerCore:
            def __init__(self, config):
                self.config = config
                self.algorithm_name = config['algorithm']
                self.model = None
                self.training_env = None
                self.risk_advisor = None
                self.logger = MagicMock()
            
            def log_hardware_info(self):
                self.logger.info("CPU: Mock CPU")
                self.logger.info("Memory: Mock Memory")
                self.logger.info("GPU: Mock GPU")
            
            def create_model(self, env):
                self.model = MagicMock()
                return self.model
            
            def set_risk_advisor(self, advisor):
                self.risk_advisor = advisor
            
            def evaluate_risk(self, obs):
                if self.risk_advisor:
                    return self.risk_advisor.evaluate(obs).get('overall_risk', 0.0)
                return 0.0
            
            def train(self, env):
                if env is None:
                    raise ValueError("Environment cannot be None")
                
                if self.model is None:
                    self.create_model(env)
                
                # Mock training
                self.model.learn(total_timesteps=1000)
                return str(temp_dirs['model_dir'] / 'final_model.zip')
            
            def evaluate_model(self, env, n_episodes=10):
                return {
                    'mean_reward': 50.0,
                    'std_reward': 10.0,
                    'episode_lengths': [100] * n_episodes
                }
            
            def save_checkpoint(self, timesteps):
                checkpoint_path = temp_dirs['model_dir'] / f'checkpoint_{timesteps}.zip'
                checkpoint_path.touch()
                return str(checkpoint_path)
        
        core = MockTrainerCore(mock_config)
        
        # Test initialization
        assert core.algorithm_name == 'DQN'
        
        # Test hardware logging
        core.log_hardware_info()
        assert core.logger.info.call_count == 3
        
        # Test model creation
        mock_env = MagicMock()
        model = core.create_model(mock_env)
        assert model is not None
        
        # Test risk advisor
        mock_risk_advisor = MagicMock()
        mock_risk_advisor.evaluate.return_value = {'overall_risk': 0.3}
        core.set_risk_advisor(mock_risk_advisor)
        
        risk_score = core.evaluate_risk({'obs': [1, 2, 3]})
        assert risk_score == 0.3
        
        # Test training
        result = core.train(mock_env)
        assert result is not None
        
        # Test evaluation
        metrics = core.evaluate_model(mock_env)
        assert metrics['mean_reward'] == 50.0
        
        # Test checkpoint
        checkpoint_path = core.save_checkpoint(500)
        assert Path(checkpoint_path).exists()


@pytest.mark.integration
class TestTrainerCoreIntegration:
    """Integration tests for TrainerCore."""
    
    @pytest.mark.skipif(TrainerCore is None, reason="TrainerCore not available")
    def test_full_training_pipeline(self, mock_config, temp_dirs):
        """Test full training pipeline integration."""
        mock_config['model_save_dir'] = str(temp_dirs['model_dir'])
        mock_config['log_dir'] = str(temp_dirs['log_dir'])
        mock_config['training_params']['total_timesteps'] = 100  # Short training
        
        # This would test with real environment and model when available
        # For now, we'll skip if components aren't available
        pytest.skip("Full integration test requires all training dependencies")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])