"""
Unit tests for fee application in PnL tracker.

Tests the venue-specific fee engine integration with the trading system.
"""

import pytest
import tempfile
import yaml
from pathlib import Path
from unittest.mock import Mock, patch

# Import the modules to test
import sys
sys.path.append('src')

from execution.core.pnl_tracker import PnLTracker
from shared.fee_schedule import FeeSchedule, Fee, calculate_cme_fee


class TestFeeSchedule:
    """Test the fee schedule engine."""
    
    def test_simple_fee_lookup(self):
        """Test basic fee lookup for CME micro futures."""
        # Create temporary fee config
        fee_config = {
            'MES': {'trade_fee': 0.35, 'currency': 'USD'},
            'MNQ': {'trade_fee': 0.47, 'currency': 'USD'},
            'DEFAULT': {'trade_fee': 1.50, 'currency': 'USD'}
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(fee_config, f)
            config_path = f.name
        
        try:
            schedule = FeeSchedule(config_path)
            
            # Test known symbols
            mes_fee = schedule.lookup('MES')
            assert mes_fee.fee_per_side == 0.35
            assert mes_fee.currency == 'USD'
            
            mnq_fee = schedule.lookup('MNQ')
            assert mnq_fee.fee_per_side == 0.47
            
            # Test unknown symbol falls back to DEFAULT
            unknown_fee = schedule.lookup('UNKNOWN')
            assert unknown_fee.fee_per_side == 1.50
            
        finally:
            Path(config_path).unlink()
    
    def test_tiered_fee_lookup(self):
        """Test tiered fee structure."""
        fee_config = {
            'MNQ': {
                'currency': 'USD',
                'tiers': [
                    {'vol': 0, 'fee': 0.47},
                    {'vol': 100000, 'fee': 0.40},
                    {'vol': 500000, 'fee': 0.35}
                ]
            },
            'DEFAULT': {'trade_fee': 1.50, 'currency': 'USD'}
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(fee_config, f)
            config_path = f.name
        
        try:
            schedule = FeeSchedule(config_path)
            
            # Test different volume tiers
            fee_low = schedule.lookup('MNQ', volume_ytd=50000)
            assert fee_low.fee_per_side == 0.47
            
            fee_mid = schedule.lookup('MNQ', volume_ytd=200000)
            assert fee_mid.fee_per_side == 0.40
            
            fee_high = schedule.lookup('MNQ', volume_ytd=600000)
            assert fee_high.fee_per_side == 0.35
            
        finally:
            Path(config_path).unlink()
    
    def test_calculate_total_fee(self):
        """Test total fee calculation."""
        fee_config = {
            'MES': {'trade_fee': 0.35, 'currency': 'USD'},
            'DEFAULT': {'trade_fee': 1.50, 'currency': 'USD'}
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(fee_config, f)
            config_path = f.name
        
        try:
            schedule = FeeSchedule(config_path)
            
            # Test fee calculation
            total_fee = schedule.calculate_total_fee('MES', quantity=10)
            assert total_fee == 3.5  # 10 contracts × $0.35
            
            # Test with negative quantity (should use absolute value)
            total_fee_neg = schedule.calculate_total_fee('MES', quantity=-5)
            assert total_fee_neg == 1.75  # 5 contracts × $0.35
            
        finally:
            Path(config_path).unlink()


class TestPnLTrackerFees:
    """Test fee integration in PnL tracker."""
    
    def setup_method(self):
        """Set up test environment."""
        self.config = {
            'ibkr_conn': {'simulation_mode': True}
        }
        
        # Create mock fee schedule
        self.mock_fee_schedule = Mock(spec=FeeSchedule)
        self.mock_fee_schedule.venue = 'CME'
        self.mock_fee_schedule.calculate_total_fee.return_value = 1.05  # 3 contracts × $0.35
    
    @patch('execution.core.pnl_tracker.get_cme_fee_schedule')
    def test_fee_application_on_fill(self, mock_get_schedule):
        """Test that fees are applied when processing fills."""
        mock_get_schedule.return_value = self.mock_fee_schedule
        
        pnl_tracker = PnLTracker(self.config)
        pnl_tracker.initialize_portfolio_state(100000.0)
        
        # Create a test trade
        trade = {
            'symbol': 'MES',
            'qty': 3,
            'side': 1,  # Buy
            'price': 4800.25
        }
        
        # Process the fill
        pnl_tracker.on_fill(trade)
        
        # Verify fee was calculated
        self.mock_fee_schedule.calculate_total_fee.assert_called_once_with(
            symbol='MES',
            quantity=3,
            volume_ytd=0
        )
        
        # Verify fee tracking
        assert pnl_tracker.fee_accumulator == 1.05
        assert pnl_tracker.fees_by_symbol['MES'] == 1.05
        assert pnl_tracker.volume_ytd['MES'] == 3
        
        # Verify cash was reduced by fee
        expected_cash = 100000.0 - 1.05
        assert pnl_tracker.portfolio_state['total_cash_value'] == expected_cash
    
    @patch('execution.core.pnl_tracker.get_cme_fee_schedule')
    def test_multiple_trades_fee_accumulation(self, mock_get_schedule):
        """Test fee accumulation across multiple trades."""
        # Set up different fees for different trades
        def mock_calculate_fee(symbol, quantity, volume_ytd):
            if symbol == 'MES':
                return quantity * 0.35
            elif symbol == 'MNQ':
                return quantity * 0.47
            return quantity * 1.50
        
        self.mock_fee_schedule.calculate_total_fee.side_effect = mock_calculate_fee
        mock_get_schedule.return_value = self.mock_fee_schedule
        
        pnl_tracker = PnLTracker(self.config)
        pnl_tracker.initialize_portfolio_state(100000.0)
        
        # Execute multiple trades
        trades = [
            {'symbol': 'MES', 'qty': 5, 'side': 1, 'price': 4800.0},
            {'symbol': 'MNQ', 'qty': 2, 'side': -1, 'price': 15000.0},
            {'symbol': 'MES', 'qty': 3, 'side': -1, 'price': 4805.0}
        ]
        
        for trade in trades:
            pnl_tracker.on_fill(trade)
        
        # Verify fee accumulation
        expected_mes_fees = (5 * 0.35) + (3 * 0.35)  # 1.75 + 1.05 = 2.80
        expected_mnq_fees = 2 * 0.47  # 0.94
        expected_total_fees = expected_mes_fees + expected_mnq_fees  # 3.74
        
        assert pnl_tracker.fee_accumulator == expected_total_fees
        assert pnl_tracker.fees_by_symbol['MES'] == expected_mes_fees
        assert pnl_tracker.fees_by_symbol['MNQ'] == expected_mnq_fees
        
        # Verify volume tracking
        assert pnl_tracker.volume_ytd['MES'] == 8  # 5 + 3
        assert pnl_tracker.volume_ytd['MNQ'] == 2
    
    @patch('execution.core.pnl_tracker.get_cme_fee_schedule')
    def test_pnl_calculation_includes_fees(self, mock_get_schedule):
        """Test that P&L calculations include fee impact."""
        self.mock_fee_schedule.calculate_total_fee.return_value = 1.05
        mock_get_schedule.return_value = self.mock_fee_schedule
        
        pnl_tracker = PnLTracker(self.config)
        pnl_tracker.initialize_portfolio_state(100000.0)
        
        # Execute a trade
        trade = {'symbol': 'MES', 'qty': 3, 'side': 1, 'price': 4800.0}
        pnl_tracker.on_fill(trade)
        
        # Calculate P&L
        pnl_metrics = pnl_tracker.calculate_pnl()
        
        # Verify fee impact is included
        assert pnl_metrics['total_fees'] == 1.05
        assert pnl_metrics['gross_pnl'] == pnl_metrics['total_pnl'] + 1.05
        assert pnl_metrics['fee_drag_bps'] == (1.05 / 100000.0) * 10000  # ~1.05 bps
    
    @patch('execution.core.pnl_tracker.get_cme_fee_schedule')
    def test_fee_summary_reporting(self, mock_get_schedule):
        """Test fee summary and impact analysis."""
        def mock_calculate_fee(symbol, quantity, volume_ytd):
            return quantity * 0.35
        
        self.mock_fee_schedule.calculate_total_fee.side_effect = mock_calculate_fee
        mock_get_schedule.return_value = self.mock_fee_schedule
        
        pnl_tracker = PnLTracker(self.config)
        pnl_tracker.initialize_portfolio_state(100000.0)
        
        # Execute trades
        trades = [
            {'symbol': 'MES', 'qty': 10, 'side': 1, 'price': 4800.0},
            {'symbol': 'MES', 'qty': 5, 'side': -1, 'price': 4810.0}
        ]
        
        for trade in trades:
            pnl_tracker.on_fill(trade)
        
        # Test fee summary
        fee_summary = pnl_tracker.get_fee_summary()
        
        assert fee_summary['total_fees'] == 5.25  # 15 contracts × $0.35
        assert fee_summary['fees_by_symbol']['MES'] == 5.25
        assert fee_summary['volume_ytd']['MES'] == 15
        assert fee_summary['average_fee_per_contract'] == 0.35
        assert fee_summary['fee_engine_available'] is True
        assert fee_summary['venue'] == 'CME'
        
        # Test fee impact analysis
        impact_analysis = pnl_tracker.get_fee_impact_analysis()
        
        assert impact_analysis['total_fees'] == 5.25
        assert impact_analysis['total_volume'] == 15
        assert impact_analysis['symbols_traded'] == 1
        assert 'fee_impact_pct' in impact_analysis
        assert 'fee_drag_bps' in impact_analysis
    
    def test_no_fee_engine_graceful_handling(self):
        """Test graceful handling when fee engine is not available."""
        with patch('execution.core.pnl_tracker.FEE_ENGINE_AVAILABLE', False):
            pnl_tracker = PnLTracker(self.config)
            pnl_tracker.initialize_portfolio_state(100000.0)
            
            # Execute a trade
            trade = {'symbol': 'MES', 'qty': 3, 'side': 1, 'price': 4800.0}
            pnl_tracker.on_fill(trade)
            
            # Verify no fees were applied
            assert pnl_tracker.fee_accumulator == 0.0
            assert len(pnl_tracker.fees_by_symbol) == 0
            assert pnl_tracker.portfolio_state['total_cash_value'] == 100000.0
            
            # Fee summary should indicate engine not available
            fee_summary = pnl_tracker.get_fee_summary()
            assert fee_summary['fee_engine_available'] is False
            assert fee_summary['total_fees'] == 0.0


class TestCMEFeeIntegration:
    """Integration tests with actual CME fee configuration."""
    
    def test_cme_fee_calculation(self):
        """Test fee calculation with actual CME configuration."""
        # This test requires the actual CME fee config file
        try:
            fee = calculate_cme_fee('MES', 10)
            assert fee == 3.5  # 10 contracts × $0.35
            
            fee = calculate_cme_fee('MNQ', 5)
            assert fee == 2.35  # 5 contracts × $0.47
            
            # Test unknown symbol uses DEFAULT
            fee = calculate_cme_fee('UNKNOWN', 2)
            assert fee == 3.0  # 2 contracts × $1.50
            
        except FileNotFoundError:
            pytest.skip("CME fee configuration file not found")
    
    def test_real_world_fee_scenario(self):
        """Test realistic trading scenario with fees."""
        try:
            config = {'ibkr_conn': {'simulation_mode': True}}
            pnl_tracker = PnLTracker(config)
            pnl_tracker.initialize_portfolio_state(100000.0)
            
            # Simulate a day of micro futures trading
            trades = [
                # Morning: Open MES position
                {'symbol': 'MES', 'qty': 20, 'side': 1, 'price': 4800.0},
                # Add to position
                {'symbol': 'MES', 'qty': 10, 'side': 1, 'price': 4805.0},
                # Trade MNQ
                {'symbol': 'MNQ', 'qty': 5, 'side': 1, 'price': 15000.0},
                # Close half MES position
                {'symbol': 'MES', 'qty': 15, 'side': -1, 'price': 4810.0},
                # Close MNQ
                {'symbol': 'MNQ', 'qty': 5, 'side': -1, 'price': 15020.0}
            ]
            
            for trade in trades:
                pnl_tracker.on_fill(trade)
            
            # Analyze fee impact
            fee_summary = pnl_tracker.get_fee_summary()
            impact_analysis = pnl_tracker.get_fee_impact_analysis()
            
            # Expected fees:
            # MES: (20 + 10 + 15) × $0.35 = $15.75
            # MNQ: (5 + 5) × $0.47 = $4.70
            # Total: $20.45
            
            expected_total_fees = 20.45
            assert abs(fee_summary['total_fees'] - expected_total_fees) < 0.01
            
            # Verify fee impact is reasonable (should be small percentage)
            assert impact_analysis['fee_drag_bps'] < 50  # Less than 5 bps drag
            
            print(f"Total fees: ${fee_summary['total_fees']:.2f}")
            print(f"Fee drag: {impact_analysis['fee_drag_bps']:.1f} bps")
            print(f"Volume traded: {impact_analysis['total_volume']} contracts")
            
        except FileNotFoundError:
            pytest.skip("CME fee configuration file not found")


if __name__ == '__main__':
    pytest.main([__file__, '-v'])