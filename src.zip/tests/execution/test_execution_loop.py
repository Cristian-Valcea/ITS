#!/usr/bin/env python3
"""
Unit tests for ExecutionLoop core component.

Tests the main execution loop functionality including:
- Loop initialization and configuration
- Market data processing
- Signal generation and execution
- Error handling and recovery
- Performance monitoring
"""

import pytest
import asyncio
from unittest.mock import MagicMock, AsyncMock, patch
from datetime import datetime, timedelta
import pandas as pd
import numpy as np

# Import the module under test
try:
    from src.execution.core.execution_loop import ExecutionLoop
except ImportError:
    # Fallback for testing without full dependencies
    ExecutionLoop = None

@pytest.fixture
def mock_config():
    """Mock configuration for ExecutionLoop."""
    return {
        'execution': {
            'loop_interval_ms': 100,
            'max_latency_ms': 50,
            'enable_monitoring': True,
            'batch_size': 10
        },
        'risk': {
            'max_position_size': 1000,
            'max_daily_loss': 5000
        },
        'data': {
            'symbols': ['AAPL', 'MSFT'],
            'update_frequency': '1s'
        }
    }

@pytest.fixture
def mock_dependencies():
    """Mock dependencies for ExecutionLoop."""
    return {
        'data_loader': MagicMock(),
        'signal_generator': MagicMock(),
        'order_router': MagicMock(),
        'risk_manager': MagicMock(),
        'pnl_tracker': MagicMock()
    }

@pytest.mark.skipif(ExecutionLoop is None, reason="ExecutionLoop not available")
class TestExecutionLoop:
    """Test suite for ExecutionLoop."""
    
    def test_initialization(self, mock_config, mock_dependencies):
        """Test ExecutionLoop initialization."""
        loop = ExecutionLoop(mock_config, **mock_dependencies)
        
        assert loop.config == mock_config
        assert loop.loop_interval == 0.1  # 100ms converted to seconds
        assert loop.max_latency == 0.05   # 50ms converted to seconds
        assert loop.is_running is False
        
    def test_configuration_validation(self, mock_dependencies):
        """Test configuration validation."""
        # Test missing required config
        with pytest.raises(ValueError, match="Missing required config"):
            ExecutionLoop({}, **mock_dependencies)
            
        # Test invalid loop interval
        invalid_config = {
            'execution': {'loop_interval_ms': -1}
        }
        with pytest.raises(ValueError, match="Invalid loop interval"):
            ExecutionLoop(invalid_config, **mock_dependencies)
    
    @pytest.mark.asyncio
    async def test_start_stop_loop(self, mock_config, mock_dependencies):
        """Test starting and stopping the execution loop."""
        loop = ExecutionLoop(mock_config, **mock_dependencies)
        
        # Test start
        start_task = asyncio.create_task(loop.start())
        await asyncio.sleep(0.01)  # Let it start
        
        assert loop.is_running is True
        
        # Test stop
        await loop.stop()
        assert loop.is_running is False
        
        # Clean up
        start_task.cancel()
        try:
            await start_task
        except asyncio.CancelledError:
            pass
    
    @pytest.mark.asyncio
    async def test_execution_cycle(self, mock_config, mock_dependencies):
        """Test a single execution cycle."""
        loop = ExecutionLoop(mock_config, **mock_dependencies)
        
        # Mock market data
        mock_data = pd.DataFrame({
            'symbol': ['AAPL', 'MSFT'],
            'price': [150.0, 300.0],
            'timestamp': [datetime.now(), datetime.now()]
        })
        mock_dependencies['data_loader'].get_latest_data.return_value = mock_data
        
        # Mock signal generation
        mock_signals = pd.DataFrame({
            'symbol': ['AAPL'],
            'signal': [1.0],  # Buy signal
            'confidence': [0.8]
        })
        mock_dependencies['signal_generator'].generate_signals.return_value = mock_signals
        
        # Mock risk check
        mock_dependencies['risk_manager'].check_risk.return_value = True
        
        # Execute one cycle
        await loop._execute_cycle()
        
        # Verify calls
        mock_dependencies['data_loader'].get_latest_data.assert_called_once()
        mock_dependencies['signal_generator'].generate_signals.assert_called_once_with(mock_data)
        mock_dependencies['risk_manager'].check_risk.assert_called_once()
        mock_dependencies['order_router'].route_orders.assert_called_once()
    
    def test_latency_monitoring(self, mock_config, mock_dependencies):
        """Test latency monitoring functionality."""
        loop = ExecutionLoop(mock_config, **mock_dependencies)
        
        # Simulate high latency
        start_time = datetime.now()
        end_time = start_time + timedelta(milliseconds=100)  # 100ms latency
        
        loop._record_latency(start_time, end_time)
        
        assert len(loop.latency_history) == 1
        assert loop.latency_history[0] >= 0.1  # 100ms
        
        # Test latency alert
        with patch.object(loop, '_alert_high_latency') as mock_alert:
            loop._check_latency_sla()
            mock_alert.assert_called_once()
    
    def test_error_handling(self, mock_config, mock_dependencies):
        """Test error handling in execution loop."""
        loop = ExecutionLoop(mock_config, **mock_dependencies)
        
        # Mock data loader to raise exception
        mock_dependencies['data_loader'].get_latest_data.side_effect = Exception("Data error")
        
        # Should handle error gracefully
        with patch.object(loop.logger, 'error') as mock_log:
            asyncio.run(loop._execute_cycle())
            mock_log.assert_called()
    
    def test_performance_metrics(self, mock_config, mock_dependencies):
        """Test performance metrics collection."""
        loop = ExecutionLoop(mock_config, **mock_dependencies)
        
        # Simulate some execution cycles
        for i in range(5):
            start_time = datetime.now()
            end_time = start_time + timedelta(milliseconds=10 + i)
            loop._record_latency(start_time, end_time)
        
        metrics = loop.get_performance_metrics()
        
        assert 'avg_latency_ms' in metrics
        assert 'max_latency_ms' in metrics
        assert 'min_latency_ms' in metrics
        assert 'cycles_executed' in metrics
        assert metrics['cycles_executed'] == 5


class TestExecutionLoopMock:
    """Test suite using mock ExecutionLoop when real one isn't available."""
    
    def test_mock_execution_loop(self, mock_config, mock_dependencies):
        """Test with mock ExecutionLoop."""
        # Create a simple mock
        class MockExecutionLoop:
            def __init__(self, config, **deps):
                self.config = config
                self.dependencies = deps
                self.is_running = False
                self.latency_history = []
            
            async def start(self):
                self.is_running = True
            
            async def stop(self):
                self.is_running = False
            
            def get_performance_metrics(self):
                return {
                    'avg_latency_ms': 10.0,
                    'max_latency_ms': 20.0,
                    'min_latency_ms': 5.0,
                    'cycles_executed': 100
                }
        
        loop = MockExecutionLoop(mock_config, **mock_dependencies)
        
        assert loop.config == mock_config
        assert loop.is_running is False
        
        # Test async operations
        async def test_async():
            await loop.start()
            assert loop.is_running is True
            
            await loop.stop()
            assert loop.is_running is False
        
        asyncio.run(test_async())
        
        # Test metrics
        metrics = loop.get_performance_metrics()
        assert metrics['avg_latency_ms'] == 10.0


@pytest.mark.integration
class TestExecutionLoopIntegration:
    """Integration tests for ExecutionLoop."""
    
    @pytest.mark.skipif(ExecutionLoop is None, reason="ExecutionLoop not available")
    def test_full_integration(self, mock_config):
        """Test full integration with real components."""
        # This would test with real dependencies when available
        # For now, we'll skip if components aren't available
        pytest.skip("Full integration test requires all dependencies")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])