#!/usr/bin/env python3
"""
Unit tests for OrderRouter core component.

Tests the order routing functionality including:
- Order validation and preprocessing
- Routing to appropriate execution venues
- Order status tracking and updates
- Error handling and retry logic
- Performance monitoring
"""

import pytest
from unittest.mock import MagicMock, patch
from datetime import datetime
import pandas as pd

# Import the module under test
try:
    from src.execution.core.order_router import OrderRouter, Order, OrderStatus
except ImportError:
    # Fallback for testing without full dependencies
    OrderRouter = None
    Order = None
    OrderStatus = None

@pytest.fixture
def mock_config():
    """Mock configuration for OrderRouter."""
    return {
        'routing': {
            'default_venue': 'IBKR',
            'max_order_size': 1000,
            'retry_attempts': 3,
            'timeout_seconds': 30
        },
        'venues': {
            'IBKR': {
                'enabled': True,
                'max_orders_per_second': 10,
                'commission': 0.005
            }
        }
    }

@pytest.fixture
def mock_venues():
    """Mock execution venues."""
    return {
        'IBKR': MagicMock(),
        'ALPACA': MagicMock()
    }

@pytest.fixture
def sample_order():
    """Sample order for testing."""
    if Order is None:
        # Mock order structure
        return {
            'id': 'ORD_001',
            'symbol': 'AAPL',
            'side': 'BUY',
            'quantity': 100,
            'order_type': 'MARKET',
            'timestamp': datetime.now(),
            'status': 'PENDING'
        }
    else:
        return Order(
            id='ORD_001',
            symbol='AAPL',
            side='BUY',
            quantity=100,
            order_type='MARKET'
        )

@pytest.mark.skipif(OrderRouter is None, reason="OrderRouter not available")
class TestOrderRouter:
    """Test suite for OrderRouter."""
    
    def test_initialization(self, mock_config, mock_venues):
        """Test OrderRouter initialization."""
        router = OrderRouter(mock_config, mock_venues)
        
        assert router.config == mock_config
        assert router.venues == mock_venues
        assert router.default_venue == 'IBKR'
        assert len(router.pending_orders) == 0
    
    def test_order_validation(self, mock_config, mock_venues, sample_order):
        """Test order validation."""
        router = OrderRouter(mock_config, mock_venues)
        
        # Test valid order
        is_valid, error = router.validate_order(sample_order)
        assert is_valid is True
        assert error is None
        
        # Test invalid order - too large
        large_order = sample_order.copy() if isinstance(sample_order, dict) else sample_order
        if isinstance(large_order, dict):
            large_order['quantity'] = 2000
        else:
            large_order.quantity = 2000
            
        is_valid, error = router.validate_order(large_order)
        assert is_valid is False
        assert "exceeds maximum" in error.lower()
    
    def test_venue_selection(self, mock_config, mock_venues, sample_order):
        """Test venue selection logic."""
        router = OrderRouter(mock_config, mock_venues)
        
        # Test default venue selection
        venue = router.select_venue(sample_order)
        assert venue == 'IBKR'
        
        # Test venue selection with preferences
        if isinstance(sample_order, dict):
            sample_order['preferred_venue'] = 'ALPACA'
        else:
            sample_order.preferred_venue = 'ALPACA'
            
        venue = router.select_venue(sample_order)
        assert venue == 'ALPACA'
    
    def test_order_routing(self, mock_config, mock_venues, sample_order):
        """Test order routing to venues."""
        router = OrderRouter(mock_config, mock_venues)
        
        # Mock successful venue execution
        mock_venues['IBKR'].submit_order.return_value = {
            'status': 'SUBMITTED',
            'venue_order_id': 'VEN_001'
        }
        
        result = router.route_order(sample_order)
        
        assert result['status'] == 'SUBMITTED'
        assert result['venue_order_id'] == 'VEN_001'
        mock_venues['IBKR'].submit_order.assert_called_once_with(sample_order)
    
    def test_order_status_tracking(self, mock_config, mock_venues, sample_order):
        """Test order status tracking."""
        router = OrderRouter(mock_config, mock_venues)
        
        # Route an order
        mock_venues['IBKR'].submit_order.return_value = {
            'status': 'SUBMITTED',
            'venue_order_id': 'VEN_001'
        }
        
        router.route_order(sample_order)
        
        # Check order is tracked
        order_id = sample_order['id'] if isinstance(sample_order, dict) else sample_order.id
        assert order_id in router.pending_orders
        
        # Update order status
        router.update_order_status(order_id, 'FILLED', {'fill_price': 150.0})
        
        # Check order is no longer pending
        assert order_id not in router.pending_orders
        assert order_id in router.completed_orders
    
    def test_batch_routing(self, mock_config, mock_venues):
        """Test batch order routing."""
        router = OrderRouter(mock_config, mock_venues)
        
        # Create batch of orders
        orders = []
        for i in range(5):
            if Order is None:
                order = {
                    'id': f'ORD_{i:03d}',
                    'symbol': 'AAPL',
                    'side': 'BUY',
                    'quantity': 100,
                    'order_type': 'MARKET'
                }
            else:
                order = Order(
                    id=f'ORD_{i:03d}',
                    symbol='AAPL',
                    side='BUY',
                    quantity=100,
                    order_type='MARKET'
                )
            orders.append(order)
        
        # Mock venue responses
        mock_venues['IBKR'].submit_order.return_value = {
            'status': 'SUBMITTED',
            'venue_order_id': 'VEN_001'
        }
        
        results = router.route_orders(orders)
        
        assert len(results) == 5
        assert all(r['status'] == 'SUBMITTED' for r in results)
        assert mock_venues['IBKR'].submit_order.call_count == 5
    
    def test_error_handling(self, mock_config, mock_venues, sample_order):
        """Test error handling in order routing."""
        router = OrderRouter(mock_config, mock_venues)
        
        # Mock venue error
        mock_venues['IBKR'].submit_order.side_effect = Exception("Venue error")
        
        result = router.route_order(sample_order)
        
        assert result['status'] == 'ERROR'
        assert 'error' in result
        assert "Venue error" in result['error']
    
    def test_retry_logic(self, mock_config, mock_venues, sample_order):
        """Test retry logic for failed orders."""
        router = OrderRouter(mock_config, mock_venues)
        
        # Mock venue to fail twice then succeed
        mock_venues['IBKR'].submit_order.side_effect = [
            Exception("Temporary error"),
            Exception("Another error"),
            {'status': 'SUBMITTED', 'venue_order_id': 'VEN_001'}
        ]
        
        result = router.route_order(sample_order)
        
        assert result['status'] == 'SUBMITTED'
        assert mock_venues['IBKR'].submit_order.call_count == 3
    
    def test_performance_monitoring(self, mock_config, mock_venues, sample_order):
        """Test performance monitoring."""
        router = OrderRouter(mock_config, mock_venues)
        
        # Mock venue response
        mock_venues['IBKR'].submit_order.return_value = {
            'status': 'SUBMITTED',
            'venue_order_id': 'VEN_001'
        }
        
        # Route several orders
        for i in range(10):
            order = sample_order.copy() if isinstance(sample_order, dict) else sample_order
            if isinstance(order, dict):
                order['id'] = f'ORD_{i:03d}'
            else:
                order.id = f'ORD_{i:03d}'
            router.route_order(order)
        
        metrics = router.get_performance_metrics()
        
        assert 'total_orders' in metrics
        assert 'successful_orders' in metrics
        assert 'failed_orders' in metrics
        assert 'avg_routing_time_ms' in metrics
        assert metrics['total_orders'] == 10


class TestOrderRouterMock:
    """Test suite using mock OrderRouter when real one isn't available."""
    
    def test_mock_order_router(self, mock_config, mock_venues, sample_order):
        """Test with mock OrderRouter."""
        # Create a simple mock
        class MockOrderRouter:
            def __init__(self, config, venues):
                self.config = config
                self.venues = venues
                self.pending_orders = {}
                self.completed_orders = {}
            
            def validate_order(self, order):
                quantity = order['quantity'] if isinstance(order, dict) else order.quantity
                if quantity > 1000:
                    return False, "Order exceeds maximum size"
                return True, None
            
            def route_order(self, order):
                return {
                    'status': 'SUBMITTED',
                    'venue_order_id': 'VEN_001'
                }
            
            def get_performance_metrics(self):
                return {
                    'total_orders': 10,
                    'successful_orders': 9,
                    'failed_orders': 1,
                    'avg_routing_time_ms': 5.0
                }
        
        router = MockOrderRouter(mock_config, mock_venues)
        
        # Test validation
        is_valid, error = router.validate_order(sample_order)
        assert is_valid is True
        
        # Test routing
        result = router.route_order(sample_order)
        assert result['status'] == 'SUBMITTED'
        
        # Test metrics
        metrics = router.get_performance_metrics()
        assert metrics['total_orders'] == 10


if __name__ == "__main__":
    pytest.main([__file__, "-v"])