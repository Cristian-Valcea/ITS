# tests/test_feature_store.py
import sys
import pathlib
import tempfile
import shutil
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

# Add project root to path
project_root = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(project_root / "src"))

from shared.feature_store import FeatureStore
from column_names import COL_OPEN, COL_HIGH, COL_LOW, COL_CLOSE, COL_VOLUME


def create_sample_data(symbol: str = "AAPL", days: int = 30) -> pd.DataFrame:
    """Create sample OHLCV data for testing."""
    start_date = datetime.now() - timedelta(days=days)
    dates = pd.date_range(start=start_date, periods=days*78, freq='5min')  # ~78 5-min bars per day
    
    # Generate realistic price data
    np.random.seed(42)  # For reproducible tests
    base_price = 150.0
    price_changes = np.random.normal(0, 0.002, len(dates))  # 0.2% volatility
    prices = base_price * np.exp(np.cumsum(price_changes))
    
    # Create OHLCV data
    data = []
    for i, (date, close) in enumerate(zip(dates, prices)):
        high = close * (1 + abs(np.random.normal(0, 0.001)))
        low = close * (1 - abs(np.random.normal(0, 0.001)))
        open_price = prices[i-1] if i > 0 else close
        volume = np.random.randint(1000, 10000)
        
        data.append({
            COL_OPEN: open_price,
            COL_HIGH: max(open_price, high, close),
            COL_LOW: min(open_price, low, close),
            COL_CLOSE: close,
            COL_VOLUME: volume
        })
    
    df = pd.DataFrame(data, index=dates)
    return df


def simple_feature_computer(raw_df: pd.DataFrame, config: dict) -> pd.DataFrame:
    """Simple feature computation function for testing."""
    df = raw_df.copy()
    
    # Add simple moving averages
    window = config.get('sma_window', 20)
    df[f'SMA_{window}'] = df[COL_CLOSE].rolling(window=window).mean()
    
    # Add RSI-like indicator
    rsi_window = config.get('rsi_window', 14)
    delta = df[COL_CLOSE].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=rsi_window).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=rsi_window).mean()
    rs = gain / loss
    df['RSI'] = 100 - (100 / (1 + rs))
    
    # Add volume indicator
    df['Volume_SMA'] = df[COL_VOLUME].rolling(window=10).mean()
    
    # Drop NaN rows
    df.dropna(inplace=True)
    
    return df


def test_feature_store_basic():
    """Test basic FeatureStore functionality."""
    print("Testing basic FeatureStore functionality...")
    
    # Create temporary directory for testing
    with tempfile.TemporaryDirectory() as temp_dir:
        # Initialize FeatureStore with context manager
        with FeatureStore(root=temp_dir) as feature_store:
            # Create sample data
            raw_data = create_sample_data("AAPL", days=10)
            config = {'sma_window': 20, 'rsi_window': 14}
            
            print(f"Created sample data: {len(raw_data)} rows")
            
            # First call - should compute features
            print("First call (should compute)...")
            start_time = datetime.now()
            features_1 = feature_store.get_or_compute(
                symbol="AAPL",
                raw_df=raw_data,
                config=config,
                compute_func=simple_feature_computer
            )
            first_duration = (datetime.now() - start_time).total_seconds()
            print(f"First call took {first_duration:.3f} seconds")
            print(f"Features computed: {features_1.columns.tolist()}")
            print(f"Feature data shape: {features_1.shape}")
            
            # Second call - should use cache
            print("\nSecond call (should use cache)...")
            start_time = datetime.now()
            features_2 = feature_store.get_or_compute(
                symbol="AAPL",
                raw_df=raw_data,
                config=config,
                compute_func=simple_feature_computer
            )
            second_duration = (datetime.now() - start_time).total_seconds()
            print(f"Second call took {second_duration:.3f} seconds")
            
            # Verify results are identical (ignore index frequency differences from parquet serialization)
            pd.testing.assert_frame_equal(features_1, features_2, check_freq=False)
            print("✓ Cached results match computed results")
            
            # Check performance improvement
            speedup = first_duration / second_duration if second_duration > 0 else float('inf')
            print(f"Cache speedup: {speedup:.1f}x")
            
            # Test cache stats
            stats = feature_store.get_cache_stats()
            print(f"\nCache stats: {stats}")
            
            # Test with different config (should recompute)
            print("\nTesting with different config (should recompute)...")
            different_config = {'sma_window': 50, 'rsi_window': 21}
            features_3 = feature_store.get_or_compute(
                symbol="AAPL",
                raw_df=raw_data,
                config=different_config,
                compute_func=simple_feature_computer
            )
            print(f"Different config features shape: {features_3.shape}")
            
            # Verify different results
            assert not features_1.equals(features_3), "Different configs should produce different results"
            print("✓ Different configs produce different cached results")
            
            # Final cache stats
            final_stats = feature_store.get_cache_stats()
            print(f"Final cache stats: {final_stats}")
            
            print("✓ FeatureStore basic test completed successfully!")


def test_feature_store_with_different_symbols():
    """Test FeatureStore with different symbols."""
    print("\nTesting FeatureStore with different symbols...")
    
    with tempfile.TemporaryDirectory() as temp_dir:
        with FeatureStore(root=temp_dir) as feature_store:
            config = {'sma_window': 20, 'rsi_window': 14}
            
            # Test with multiple symbols
            symbols = ["AAPL", "GOOGL", "MSFT"]
            for symbol in symbols:
                raw_data = create_sample_data(symbol, days=5)
                features = feature_store.get_or_compute(
                    symbol=symbol,
                    raw_df=raw_data,
                    config=config,
                    compute_func=simple_feature_computer
                )
                print(f"Cached features for {symbol}: {features.shape}")
            
            # Check that each symbol has separate cache entries
            stats = feature_store.get_cache_stats()
            print(f"Cache stats with multiple symbols: {stats}")
            assert stats['unique_symbols'] == len(symbols), "Should have separate cache entries per symbol"
            
            print("✓ Multiple symbols test completed successfully!")


def test_cache_cleanup():
    """Test cache cleanup functionality."""
    print("\nTesting cache cleanup...")
    
    with tempfile.TemporaryDirectory() as temp_dir:
        with FeatureStore(root=temp_dir) as feature_store:
            # Add some cache entries
            config = {'sma_window': 20, 'rsi_window': 14}
            raw_data = create_sample_data("TEST", days=3)
            
            feature_store.get_or_compute("TEST", raw_data, config, simple_feature_computer)
            
            stats_before = feature_store.get_cache_stats()
            print(f"Before cleanup: {stats_before}")
            
            # Clear cache for specific symbol
            feature_store.clear_cache(symbol="TEST")
            
            stats_after = feature_store.get_cache_stats()
            print(f"After cleanup: {stats_after}")
            
            assert stats_after['total_entries'] == 0, "Cache should be empty after cleanup"
            
            print("✓ Cache cleanup test completed successfully!")


if __name__ == "__main__":
    print("=" * 60)
    print("FEATURE STORE PERFORMANCE TEST")
    print("=" * 60)
    
    try:
        test_feature_store_basic()
        test_feature_store_with_different_symbols()
        test_cache_cleanup()
        
        print("\n" + "=" * 60)
        print("ALL TESTS PASSED! ✓")
        print("FeatureStore is ready for 32x performance improvement!")
        print("=" * 60)
        
    except Exception as e:
        print(f"\n❌ Test failed: {e}")
        import traceback
        traceback.print_exc()