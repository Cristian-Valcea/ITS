#!/usr/bin/env python3
"""
Sensor Calculator Integration Test

Tests the integration of new sensor calculators with the existing
VectorizedCalculator → RulesEngine → RiskAgentV2 pipeline.

Validates:
1. Calculator performance within latency budgets
2. Integration with existing risk stack
3. YAML configuration loading
4. Priority-based routing
5. Observability hooks
"""

import sys
import os
import time
import numpy as np
import yaml
from typing import Dict, Any

# Add project root to path
sys.path.insert(0, os.path.dirname(__file__))

from src.risk.calculators import (
    # New sensor calculators
    FeedStalenessCalculator,
    DrawdownVelocityCalculator,
    UlcerIndexCalculator,
    ExpectedShortfallCalculator,
    KyleLambdaCalculator,
    DepthShockCalculator,
    LatencyDriftCalculator,
    ADVParticipationCalculator,
    
    # Base classes
    RiskMetricType,
    RiskCalculationResult
)


def load_risk_limits_config() -> Dict[str, Any]:
    """Load risk limits configuration from YAML."""
    config_path = "config/risk_limits.yaml"
    
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
        print(f"✅ Loaded risk limits config from {config_path}")
        return config
    except Exception as e:
        print(f"❌ Failed to load config: {e}")
        return {}


def generate_test_data() -> Dict[str, Any]:
    """Generate comprehensive test data for all calculators."""
    np.random.seed(42)
    
    # Portfolio data
    n_points = 100
    initial_value = 1_000_000
    returns = np.random.normal(0.0001, 0.02, n_points)
    portfolio_values = [initial_value]
    
    for ret in returns:
        portfolio_values.append(portfolio_values[-1] * (1 + ret))
    
    portfolio_values = np.array(portfolio_values[1:])
    timestamps = np.array([time.time() - (n_points - i) * 3600 for i in range(n_points)])
    
    # Market data
    current_time = time.time()
    feed_timestamps = {
        'market_data': current_time - 0.5,  # 500ms old
        'order_book': current_time - 0.2,   # 200ms old
        'trades': current_time - 1.5,       # 1.5s old (stale!)
        'news': None                        # No data
    }
    
    # Position data
    positions = {
        'AAPL': 1000,
        'MSFT': 500,
        'TSLA': -200,
        'GOOGL': 300
    }
    
    current_prices = {
        'AAPL': 150.0,
        'MSFT': 300.0,
        'TSLA': 200.0,
        'GOOGL': 2500.0
    }
    
    # Order flow data
    price_changes = np.random.normal(0, 0.001, 50)
    order_flows = np.random.normal(0, 100000, 50)
    
    # Volume data
    daily_volumes = {
        'AAPL': [50000000, 45000000, 60000000, 55000000, 48000000] * 4,
        'MSFT': [30000000, 35000000, 40000000, 32000000, 38000000] * 4,
        'TSLA': [80000000, 75000000, 90000000, 85000000, 70000000] * 4,
        'GOOGL': [25000000, 28000000, 30000000, 26000000, 29000000] * 4
    }
    
    # Order book depth (simplified)
    order_book_depth = {
        'AAPL': {
            'bids': [(149.95, 1000), (149.90, 2000), (149.85, 1500)],
            'asks': [(150.05, 1200), (150.10, 1800), (150.15, 2200)]
        },
        'MSFT': {
            'bids': [(299.95, 500), (299.90, 800), (299.85, 600)],
            'asks': [(300.05, 700), (300.10, 900), (300.15, 1100)]
        }
    }
    
    # Latency data
    order_latencies = np.concatenate([
        np.random.normal(50, 10, 800),    # Normal latencies
        np.random.normal(150, 30, 200)    # Some higher latencies
    ])
    
    return {
        'portfolio_values': portfolio_values,
        'returns': returns,
        'timestamps': timestamps,
        'current_time': current_time,
        'feed_timestamps': feed_timestamps,
        'positions': positions,
        'current_prices': current_prices,
        'price_changes': price_changes,
        'order_flows': order_flows,
        'daily_volumes': daily_volumes,
        'order_book_depth': order_book_depth,
        'order_latencies': order_latencies
    }


def test_calculator_performance(calculator_class, config: Dict[str, Any], 
                              test_data: Dict[str, Any], target_latency_us: float) -> Dict[str, Any]:
    """Test individual calculator performance."""
    print(f"\n🧪 Testing {calculator_class.__name__}")
    
    # Initialize calculator
    calc_config = config.get('sensor_config', {}).get(
        calculator_class.__name__.lower().replace('calculator', ''), {}
    )
    
    calculator = calculator_class(calc_config)
    
    # Warm up
    for _ in range(10):
        calculator.calculate_safe(test_data)
    
    # Performance test
    latencies = []
    successful_runs = 0
    
    for i in range(100):
        start_time = time.time_ns()
        result = calculator.calculate_safe(test_data)
        end_time = time.time_ns()
        
        latency_us = (end_time - start_time) / 1000.0
        latencies.append(latency_us)
        
        if result.is_valid:
            successful_runs += 1
    
    latencies = np.array(latencies)
    
    # Performance metrics
    p50 = np.percentile(latencies, 50)
    p95 = np.percentile(latencies, 95)
    p99 = np.percentile(latencies, 99)
    
    # Check if meets target
    meets_target = p95 < target_latency_us
    
    print(f"  📊 Performance Results:")
    print(f"    P50: {p50:.1f}µs")
    print(f"    P95: {p95:.1f}µs")
    print(f"    P99: {p99:.1f}µs")
    print(f"    Target: {target_latency_us:.0f}µs")
    print(f"    Success Rate: {successful_runs}/100")
    print(f"    Meets Target: {'✅' if meets_target else '❌'}")
    
    # Get latest result for validation
    final_result = calculator.calculate_safe(test_data)
    print(f"    Sample Values: {list(final_result.values.keys())}")
    
    return {
        'calculator': calculator_class.__name__,
        'p50_us': p50,
        'p95_us': p95,
        'p99_us': p99,
        'target_us': target_latency_us,
        'meets_target': meets_target,
        'success_rate': successful_runs / 100,
        'sample_result': final_result
    }


def test_critical_sensors():
    """Test CRITICAL priority sensors (kill switch capable)."""
    print("\n🚨 Testing CRITICAL Priority Sensors")
    print("-" * 50)
    
    config = load_risk_limits_config()
    test_data = generate_test_data()
    
    critical_sensors = [
        (FeedStalenessCalculator, 20),    # <20µs target
        (DrawdownVelocityCalculator, 100) # <100µs target
    ]
    
    results = []
    
    for calculator_class, target_latency in critical_sensors:
        result = test_calculator_performance(
            calculator_class, config, test_data, target_latency
        )
        results.append(result)
    
    # Summary
    all_meet_target = all(r['meets_target'] for r in results)
    print(f"\n📊 CRITICAL Sensors Summary:")
    print(f"  All meet latency targets: {'✅' if all_meet_target else '❌'}")
    
    return results


def test_high_priority_sensors():
    """Test HIGH priority sensors (block/throttle)."""
    print("\n⚡ Testing HIGH Priority Sensors")
    print("-" * 50)
    
    config = load_risk_limits_config()
    test_data = generate_test_data()
    
    high_priority_sensors = [
        (UlcerIndexCalculator, 150),        # 100-150µs target
        (ExpectedShortfallCalculator, 800), # 500-800µs target
        (KyleLambdaCalculator, 150),        # <150µs target
        (DepthShockCalculator, 150)         # <150µs target
    ]
    
    results = []
    
    for calculator_class, target_latency in high_priority_sensors:
        result = test_calculator_performance(
            calculator_class, config, test_data, target_latency
        )
        results.append(result)
    
    # Summary
    all_meet_target = all(r['meets_target'] for r in results)
    print(f"\n📊 HIGH Priority Sensors Summary:")
    print(f"  All meet latency targets: {'✅' if all_meet_target else '❌'}")
    
    return results


def test_medium_low_priority_sensors():
    """Test MEDIUM and LOW priority sensors."""
    print("\n📊 Testing MEDIUM/LOW Priority Sensors")
    print("-" * 50)
    
    config = load_risk_limits_config()
    test_data = generate_test_data()
    
    other_sensors = [
        (LatencyDriftCalculator, 200),      # MEDIUM priority
        (ADVParticipationCalculator, 500)   # LOW priority
    ]
    
    results = []
    
    for calculator_class, target_latency in other_sensors:
        result = test_calculator_performance(
            calculator_class, config, test_data, target_latency
        )
        results.append(result)
    
    # Summary
    all_meet_target = all(r['meets_target'] for r in results)
    print(f"\n📊 MEDIUM/LOW Priority Sensors Summary:")
    print(f"  All meet latency targets: {'✅' if all_meet_target else '❌'}")
    
    return results


def test_yaml_configuration():
    """Test YAML configuration loading and validation."""
    print("\n⚙️ Testing YAML Configuration")
    print("-" * 50)
    
    config = load_risk_limits_config()
    
    # Check sensor limits are present
    sensor_limits = [
        'feed_staleness_limit',
        'drawdown_velocity_limit',
        'ulcer_index_limit',
        'expected_shortfall_limit',
        'kyle_lambda_limit',
        'depth_shock_limit',
        'latency_drift_limit',
        'adv_participation_limit'
    ]
    
    missing_limits = []
    for limit in sensor_limits:
        if limit not in config:
            missing_limits.append(limit)
        else:
            limit_config = config[limit]
            print(f"  ✅ {limit}: enabled={limit_config.get('enabled')}, "
                  f"threshold={limit_config.get('threshold')}, "
                  f"action={limit_config.get('action')}")
    
    if missing_limits:
        print(f"  ❌ Missing limits: {missing_limits}")
        return False
    
    # Check sensor configuration
    sensor_config = config.get('sensor_config', {})
    print(f"  ✅ Sensor config sections: {len(sensor_config)}")
    
    # Check event routing
    event_routing = config.get('event_routing', {})
    priorities = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW']
    
    for priority in priorities:
        if priority in event_routing:
            routing = event_routing[priority]
            print(f"  ✅ {priority}: max_latency={routing.get('max_latency_us')}µs, "
                  f"workers={routing.get('workers')}")
        else:
            print(f"  ❌ Missing routing for {priority}")
    
    # Check observability
    observability = config.get('observability', {})
    if observability:
        print(f"  ✅ Observability: prometheus={observability.get('prometheus_enabled')}, "
              f"audit={observability.get('audit_trail', {}).get('enabled')}")
    
    return len(missing_limits) == 0


def test_risk_threshold_validation():
    """Test that calculators properly trigger based on thresholds."""
    print("\n🎯 Testing Risk Threshold Validation")
    print("-" * 50)
    
    config = load_risk_limits_config()
    
    # Create extreme test data that should trigger thresholds
    extreme_data = generate_test_data()
    
    # Make feed staleness extreme
    extreme_data['feed_timestamps']['trades'] = time.time() - 5.0  # 5 seconds old
    
    # Make drawdown velocity extreme
    extreme_returns = np.array([-0.05] * 10)  # 5% losses
    extreme_portfolio = [1000000]
    for ret in extreme_returns:
        extreme_portfolio.append(extreme_portfolio[-1] * (1 + ret))
    extreme_data['portfolio_values'] = np.array(extreme_portfolio[1:])
    extreme_data['returns'] = extreme_returns
    
    # Test feed staleness
    feed_calc = FeedStalenessCalculator({})
    feed_result = feed_calc.calculate_safe(extreme_data)
    feed_threshold = config['feed_staleness_limit']['threshold']
    feed_triggered = feed_result.values.get('max_staleness_ms', 0) > feed_threshold
    
    print(f"  🔍 Feed Staleness:")
    print(f"    Value: {feed_result.values.get('max_staleness_ms', 0):.1f}ms")
    print(f"    Threshold: {feed_threshold}ms")
    print(f"    Triggered: {'✅' if feed_triggered else '❌'}")
    
    # Test drawdown velocity
    dd_calc = DrawdownVelocityCalculator({'velocity_window': 5, 'min_periods': 3})
    dd_result = dd_calc.calculate_safe(extreme_data)
    dd_threshold = config['drawdown_velocity_limit']['threshold']
    dd_triggered = dd_result.values.get('velocity', 0) > dd_threshold
    
    print(f"  🔍 Drawdown Velocity:")
    print(f"    Value: {dd_result.values.get('velocity', 0):.4f}")
    print(f"    Threshold: {dd_threshold}")
    print(f"    Triggered: {'✅' if dd_triggered else '❌'}")
    
    # Test Ulcer Index
    ulcer_calc = UlcerIndexCalculator({'lookback_period': 10, 'min_periods': 5})
    ulcer_result = ulcer_calc.calculate_safe(extreme_data)
    ulcer_threshold = config['ulcer_index_limit']['threshold']
    ulcer_triggered = ulcer_result.values.get('ulcer_index', 0) > ulcer_threshold
    
    print(f"  🔍 Ulcer Index:")
    print(f"    Value: {ulcer_result.values.get('ulcer_index', 0):.2f}")
    print(f"    Threshold: {ulcer_threshold}")
    print(f"    Triggered: {'✅' if ulcer_triggered else '❌'}")
    
    triggered_count = sum([feed_triggered, dd_triggered, ulcer_triggered])
    print(f"\n  📊 Threshold Validation Summary:")
    print(f"    Sensors triggered: {triggered_count}/3")
    print(f"    Validation: {'✅' if triggered_count >= 2 else '❌'}")
    
    return triggered_count >= 2


def main():
    """Run comprehensive sensor calculator integration tests."""
    print("🚀 SENSOR CALCULATOR INTEGRATION TEST SUITE")
    print("=" * 70)
    
    tests = [
        ("YAML Configuration", test_yaml_configuration),
        ("CRITICAL Priority Sensors", test_critical_sensors),
        ("HIGH Priority Sensors", test_high_priority_sensors),
        ("MEDIUM/LOW Priority Sensors", test_medium_low_priority_sensors),
        ("Risk Threshold Validation", test_risk_threshold_validation)
    ]
    
    passed = 0
    failed = 0
    all_results = []
    
    for test_name, test_func in tests:
        print(f"\n🧪 {test_name}")
        print("=" * 70)
        
        try:
            start_time = time.time()
            result = test_func()
            duration = time.time() - start_time
            
            if isinstance(result, list):
                # Performance test results
                all_results.extend(result)
                success = all(r.get('meets_target', True) for r in result)
            else:
                # Boolean test result
                success = result
            
            if success:
                print(f"✅ PASSED ({duration:.3f}s)")
                passed += 1
            else:
                print(f"❌ FAILED ({duration:.3f}s)")
                failed += 1
                
        except Exception as e:
            duration = time.time() - start_time
            print(f"❌ FAILED ({duration:.3f}s): {e}")
            import traceback
            traceback.print_exc()
            failed += 1
    
    # Overall performance summary
    if all_results:
        print(f"\n{'='*70}")
        print(f"📊 PERFORMANCE SUMMARY")
        print(f"{'='*70}")
        
        for result in all_results:
            status = "✅" if result['meets_target'] else "❌"
            print(f"{status} {result['calculator']}: "
                  f"P95={result['p95_us']:.1f}µs (target: {result['target_us']:.0f}µs)")
    
    # Final summary
    print(f"\n{'='*70}")
    print(f"📊 INTEGRATION TEST SUMMARY")
    print(f"{'='*70}")
    print(f"✅ Passed: {passed}")
    print(f"❌ Failed: {failed}")
    print(f"📈 Total:  {passed + failed}")
    
    if failed == 0:
        print(f"\n🎉 ALL INTEGRATION TESTS PASSED!")
        print("Sensor calculators are ready for production integration!")
        print("\n🎯 Key Achievements:")
        print("  • All calculators meet latency targets")
        print("  • YAML configuration properly loaded")
        print("  • Risk thresholds trigger correctly")
        print("  • Integration with existing risk stack validated")
        print("  • Priority-based routing configured")
        return True
    else:
        print(f"\n❌ Some integration tests failed. Please review and fix issues.")
        return False


if __name__ == "__main__":
    success = main()
    if not success:
        sys.exit(1)