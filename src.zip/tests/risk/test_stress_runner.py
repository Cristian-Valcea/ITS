"""
Unit tests for the Flash-Crash Lite stress testing system.
"""

import pytest
import asyncio
import tempfile
from pathlib import Path
from unittest.mock import Mock, AsyncMock, patch
import yaml

from src.risk.stress_runner import (
    StressScenario, StressRunner, PagerDutyAlerter, 
    HourlyStressScheduler, create_stress_system
)


class TestStressScenario:
    """Test stress scenario configuration."""
    
    def test_valid_scenario_config(self):
        """Test loading valid scenario configuration."""
        config = {
            'scenario_name': 'test_scenario',
            'symbol_set': 'active_book',
            'price_shock_pct': -0.03,
            'spread_mult': 3.0,
            'duration_sec': 60
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(config, f)
            config_path = Path(f.name)
        
        try:
            scenario = StressScenario(config_path)
            assert scenario.name == 'test_scenario'
            assert scenario.price_shock_pct == -0.03
            assert scenario.spread_mult == 3.0
            assert scenario.duration_sec == 60
        finally:
            config_path.unlink()
    
    def test_invalid_price_shock(self):
        """Test validation of price shock percentage."""
        config = {
            'scenario_name': 'test_scenario',
            'symbol_set': 'active_book',
            'price_shock_pct': -0.50,  # Invalid: > 20%
            'spread_mult': 3.0,
            'duration_sec': 60
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(config, f)
            config_path = Path(f.name)
        
        try:
            with pytest.raises(ValueError, match="price_shock_pct must be between"):
                StressScenario(config_path)
        finally:
            config_path.unlink()
    
    def test_missing_required_field(self):
        """Test validation of required fields."""
        config = {
            'scenario_name': 'test_scenario',
            # Missing symbol_set
            'price_shock_pct': -0.03,
            'spread_mult': 3.0,
            'duration_sec': 60
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(config, f)
            config_path = Path(f.name)
        
        try:
            with pytest.raises(ValueError, match="Missing required field: symbol_set"):
                StressScenario(config_path)
        finally:
            config_path.unlink()


class TestPagerDutyAlerter:
    """Test PagerDuty alerting functionality."""
    
    @pytest.mark.asyncio
    async def test_send_alert_success(self):
        """Test successful PagerDuty alert."""
        alerter = PagerDutyAlerter("test-routing-key")
        
        with patch('httpx.AsyncClient') as mock_client:
            mock_response = Mock()
            mock_response.raise_for_status = Mock()
            mock_client.return_value.__aenter__.return_value.post = AsyncMock(return_value=mock_response)
            
            await alerter.send_alert(['MES', 'MNQ'], 'flash_crash_lite')
            
            # Verify HTTP call was made
            mock_client.return_value.__aenter__.return_value.post.assert_called_once()
            call_args = mock_client.return_value.__aenter__.return_value.post.call_args
            
            assert call_args[1]['json']['routing_key'] == 'test-routing-key'
            assert 'MES, MNQ' in call_args[1]['json']['payload']['summary']
    
    @pytest.mark.asyncio
    async def test_send_alert_disabled(self):
        """Test alerter with no routing key (disabled)."""
        alerter = PagerDutyAlerter("")
        
        # Should not raise exception when disabled
        await alerter.send_alert(['MES'], 'test_scenario')
        assert not alerter.enabled


class TestStressRunner:
    """Test stress runner functionality."""
    
    def create_test_scenario(self):
        """Create a test scenario configuration."""
        config = {
            'scenario_name': 'test_scenario',
            'symbol_set': 'test_symbols',
            'price_shock_pct': -0.03,
            'spread_mult': 3.0,
            'duration_sec': 60,
            'max_runtime_ms': 50,
            'max_symbols': 100,
            'alert_on_breach': True,
            'halt_on_breach': True
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(config, f)
            return StressScenario(Path(f.name))
    
    @pytest.mark.asyncio
    async def test_run_once_no_breaches(self):
        """Test stress runner with no breaches detected."""
        scenario = self.create_test_scenario()
        
        # Mock components
        mock_bus = Mock()
        mock_risk_agent = Mock()
        mock_alerter = Mock()
        mock_alerter.send_alert = AsyncMock()
        
        runner = StressRunner(scenario, mock_bus, mock_risk_agent, mock_alerter)
        
        # Mock _test_symbol to return no breaches
        runner._test_symbol = AsyncMock(return_value=False)
        
        result = await runner.run_once()
        
        assert result['scenario'] == 'test_scenario'
        assert result['breach_count'] == 0
        assert len(result['breaches']) == 0
        assert result['symbols_tested'] == 2  # test_symbols = ['MES', 'MNQ']
        
        # Verify no alert was sent
        mock_alerter.send_alert.assert_not_called()
    
    @pytest.mark.asyncio
    async def test_run_once_with_breaches(self):
        """Test stress runner with breaches detected."""
        scenario = self.create_test_scenario()
        
        # Mock components
        mock_bus = Mock()
        mock_bus.publish = AsyncMock()
        mock_risk_agent = Mock()
        mock_alerter = Mock()
        mock_alerter.send_alert = AsyncMock()
        
        runner = StressRunner(scenario, mock_bus, mock_risk_agent, mock_alerter)
        
        # Mock _test_symbol to return breach for MES
        async def mock_test_symbol(symbol):
            return symbol == 'MES'
        
        runner._test_symbol = mock_test_symbol
        
        result = await runner.run_once()
        
        assert result['scenario'] == 'test_scenario'
        assert result['breach_count'] == 1
        assert result['breaches'] == ['MES']
        assert result['symbols_tested'] == 2
        
        # Verify alert was sent
        mock_alerter.send_alert.assert_called_once_with(['MES'], 'test_scenario')
        
        # Verify KILL_SWITCH was triggered (only if RISK_SYSTEM_AVAILABLE)
        # In test environment, RISK_SYSTEM_AVAILABLE may be False
        # so we check if publish was called or not based on system availability
        from src.risk.stress_runner import RISK_SYSTEM_AVAILABLE
        if RISK_SYSTEM_AVAILABLE:
            mock_bus.publish.assert_called_once()
        else:
            # If risk system not available, publish should not be called
            mock_bus.publish.assert_not_called()
    
    def test_resolve_symbols(self):
        """Test symbol resolution."""
        scenario = self.create_test_scenario()
        runner = StressRunner(scenario)
        
        # Test known symbol sets
        symbols = runner._resolve_symbols('test_symbols')
        assert symbols == ['MES', 'MNQ']
        
        symbols = runner._resolve_symbols('cme_micros')
        assert symbols == ['MES', 'MNQ', 'M2K', 'MCL']
        
        # Test unknown symbol set
        with pytest.raises(ValueError, match="Unknown symbol_set"):
            runner._resolve_symbols('unknown_set')
    
    def test_build_synthetic_event(self):
        """Test synthetic event generation."""
        scenario = self.create_test_scenario()
        runner = StressRunner(scenario)
        
        event = runner._build_synthetic_event('MES')
        
        # Check event structure
        if isinstance(event, dict):
            assert event['symbol'] == 'MES'
            assert event['spread_mult'] == 3.0
            assert event['duration_sec'] == 60
            assert event['scenario'] == 'test_scenario'
            assert len(event['price_path']) == 10
        
        # Check price path starts with shock and recovers
        price_path = event['price_path'] if isinstance(event, dict) else event.data['price_path']
        assert price_path[0] < 1.0  # Initial shock
        assert price_path[-1] == pytest.approx(1.0, rel=1e-3)  # Recovery to original


class TestHourlyStressScheduler:
    """Test hourly stress scheduler."""
    
    @pytest.mark.asyncio
    async def test_scheduler_start_stop(self):
        """Test scheduler start and stop."""
        scenario = StressScenario(Path("risk/stress_packs/flash_crash.yaml"))
        runner = StressRunner(scenario)
        scheduler = HourlyStressScheduler(runner)
        
        # Test start
        await scheduler.start()
        assert scheduler.running
        assert scheduler.task is not None
        
        # Test stop
        await scheduler.stop()
        assert not scheduler.running
    
    def test_should_run_market_hours(self):
        """Test market hours logic."""
        scenario_config = {
            'scenario_name': 'test',
            'symbol_set': 'test_symbols',
            'price_shock_pct': -0.03,
            'spread_mult': 3.0,
            'duration_sec': 60,
            'market_hours_only': True
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(scenario_config, f)
            scenario = StressScenario(Path(f.name))
        
        runner = StressRunner(scenario)
        scheduler = HourlyStressScheduler(runner)
        
        # Mock datetime to test different times
        with patch('src.risk.stress_runner.dt') as mock_dt:
            # Test weekday during market hours (3 PM UTC = 10 AM ET)
            mock_dt.datetime.utcnow.return_value.hour = 15
            mock_dt.datetime.utcnow.return_value.weekday.return_value = 2  # Wednesday
            
            assert scheduler._should_run()
            
            # Test weekend
            mock_dt.datetime.utcnow.return_value.weekday.return_value = 6  # Sunday
            
            assert not scheduler._should_run()


class TestIntegration:
    """Integration tests for the complete stress testing system."""
    
    @pytest.mark.asyncio
    async def test_create_stress_system(self):
        """Test stress system factory function."""
        # Create temporary config
        config = {
            'scenario_name': 'integration_test',
            'symbol_set': 'test_symbols',
            'price_shock_pct': -0.03,
            'spread_mult': 3.0,
            'duration_sec': 60
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(config, f)
            config_path = f.name
        
        try:
            runner, scheduler = create_stress_system(config_path, "test-key")
            
            assert runner.scenario.name == 'integration_test'
            assert runner.alerter.routing_key == 'test-key'
            assert scheduler.stress_runner == runner
            
        finally:
            Path(config_path).unlink()
    
    @pytest.mark.asyncio
    async def test_performance_constraint(self):
        """Test that stress runner meets performance constraints."""
        scenario_config = {
            'scenario_name': 'perf_test',
            'symbol_set': 'test_symbols',
            'price_shock_pct': -0.03,
            'spread_mult': 3.0,
            'duration_sec': 60,
            'max_runtime_ms': 50
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(scenario_config, f)
            scenario = StressScenario(Path(f.name))
        
        try:
            runner = StressRunner(scenario)
            
            # Mock fast test
            runner._test_symbol = AsyncMock(return_value=False)
            
            result = await runner.run_once()
            
            # Should complete quickly for test symbols
            assert result['runtime_ms'] < 100  # Generous limit for test
            
        finally:
            Path(f.name).unlink()


# Performance test (separate from unit tests)
@pytest.mark.performance
@pytest.mark.asyncio
async def test_stress_runner_performance():
    """Test stress runner performance with many symbols."""
    scenario_config = {
        'scenario_name': 'perf_test',
        'symbol_set': 'cme_micros',
        'price_shock_pct': -0.03,
        'spread_mult': 3.0,
        'duration_sec': 60,
        'max_runtime_ms': 50,
        'max_symbols': 100
    }
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        yaml.dump(scenario_config, f)
        scenario = StressScenario(Path(f.name))
    
    try:
        runner = StressRunner(scenario)
        
        # Override symbol resolution to return many symbols
        def mock_resolve_symbols(symbol_set):
            return [f'SYM{i:03d}' for i in range(100)]
        
        runner._resolve_symbols = mock_resolve_symbols
        runner._test_symbol = AsyncMock(return_value=False)
        
        result = await runner.run_once()
        
        # Should handle 100 symbols within performance constraint
        assert result['symbols_tested'] == 100
        assert result['runtime_ms'] < 100  # Should be fast with mocked tests
        
    finally:
        Path(f.name).unlink()


if __name__ == "__main__":
    # Run tests
    pytest.main([__file__, "-v"])