"""
Unit tests for the fee schedule engine.

Tests the venue-specific fee calculation without complex imports.
"""

import pytest
import tempfile
import yaml
from pathlib import Path

# Import the fee schedule module directly
import sys
sys.path.append('src')

from shared.fee_schedule import FeeSchedule, Fee, validate_fee_config


class TestFeeSchedule:
    """Test the fee schedule engine."""
    
    def test_simple_fee_lookup(self):
        """Test basic fee lookup for CME micro futures."""
        # Create temporary fee config
        fee_config = {
            'MES': {'trade_fee': 0.35, 'currency': 'USD', 'description': 'Micro E-mini S&P 500'},
            'MNQ': {'trade_fee': 0.47, 'currency': 'USD', 'description': 'Micro E-mini NASDAQ-100'},
            'M2K': {'trade_fee': 0.25, 'currency': 'USD', 'description': 'Micro E-mini Russell 2000'},
            'MCL': {'trade_fee': 0.74, 'currency': 'USD', 'description': 'Micro WTI Crude Oil'},
            'DEFAULT': {'trade_fee': 1.50, 'currency': 'USD', 'description': 'Default CME fee'},
            'metadata': {
                'venue': 'CME',
                'last_updated': '2024-01-15',
                'source': 'CME Group fee schedule'
            }
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(fee_config, f)
            config_path = f.name
        
        try:
            schedule = FeeSchedule(config_path)
            
            # Test venue info
            assert schedule.venue == 'CME'
            assert schedule.last_updated == '2024-01-15'
            
            # Test known symbols
            mes_fee = schedule.lookup('MES')
            assert mes_fee.fee_per_side == 0.35
            assert mes_fee.currency == 'USD'
            assert 'Micro E-mini S&P 500' in mes_fee.description
            
            mnq_fee = schedule.lookup('MNQ')
            assert mnq_fee.fee_per_side == 0.47
            
            m2k_fee = schedule.lookup('M2K')
            assert m2k_fee.fee_per_side == 0.25
            
            mcl_fee = schedule.lookup('MCL')
            assert mcl_fee.fee_per_side == 0.74
            
            # Test unknown symbol falls back to DEFAULT
            unknown_fee = schedule.lookup('UNKNOWN_SYMBOL')
            assert unknown_fee.fee_per_side == 1.50
            assert unknown_fee.currency == 'USD'
            
        finally:
            Path(config_path).unlink()
    
    def test_tiered_fee_lookup(self):
        """Test tiered fee structure with volume discounts."""
        fee_config = {
            'MNQ': {
                'currency': 'USD',
                'description': 'Micro E-mini NASDAQ-100 (Tiered)',
                'tiers': [
                    {'vol': 0, 'fee': 0.47},        # 0-99,999 contracts
                    {'vol': 100000, 'fee': 0.40},   # 100,000-499,999 contracts
                    {'vol': 500000, 'fee': 0.35}    # 500,000+ contracts
                ]
            },
            'DEFAULT': {'trade_fee': 1.50, 'currency': 'USD'}
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(fee_config, f)
            config_path = f.name
        
        try:
            schedule = FeeSchedule(config_path)
            
            # Test different volume tiers
            fee_tier1 = schedule.lookup('MNQ', volume_ytd=50000)
            assert fee_tier1.fee_per_side == 0.47
            
            fee_tier2 = schedule.lookup('MNQ', volume_ytd=200000)
            assert fee_tier2.fee_per_side == 0.40
            
            fee_tier3 = schedule.lookup('MNQ', volume_ytd=600000)
            assert fee_tier3.fee_per_side == 0.35
            
            # Test edge cases
            fee_edge1 = schedule.lookup('MNQ', volume_ytd=99999)
            assert fee_edge1.fee_per_side == 0.47
            
            fee_edge2 = schedule.lookup('MNQ', volume_ytd=100000)
            assert fee_edge2.fee_per_side == 0.40
            
            fee_edge3 = schedule.lookup('MNQ', volume_ytd=500000)
            assert fee_edge3.fee_per_side == 0.35
            
        finally:
            Path(config_path).unlink()
    
    def test_calculate_total_fee(self):
        """Test total fee calculation for trades."""
        fee_config = {
            'MES': {'trade_fee': 0.35, 'currency': 'USD'},
            'MNQ': {'trade_fee': 0.47, 'currency': 'USD'},
            'DEFAULT': {'trade_fee': 1.50, 'currency': 'USD'}
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(fee_config, f)
            config_path = f.name
        
        try:
            schedule = FeeSchedule(config_path)
            
            # Test fee calculation for different quantities
            total_fee_1 = schedule.calculate_total_fee('MES', quantity=1)
            assert total_fee_1 == 0.35  # 1 contract × $0.35
            
            total_fee_10 = schedule.calculate_total_fee('MES', quantity=10)
            assert total_fee_10 == 3.5  # 10 contracts × $0.35
            
            total_fee_mnq = schedule.calculate_total_fee('MNQ', quantity=5)
            assert abs(total_fee_mnq - 2.35) < 0.01  # 5 contracts × $0.47
            
            # Test with negative quantity (should use absolute value)
            total_fee_neg = schedule.calculate_total_fee('MES', quantity=-5)
            assert abs(total_fee_neg - 1.75) < 0.01  # 5 contracts × $0.35
            
            # Test unknown symbol
            total_fee_unknown = schedule.calculate_total_fee('UNKNOWN', quantity=2)
            assert total_fee_unknown == 3.0  # 2 contracts × $1.50
            
        finally:
            Path(config_path).unlink()
    
    def test_fee_info_and_metadata(self):
        """Test fee information and metadata retrieval."""
        fee_config = {
            'MES': {
                'trade_fee': 0.35, 
                'currency': 'USD',
                'description': 'Micro E-mini S&P 500 Futures'
            },
            'MNQ': {
                'currency': 'USD',
                'description': 'Micro E-mini NASDAQ-100 (Tiered)',
                'tiers': [
                    {'vol': 0, 'fee': 0.47},
                    {'vol': 100000, 'fee': 0.40}
                ]
            },
            'DEFAULT': {'trade_fee': 1.50, 'currency': 'USD'},
            'metadata': {
                'venue': 'CME',
                'last_updated': '2024-01-15'
            }
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(fee_config, f)
            config_path = f.name
        
        try:
            schedule = FeeSchedule(config_path)
            
            # Test simple fee info
            mes_info = schedule.get_fee_info('MES')
            assert mes_info['symbol'] == 'MES'
            assert mes_info['venue'] == 'CME'
            assert mes_info['currency'] == 'USD'
            assert mes_info['is_tiered'] is False
            assert mes_info['base_fee'] == 0.35
            
            # Test tiered fee info
            mnq_info = schedule.get_fee_info('MNQ')
            assert mnq_info['symbol'] == 'MNQ'
            assert mnq_info['is_tiered'] is True
            assert 'tiers' in mnq_info
            assert len(mnq_info['tiers']) == 2
            
            # Test venue info
            venue_info = schedule.get_venue_info()
            assert venue_info['venue'] == 'CME'
            assert venue_info['last_updated'] == '2024-01-15'
            assert venue_info['symbols_count'] == 2  # MES and MNQ (excluding DEFAULT)
            
            # Test symbol listing
            symbols = schedule.list_symbols()
            assert 'MES' in symbols
            assert 'MNQ' in symbols
            assert 'DEFAULT' not in symbols
            
        finally:
            Path(config_path).unlink()
    
    def test_config_validation(self):
        """Test configuration validation."""
        # Test valid config
        valid_config = {
            'MES': {'trade_fee': 0.35, 'currency': 'USD'},
            'DEFAULT': {'trade_fee': 1.50, 'currency': 'USD'}
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(valid_config, f)
            config_path = f.name
        
        try:
            # Should not raise exception
            assert validate_fee_config(config_path) is True
        finally:
            Path(config_path).unlink()
        
        # Test invalid config - missing DEFAULT
        invalid_config = {
            'MES': {'trade_fee': 0.35, 'currency': 'USD'}
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(invalid_config, f)
            config_path = f.name
        
        try:
            with pytest.raises(ValueError, match="DEFAULT"):
                validate_fee_config(config_path)
        finally:
            Path(config_path).unlink()
        
        # Test invalid config - missing fee structure
        invalid_config2 = {
            'MES': {'currency': 'USD'},  # Missing trade_fee or tiers
            'DEFAULT': {'trade_fee': 1.50, 'currency': 'USD'}
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(invalid_config2, f)
            config_path = f.name
        
        try:
            with pytest.raises(ValueError, match="trade_fee.*tiers"):
                validate_fee_config(config_path)
        finally:
            Path(config_path).unlink()
    
    def test_fee_object_validation(self):
        """Test Fee object validation."""
        # Valid fee
        fee = Fee(fee_per_side=0.35, currency='USD', description='Test fee')
        assert fee.fee_per_side == 0.35
        assert fee.currency == 'USD'
        
        # Invalid fee - negative
        with pytest.raises(ValueError, match="negative"):
            Fee(fee_per_side=-0.35)
    
    def test_realistic_trading_scenario(self):
        """Test realistic CME micro futures trading scenario."""
        # Realistic CME fee structure
        cme_config = {
            'MES': {'trade_fee': 0.35, 'currency': 'USD', 'description': 'Micro E-mini S&P 500'},
            'MNQ': {'trade_fee': 0.47, 'currency': 'USD', 'description': 'Micro E-mini NASDAQ-100'},
            'M2K': {'trade_fee': 0.25, 'currency': 'USD', 'description': 'Micro E-mini Russell 2000'},
            'MCL': {'trade_fee': 0.74, 'currency': 'USD', 'description': 'Micro WTI Crude Oil'},
            'ES': {'trade_fee': 1.28, 'currency': 'USD', 'description': 'E-mini S&P 500'},
            'DEFAULT': {'trade_fee': 1.50, 'currency': 'USD'},
            'metadata': {
                'venue': 'CME',
                'last_updated': '2024-01-15',
                'source': 'CME Group fee schedule'
            }
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(cme_config, f)
            config_path = f.name
        
        try:
            schedule = FeeSchedule(config_path)
            
            # Simulate a day of trading
            trades = [
                ('MES', 20),   # Open 20 micro S&P contracts
                ('MNQ', 10),   # Open 10 micro NASDAQ contracts  
                ('M2K', 15),   # Open 15 micro Russell contracts
                ('MCL', 5),    # Open 5 micro crude contracts
                ('MES', 10),   # Close 10 S&P contracts
                ('MNQ', 10),   # Close all NASDAQ contracts
                ('M2K', 15),   # Close all Russell contracts
                ('MCL', 5),    # Close all crude contracts
                ('MES', 10)    # Close remaining S&P contracts
            ]
            
            total_fees = 0
            fees_by_symbol = {}
            
            for symbol, quantity in trades:
                fee = schedule.calculate_total_fee(symbol, quantity)
                total_fees += fee
                fees_by_symbol[symbol] = fees_by_symbol.get(symbol, 0) + fee
            
            # Expected fees:
            # MES: (20 + 10 + 10) × $0.35 = $14.00
            # MNQ: (10 + 10) × $0.47 = $9.40
            # M2K: (15 + 15) × $0.25 = $7.50
            # MCL: (5 + 5) × $0.74 = $7.40
            # Total: $38.30
            
            expected_fees = {
                'MES': 40 * 0.35,  # $14.00
                'MNQ': 20 * 0.47,  # $9.40
                'M2K': 30 * 0.25,  # $7.50
                'MCL': 10 * 0.74   # $7.40
            }
            expected_total = sum(expected_fees.values())  # $38.30
            
            assert abs(total_fees - expected_total) < 0.01
            
            for symbol, expected_fee in expected_fees.items():
                assert abs(fees_by_symbol[symbol] - expected_fee) < 0.01
            
            print(f"\nRealistic Trading Scenario Results:")
            print(f"Total contracts traded: {sum(q for _, q in trades)}")
            print(f"Total fees: ${total_fees:.2f}")
            print(f"Fees by symbol: {fees_by_symbol}")
            print(f"Average fee per contract: ${total_fees / sum(q for _, q in trades):.3f}")
            
        finally:
            Path(config_path).unlink()


if __name__ == '__main__':
    pytest.main([__file__, '-v'])