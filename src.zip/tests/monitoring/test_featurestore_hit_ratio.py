#!/usr/bin/env python3
"""
Unit tests for FeatureStore hit ratio metrics and SLO monitoring.

Tests the Prometheus metrics integration for cache hit/miss tracking
and hit ratio calculation functionality.
"""

import pytest
import pandas as pd
import numpy as np
from unittest.mock import Mock, patch, MagicMock
from datetime import datetime, timedelta
import tempfile
import shutil
from pathlib import Path

# Import the FeatureStore and metrics
import sys
sys.path.append('src')

from shared.feature_store import FeatureStore, FEATURE_HITS, FEATURE_MISS, FEATURE_HIT_RT, _update_hit_ratio


class TestFeatureStoreHitRatioMetrics:
    """Test suite for FeatureStore hit ratio SLO metrics."""
    
    @pytest.fixture
    def temp_cache_dir(self):
        """Create temporary cache directory for testing."""
        temp_dir = tempfile.mkdtemp()
        yield temp_dir
        shutil.rmtree(temp_dir)
    
    @pytest.fixture
    def feature_store(self, temp_cache_dir):
        """Create FeatureStore instance for testing."""
        return FeatureStore(root=temp_cache_dir)
    
    @pytest.fixture
    def sample_data(self):
        """Create sample OHLCV data for testing."""
        dates = pd.date_range(start='2023-01-01', end='2023-01-10', freq='1H')
        data = {
            'open': np.random.uniform(100, 110, len(dates)),
            'high': np.random.uniform(110, 120, len(dates)),
            'low': np.random.uniform(90, 100, len(dates)),
            'close': np.random.uniform(100, 110, len(dates)),
            'volume': np.random.uniform(1000, 10000, len(dates))
        }
        return pd.DataFrame(data, index=dates)
    
    @pytest.fixture
    def sample_config(self):
        """Sample feature configuration."""
        return {
            'rsi_window': 14,
            'ema_windows': [10, 20],
            'features': ['rsi', 'ema']
        }
    
    def test_hit_ratio_gauge_direct_access(self):
        """Test direct access to hit ratio gauge."""
        # Test setting and getting hit ratio
        FEATURE_HIT_RT.set(0.93)
        
        # Note: Direct access to _value.get() may not work with all Prometheus client versions
        # This test verifies the gauge can be set without errors
        assert True  # If we get here without exception, the gauge works
    
    def test_metrics_counters_increment(self):
        """Test that hit and miss counters can be incremented."""
        # Get initial values (may be from previous tests)
        initial_hits = 0
        initial_misses = 0
        
        # Increment counters
        FEATURE_HITS.labels(symbol="TEST").inc()
        FEATURE_MISS.labels(symbol="TEST").inc()
        
        # Verify counters can be incremented without errors
        assert True  # If we get here without exception, counters work
    
    def test_update_hit_ratio_function(self):
        """Test the hit ratio update function."""
        # This function should handle cases where metrics are not available
        try:
            _update_hit_ratio()
            assert True  # Function executed without error
        except Exception as e:
            pytest.fail(f"_update_hit_ratio() raised an exception: {e}")
    
    def test_cache_hit_increments_metrics(self, feature_store, sample_data, sample_config):
        """Test that cache hits increment the hit counter."""
        symbol = "TEST_HIT"
        
        # Mock compute function
        def mock_compute_func(df, config):
            return pd.DataFrame({'feature1': [1, 2, 3]}, index=df.index[:3])
        
        # First call should be a miss (cache empty)
        with patch.object(FEATURE_MISS, 'labels') as mock_miss_labels:
            mock_miss_counter = Mock()
            mock_miss_labels.return_value = mock_miss_counter
            
            result1 = feature_store.get_or_compute(
                symbol=symbol,
                raw_df=sample_data,
                config=sample_config,
                compute_func=mock_compute_func
            )
            
            # Verify miss counter was called
            mock_miss_labels.assert_called_with(symbol=symbol)
            mock_miss_counter.inc.assert_called_once()
        
        # Second call should be a hit (cache populated)
        with patch.object(FEATURE_HITS, 'labels') as mock_hit_labels:
            mock_hit_counter = Mock()
            mock_hit_labels.return_value = mock_hit_counter
            
            result2 = feature_store.get_or_compute(
                symbol=symbol,
                raw_df=sample_data,
                config=sample_config,
                compute_func=mock_compute_func
            )
            
            # Verify hit counter was called
            mock_hit_labels.assert_called_with(symbol=symbol)
            mock_hit_counter.inc.assert_called_once()
    
    def test_cache_miss_increments_metrics(self, feature_store, sample_data, sample_config):
        """Test that cache misses increment the miss counter."""
        symbol = "TEST_MISS"
        
        # Mock compute function
        def mock_compute_func(df, config):
            return pd.DataFrame({'feature1': [1, 2, 3]}, index=df.index[:3])
        
        with patch.object(FEATURE_MISS, 'labels') as mock_miss_labels:
            mock_miss_counter = Mock()
            mock_miss_labels.return_value = mock_miss_counter
            
            # First call should always be a miss
            result = feature_store.get_or_compute(
                symbol=symbol,
                raw_df=sample_data,
                config=sample_config,
                compute_func=mock_compute_func
            )
            
            # Verify miss counter was incremented
            mock_miss_labels.assert_called_with(symbol=symbol)
            mock_miss_counter.inc.assert_called_once()
    
    def test_hit_ratio_calculation_with_mocked_metrics(self):
        """Test hit ratio calculation with mocked metric values."""
        with patch('shared.feature_store.FEATURE_HITS') as mock_hits, \
             patch('shared.feature_store.FEATURE_MISS') as mock_misses, \
             patch('shared.feature_store.FEATURE_HIT_RT') as mock_ratio:
            
            # Mock the metrics structure
            mock_hits._metrics = {
                'symbol1': Mock(get=Mock(return_value=80)),
                'symbol2': Mock(get=Mock(return_value=20))
            }
            mock_misses._metrics = {
                'symbol1': Mock(get=Mock(return_value=15)),
                'symbol2': Mock(get=Mock(return_value=5))
            }
            
            # Call update function
            _update_hit_ratio()
            
            # Verify hit ratio was calculated correctly
            # Total hits: 80 + 20 = 100
            # Total misses: 15 + 5 = 20
            # Hit ratio: 100 / (100 + 20) = 0.833...
            expected_ratio = 100 / 120
            mock_ratio.set.assert_called_once_with(expected_ratio)
    
    def test_prometheus_unavailable_graceful_handling(self):
        """Test that metrics work gracefully when Prometheus is unavailable."""
        # This test verifies that the mock classes work correctly
        from shared.feature_store import PROMETHEUS_AVAILABLE
        
        if not PROMETHEUS_AVAILABLE:
            # When Prometheus is not available, operations should not raise errors
            FEATURE_HITS.labels(symbol="TEST").inc()
            FEATURE_MISS.labels(symbol="TEST").inc()
            FEATURE_HIT_RT.set(0.95)
            _update_hit_ratio()
            
            # If we reach here, graceful handling works
            assert True
        else:
            # When Prometheus is available, test that real metrics work
            FEATURE_HITS.labels(symbol="TEST").inc()
            FEATURE_MISS.labels(symbol="TEST").inc()
            FEATURE_HIT_RT.set(0.95)
            _update_hit_ratio()
            
            assert True
    
    def test_multiple_symbols_hit_ratio_tracking(self, feature_store, sample_data, sample_config):
        """Test hit ratio tracking across multiple symbols."""
        symbols = ["AAPL", "GOOGL", "MSFT"]
        
        def mock_compute_func(df, config):
            return pd.DataFrame({'feature1': [1, 2, 3]}, index=df.index[:3])
        
        # Track calls to metrics
        hit_calls = []
        miss_calls = []
        
        def track_hit_calls(symbol):
            hit_calls.append(symbol)
            return Mock(inc=Mock())
        
        def track_miss_calls(symbol):
            miss_calls.append(symbol)
            return Mock(inc=Mock())
        
        with patch.object(FEATURE_HITS, 'labels', side_effect=track_hit_calls), \
             patch.object(FEATURE_MISS, 'labels', side_effect=track_miss_calls):
            
            # First calls should all be misses
            for symbol in symbols:
                feature_store.get_or_compute(
                    symbol=symbol,
                    raw_df=sample_data,
                    config=sample_config,
                    compute_func=mock_compute_func
                )
            
            # Second calls should all be hits
            for symbol in symbols:
                feature_store.get_or_compute(
                    symbol=symbol,
                    raw_df=sample_data,
                    config=sample_config,
                    compute_func=mock_compute_func
                )
            
            # Verify all symbols were tracked for both hits and misses
            assert len(miss_calls) == len(symbols)  # First calls were misses
            assert len(hit_calls) == len(symbols)   # Second calls were hits
            assert set(miss_calls) == set(symbols)
            assert set(hit_calls) == set(symbols)


class TestPrometheusRulesValidation:
    """Test Prometheus alerting rules syntax and logic."""
    
    def test_prometheus_rules_file_exists(self):
        """Test that the Prometheus rules file exists."""
        rules_file = Path("config/prometheus/featurestore_rules.yml")
        assert rules_file.exists(), f"Prometheus rules file not found: {rules_file}"
    
    def test_prometheus_rules_yaml_syntax(self):
        """Test that the Prometheus rules file has valid YAML syntax."""
        import yaml
        
        rules_file = Path("config/prometheus/featurestore_rules.yml")
        try:
            with open(rules_file, 'r') as f:
                yaml.safe_load(f)
        except yaml.YAMLError as e:
            pytest.fail(f"Invalid YAML syntax in rules file: {e}")
    
    def test_prometheus_rules_structure(self):
        """Test that the Prometheus rules have the expected structure."""
        import yaml
        
        rules_file = Path("config/prometheus/featurestore_rules.yml")
        with open(rules_file, 'r') as f:
            rules = yaml.safe_load(f)
        
        # Verify basic structure
        assert 'groups' in rules
        assert isinstance(rules['groups'], list)
        assert len(rules['groups']) > 0
        
        # Check for expected rule groups
        group_names = [group['name'] for group in rules['groups']]
        assert 'featurestore.slo' in group_names
        assert 'featurestore.alerts' in group_names
    
    def test_slo_alert_configuration(self):
        """Test that the main SLO alert is properly configured."""
        import yaml
        
        rules_file = Path("config/prometheus/featurestore_rules.yml")
        with open(rules_file, 'r') as f:
            rules = yaml.safe_load(f)
        
        # Find the alerts group
        alerts_group = None
        for group in rules['groups']:
            if group['name'] == 'featurestore.alerts':
                alerts_group = group
                break
        
        assert alerts_group is not None, "featurestore.alerts group not found"
        
        # Find the main SLO alert
        slo_alert = None
        for rule in alerts_group['rules']:
            if rule.get('alert') == 'FeatureStoreHitRatioLow':
                slo_alert = rule
                break
        
        assert slo_alert is not None, "FeatureStoreHitRatioLow alert not found"
        
        # Verify alert configuration
        assert 'expr' in slo_alert
        assert 'for' in slo_alert
        assert slo_alert['for'] == '10m'
        assert 'labels' in slo_alert
        assert slo_alert['labels']['severity'] == 'warning'


if __name__ == "__main__":
    pytest.main([__file__, "-v"])