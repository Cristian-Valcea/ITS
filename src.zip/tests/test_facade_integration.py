#!/usr/bin/env python3
"""
Integration tests for façade delegation patterns.

Tests that the façade classes properly delegate to their core components
and maintain backward compatibility while providing the new modular architecture.
"""

import pytest
from unittest.mock import MagicMock, patch
import tempfile
import shutil
from pathlib import Path

# Import façade classes
try:
    from src.execution.orchestrator_agent import OrchestratorAgent
    from src.training.trainer_agent import TrainerAgent, create_trainer_agent
    FACADES_AVAILABLE = True
except ImportError:
    OrchestratorAgent = None
    TrainerAgent = None
    create_trainer_agent = None
    FACADES_AVAILABLE = False

@pytest.fixture
def orchestrator_config():
    """Mock configuration for OrchestratorAgent."""
    return {
        'execution': {
            'loop_interval_ms': 100,
            'max_latency_ms': 50
        },
        'data': {
            'symbols': ['AAPL', 'MSFT'],
            'provider': 'IBKR'
        },
        'routing': {
            'default_venue': 'IBKR'
        },
        'pnl': {
            'base_currency': 'USD'
        }
    }

@pytest.fixture
def trainer_config():
    """Mock configuration for TrainerAgent."""
    return {
        'algorithm': 'DQN',
        'model_save_dir': 'test_models',
        'log_dir': 'test_logs',
        'algo_params': {
            'learning_rate': 0.001,
            'buffer_size': 10000
        },
        'training_params': {
            'total_timesteps': 1000
        },
        'risk_config': {
            'enabled': True
        }
    }

@pytest.fixture
def temp_dirs():
    """Create temporary directories for testing."""
    temp_dir = Path(tempfile.mkdtemp())
    model_dir = temp_dir / "models"
    log_dir = temp_dir / "logs"
    
    model_dir.mkdir()
    log_dir.mkdir()
    
    yield {
        'temp_dir': temp_dir,
        'model_dir': model_dir,
        'log_dir': log_dir
    }
    
    # Cleanup
    shutil.rmtree(temp_dir, ignore_errors=True)

@pytest.mark.skipif(not FACADES_AVAILABLE, reason="Façade classes not available")
class TestOrchestratorFacade:
    """Test suite for OrchestratorAgent façade delegation."""
    
    def test_orchestrator_initialization(self, orchestrator_config):
        """Test OrchestratorAgent initialization and core component creation."""
        with patch('src.execution.orchestrator_agent.ExecutionLoop') as mock_loop:
            with patch('src.execution.orchestrator_agent.OrderRouter') as mock_router:
                with patch('src.execution.orchestrator_agent.PnLTracker') as mock_pnl:
                    with patch('src.execution.orchestrator_agent.LiveDataLoader') as mock_loader:
                        
                        agent = OrchestratorAgent(orchestrator_config)
                        
                        # Verify core components are created
                        assert hasattr(agent, 'loop')
                        assert hasattr(agent, 'order_router')
                        assert hasattr(agent, 'pnl_tracker')
                        assert hasattr(agent, 'data_loader')
                        
                        # Verify components are instances of core classes
                        mock_loop.assert_called_once()
                        mock_router.assert_called_once()
                        mock_pnl.assert_called_once()
                        mock_loader.assert_called_once()
    
    def test_orchestrator_delegation(self, orchestrator_config):
        """Test that OrchestratorAgent properly delegates to core components."""
        with patch('src.execution.orchestrator_agent.ExecutionLoop') as mock_loop_class:
            with patch('src.execution.orchestrator_agent.OrderRouter') as mock_router_class:
                
                # Create mock instances
                mock_loop = MagicMock()
                mock_router = MagicMock()
                mock_loop_class.return_value = mock_loop
                mock_router_class.return_value = mock_router
                
                agent = OrchestratorAgent(orchestrator_config)
                
                # Test delegation to execution loop
                agent.start_execution()
                mock_loop.start.assert_called_once()
                
                # Test delegation to order router
                mock_order = {'symbol': 'AAPL', 'quantity': 100}
                agent.route_order(mock_order)
                mock_router.route_order.assert_called_once_with(mock_order)
    
    def test_orchestrator_property_delegation(self, orchestrator_config):
        """Test property delegation in OrchestratorAgent."""
        with patch('src.execution.orchestrator_agent.ExecutionLoop') as mock_loop_class:
            with patch('src.execution.orchestrator_agent.PnLTracker') as mock_pnl_class:
                
                # Create mock instances with properties
                mock_loop = MagicMock()
                mock_pnl = MagicMock()
                mock_loop.is_running = True
                mock_pnl.total_pnl = 1500.0
                
                mock_loop_class.return_value = mock_loop
                mock_pnl_class.return_value = mock_pnl
                
                agent = OrchestratorAgent(orchestrator_config)
                
                # Test property delegation
                assert agent.is_running == True
                assert agent.total_pnl == 1500.0
    
    def test_orchestrator_backward_compatibility(self, orchestrator_config):
        """Test backward compatibility of OrchestratorAgent interface."""
        # Test that old method names still work
        with patch('src.execution.orchestrator_agent.ExecutionLoop'):
            with patch('src.execution.orchestrator_agent.OrderRouter'):
                with patch('src.execution.orchestrator_agent.PnLTracker'):
                    with patch('src.execution.orchestrator_agent.LiveDataLoader'):
                        
                        agent = OrchestratorAgent(orchestrator_config)
                        
                        # These methods should exist for backward compatibility
                        assert hasattr(agent, 'start_execution')
                        assert hasattr(agent, 'stop_execution')
                        assert hasattr(agent, 'route_order')
                        assert hasattr(agent, 'get_pnl')
                        assert hasattr(agent, 'get_positions')


@pytest.mark.skipif(not FACADES_AVAILABLE, reason="Façade classes not available")
class TestTrainerFacade:
    """Test suite for TrainerAgent façade delegation."""
    
    def test_trainer_initialization(self, trainer_config, temp_dirs):
        """Test TrainerAgent initialization and core component creation."""
        trainer_config['model_save_dir'] = str(temp_dirs['model_dir'])
        trainer_config['log_dir'] = str(temp_dirs['log_dir'])
        
        with patch('src.training.trainer_agent.TrainerCore') as mock_core_class:
            mock_core = MagicMock()
            mock_core_class.return_value = mock_core
            
            agent = TrainerAgent(trainer_config)
            
            # Verify core component is created
            assert hasattr(agent, 'trainer_core')
            mock_core_class.assert_called_once_with(trainer_config)
    
    def test_trainer_delegation(self, trainer_config, temp_dirs):
        """Test that TrainerAgent properly delegates to TrainerCore."""
        trainer_config['model_save_dir'] = str(temp_dirs['model_dir'])
        trainer_config['log_dir'] = str(temp_dirs['log_dir'])
        
        with patch('src.training.trainer_agent.TrainerCore') as mock_core_class:
            mock_core = MagicMock()
            mock_core.train.return_value = 'model_path.zip'
            mock_core.evaluate_model.return_value = {'mean_reward': 100.0}
            mock_core_class.return_value = mock_core
            
            agent = TrainerAgent(trainer_config)
            
            # Test delegation to core
            mock_env = MagicMock()
            result = agent.train(mock_env)
            
            mock_core.train.assert_called_once_with(mock_env)
            assert result == 'model_path.zip'
            
            # Test evaluation delegation
            metrics = agent.evaluate_model(mock_env)
            mock_core.evaluate_model.assert_called_once_with(mock_env)
            assert metrics['mean_reward'] == 100.0
    
    def test_trainer_property_delegation(self, trainer_config, temp_dirs):
        """Test property delegation in TrainerAgent."""
        trainer_config['model_save_dir'] = str(temp_dirs['model_dir'])
        trainer_config['log_dir'] = str(temp_dirs['log_dir'])
        
        with patch('src.training.trainer_agent.TrainerCore') as mock_core_class:
            mock_core = MagicMock()
            mock_core.algorithm_name = 'DQN'
            mock_core.model = MagicMock()
            mock_core_class.return_value = mock_core
            
            agent = TrainerAgent(trainer_config)
            
            # Test property delegation
            assert agent.algorithm_name == 'DQN'
            assert agent.model is not None
    
    def test_trainer_backward_compatibility(self, trainer_config, temp_dirs):
        """Test backward compatibility of TrainerAgent interface."""
        trainer_config['model_save_dir'] = str(temp_dirs['model_dir'])
        trainer_config['log_dir'] = str(temp_dirs['log_dir'])
        
        with patch('src.training.trainer_agent.TrainerCore') as mock_core_class:
            mock_core = MagicMock()
            mock_core_class.return_value = mock_core
            
            agent = TrainerAgent(trainer_config)
            
            # These methods should exist for backward compatibility
            assert hasattr(agent, 'train')
            assert hasattr(agent, 'evaluate_model')
            assert hasattr(agent, 'save_model')
            assert hasattr(agent, 'load_model')
            assert hasattr(agent, 'get_hyperparameters')
    
    def test_factory_function(self, trainer_config, temp_dirs):
        """Test create_trainer_agent factory function."""
        trainer_config['model_save_dir'] = str(temp_dirs['model_dir'])
        trainer_config['log_dir'] = str(temp_dirs['log_dir'])
        
        with patch('src.training.trainer_agent.TrainerCore'):
            agent = create_trainer_agent(trainer_config)
            
            assert isinstance(agent, TrainerAgent)
            assert agent.config == trainer_config


class TestFacadeMock:
    """Test suite using mock façades when real ones aren't available."""
    
    def test_mock_orchestrator_facade(self, orchestrator_config):
        """Test with mock OrchestratorAgent façade."""
        # Create a mock façade
        class MockOrchestratorAgent:
            def __init__(self, config):
                self.config = config
                self.loop = MagicMock()
                self.order_router = MagicMock()
                self.pnl_tracker = MagicMock()
                self.data_loader = MagicMock()
                
                # Set up mock properties
                self.loop.is_running = False
                self.pnl_tracker.total_pnl = 0.0
            
            def start_execution(self):
                self.loop.start()
                self.loop.is_running = True
            
            def stop_execution(self):
                self.loop.stop()
                self.loop.is_running = False
            
            def route_order(self, order):
                return self.order_router.route_order(order)
            
            @property
            def is_running(self):
                return self.loop.is_running
            
            @property
            def total_pnl(self):
                return self.pnl_tracker.total_pnl
        
        agent = MockOrchestratorAgent(orchestrator_config)
        
        # Test core components exist
        assert hasattr(agent, 'loop')
        assert hasattr(agent, 'order_router')
        assert hasattr(agent, 'pnl_tracker')
        assert hasattr(agent, 'data_loader')
        
        # Test delegation
        agent.start_execution()
        agent.loop.start.assert_called_once()
        assert agent.is_running is True
        
        # Test order routing
        mock_order = {'symbol': 'AAPL'}
        agent.route_order(mock_order)
        agent.order_router.route_order.assert_called_once_with(mock_order)
    
    def test_mock_trainer_facade(self, trainer_config, temp_dirs):
        """Test with mock TrainerAgent façade."""
        # Create a mock façade
        class MockTrainerAgent:
            def __init__(self, config):
                self.config = config
                self.trainer_core = MagicMock()
                
                # Set up mock properties
                self.trainer_core.algorithm_name = config['algorithm']
                self.trainer_core.model = None
            
            def train(self, env):
                return self.trainer_core.train(env)
            
            def evaluate_model(self, env):
                return self.trainer_core.evaluate_model(env)
            
            @property
            def algorithm_name(self):
                return self.trainer_core.algorithm_name
            
            @property
            def model(self):
                return self.trainer_core.model
        
        def mock_create_trainer_agent(config):
            return MockTrainerAgent(config)
        
        trainer_config['model_save_dir'] = str(temp_dirs['model_dir'])
        trainer_config['log_dir'] = str(temp_dirs['log_dir'])
        
        agent = MockTrainerAgent(trainer_config)
        
        # Test core component exists
        assert hasattr(agent, 'trainer_core')
        
        # Test delegation
        mock_env = MagicMock()
        agent.train(mock_env)
        agent.trainer_core.train.assert_called_once_with(mock_env)
        
        # Test properties
        assert agent.algorithm_name == 'DQN'
        
        # Test factory function
        factory_agent = mock_create_trainer_agent(trainer_config)
        assert isinstance(factory_agent, MockTrainerAgent)


@pytest.mark.integration
class TestFullFacadeIntegration:
    """Integration tests for full façade functionality."""
    
    @pytest.mark.skipif(not FACADES_AVAILABLE, reason="Façade classes not available")
    def test_orchestrator_trainer_integration(self, orchestrator_config, trainer_config, temp_dirs):
        """Test integration between OrchestratorAgent and TrainerAgent."""
        trainer_config['model_save_dir'] = str(temp_dirs['model_dir'])
        trainer_config['log_dir'] = str(temp_dirs['log_dir'])
        
        # This would test real integration when all dependencies are available
        # For now, we'll skip if components aren't fully available
        pytest.skip("Full integration test requires all dependencies")
    
    def test_legacy_import_compatibility(self):
        """Test that legacy import paths still work."""
        try:
            # Test legacy imports
            from src.agents.trainer_agent import TrainerAgent as LegacyTrainer
            from src.agents.orchestrator_agent import OrchestratorAgent as LegacyOrchestrator
            
            # Test that they are the same classes as new imports
            from src.training.trainer_agent import TrainerAgent as NewTrainer
            from src.execution.orchestrator_agent import OrchestratorAgent as NewOrchestrator
            
            assert LegacyTrainer is NewTrainer
            assert LegacyOrchestrator is NewOrchestrator
            
        except ImportError:
            # If imports fail due to dependencies, that's expected
            pytest.skip("Legacy imports not available due to dependencies")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])