"""
fx_lifecycle.py – Simple, self-contained lifecycle guard for FX pairs
======================================================================

GOAL
-----
Filter any OHLC/tick DataFrame so that prices outside the 'active window'
(start_date ≤ timestamp ≤ end_date) are dropped or NaN-padded, preventing
FX survivorship bias in training / back-tests.

USAGE
-----
# 1) Build once from vendor feeds / manual CSV
FxLifecycleBuilder().from_bloomberg(bbg_df)           \
                    .from_iso4217("iso_4217.csv")      \
                    .from_broker_fix("fix_sec_list.csv") \
                    .to_parquet("fx_lifecycle.parquet")

# 2) Load in feature pipeline
guard = FxLifecycle("fx_lifecycle.parquet")
clean_df = guard.apply(df, pair="USDTRY")     # rows outside life-span dropped
"""

import pandas as pd
import numpy as np
from pathlib import Path
from datetime import date, datetime
from typing import Dict, List, Optional, Union, Tuple
import logging


class FxLifecycle:
    """
    Lightweight lookup object backed by a parquet table
    columns: symbol | start_date | end_date | status | source
    
    Prevents survivorship bias by filtering FX data to only include
    periods when currency pairs were actively tradeable.
    """
    
    def __init__(self, parquet_path: Union[str, Path]):
        """
        Initialize FX lifecycle guard from parquet file.
        
        Args:
            parquet_path: Path to parquet file with FX lifecycle data
        """
        self.parquet_path = Path(parquet_path)
        if not self.parquet_path.exists():
            raise FileNotFoundError(f"FX lifecycle data not found: {parquet_path}")
            
        # Load lifecycle data
        self.tab = pd.read_parquet(parquet_path)
        self.tab['start_date'] = pd.to_datetime(self.tab['start_date'])
        self.tab['end_date'] = pd.to_datetime(self.tab['end_date'])
        
        # Create fast lookup index
        self._idx = {
            symbol: (start_date, end_date) 
            for symbol, start_date, end_date in 
            self.tab[['symbol', 'start_date', 'end_date']].itertuples(index=False)
        }
        
        self.logger = logging.getLogger(__name__)
        self.logger.info(f"FxLifecycle initialized with {len(self._idx)} currency pairs")
    
    def is_active(self, symbol: str, ts: pd.Timestamp) -> bool:
        """
        Check if FX pair was active (tradeable) at given timestamp.
        
        Args:
            symbol: FX pair symbol (e.g., "EURUSD", "USDTRY")
            ts: Timestamp to check
            
        Returns:
            True if pair was active, False if inactive/delisted
        """
        if symbol not in self._idx:
            # Unknown pair -> treat as inactive to be conservative
            self.logger.warning(f"Unknown FX pair {symbol} - treating as inactive")
            return False
            
        start_date, end_date = self._idx[symbol]
        return start_date <= ts <= end_date
    
    def apply(self, df: pd.DataFrame, pair: str, mode: str = "drop") -> pd.DataFrame:
        """
        Apply lifecycle filtering to DataFrame.
        
        Args:
            df: DataFrame with datetime index and OHLC/price columns
            pair: FX pair symbol
            mode: "drop" to delete rows outside life-span,
                  "mask" to keep rows but set NaN for price columns
                  
        Returns:
            Filtered DataFrame
        """
        if pair not in self._idx:
            raise KeyError(f"FX pair {pair} missing from lifecycle database. "
                          f"Available pairs: {sorted(self._idx.keys())}")
        
        start_date, end_date = self._idx[pair]
        
        # Create boolean mask for active window
        if hasattr(df.index, 'to_series'):
            # DatetimeIndex
            in_window = df.index.to_series().between(start_date, end_date)
        else:
            # Regular index - assume datetime column exists
            if 'datetime' in df.columns:
                in_window = df['datetime'].between(start_date, end_date)
            elif 'timestamp' in df.columns:
                in_window = df['timestamp'].between(start_date, end_date)
            else:
                raise ValueError(f"DataFrame must have datetime index or datetime/timestamp column")
        
        if mode == "drop":
            # Drop rows outside active window
            filtered_df = df.loc[in_window].copy()
            dropped_rows = len(df) - len(filtered_df)
            if dropped_rows > 0:
                self.logger.info(f"Dropped {dropped_rows} rows outside active window for {pair}")
            return filtered_df
            
        elif mode == "mask":
            # Keep rows but mask price columns with NaN
            mask = ~in_window
            price_cols = ["open", "high", "low", "close", "bid", "ask", "mid", "price"]
            common_price_cols = [col for col in price_cols if col in df.columns]
            
            df_masked = df.copy()
            df_masked.loc[mask, common_price_cols] = pd.NA
            
            masked_rows = mask.sum()
            if masked_rows > 0:
                self.logger.info(f"Masked {masked_rows} rows outside active window for {pair}")
            return df_masked
            
        else:
            raise ValueError("mode must be 'drop' or 'mask'")


class FxLifecycleBuilder:
    """
    Builder class for creating FX lifecycle databases from various sources.
    """
    
    def __init__(self):
        self.rows: List[Dict] = []
        self.logger = logging.getLogger(__name__)
    
    def add(self, symbol: str, start: date, end: date, status: str, source: str) -> 'FxLifecycleBuilder':
        """Add a single FX pair lifecycle entry."""
        self.rows.append({
            "symbol": symbol,
            "start_date": pd.Timestamp(start),
            "end_date": pd.Timestamp(end),
            "status": status,
            "source": source
        })
        return self
    
    def from_bloomberg(self, df: pd.DataFrame) -> 'FxLifecycleBuilder':
        """Load FX lifecycle data from Bloomberg terminal export."""
        required_cols = ['TICKER', 'FIRST_TRADE_DT', 'LAST_TRADE_DT', 'SEC_STATUS']
        missing_cols = [col for col in required_cols if col not in df.columns]
        if missing_cols:
            raise ValueError(f"Bloomberg DataFrame missing columns: {missing_cols}")
        
        for row in df.itertuples(index=False):
            end_date = (row.LAST_TRADE_DT.date() 
                       if pd.notna(row.LAST_TRADE_DT) 
                       else date.max)
            
            self.add(
                symbol=row.TICKER,
                start=row.FIRST_TRADE_DT.date(),
                end=end_date,
                status=row.SEC_STATUS,
                source="Bloomberg"
            )
        
        self.logger.info(f"Added {len(df)} FX pairs from Bloomberg data")
        return self
    
    def from_iso4217(self, csv_path: Union[str, Path]) -> 'FxLifecycleBuilder':
        """Load currency lifecycle data from ISO 4217 history CSV."""
        csv_path = Path(csv_path)
        if not csv_path.exists():
            self.logger.warning(f"ISO 4217 file not found: {csv_path}")
            return self
        
        iso_df = pd.read_csv(csv_path, parse_dates=["start", "end"])
        
        for row in iso_df.itertuples(index=False):
            end_date = (row.end.date() 
                       if pd.notna(row.end) 
                       else date.max)
            
            # Add both USD/XXX and XXX/USD pairs
            for pair_format in [f"USD{row.code}", f"{row.code}USD"]:
                self.add(
                    symbol=pair_format,
                    start=row.start.date(),
                    end=end_date,
                    status="ISO4217",
                    source="ISO"
                )
        
        self.logger.info(f"Added {len(iso_df) * 2} FX pairs from ISO 4217 data")
        return self
    
    def from_broker_fix(self, csv_path: Union[str, Path]) -> 'FxLifecycleBuilder':
        """Load FX lifecycle data from broker FIX SecurityList snapshots."""
        csv_path = Path(csv_path)
        if not csv_path.exists():
            self.logger.warning(f"Broker FIX file not found: {csv_path}")
            return self
        
        fix_df = pd.read_csv(csv_path, parse_dates=["StartDate", "EndDate"])
        
        for row in fix_df.itertuples(index=False):
            end_date = (row.EndDate.date() 
                       if pd.notna(row.EndDate) 
                       else date.max)
            
            self.add(
                symbol=row.Symbol,
                start=row.StartDate.date(),
                end=end_date,
                status=row.Status,
                source="BrokerFIX"
            )
        
        self.logger.info(f"Added {len(fix_df)} FX pairs from broker FIX data")
        return self
    
    def add_common_pairs(self) -> 'FxLifecycleBuilder':
        """Add commonly traded FX pairs with historical data."""
        # Major pairs (still active)
        major_pairs = [
            {"symbol": "EURUSD", "start": date(1999, 1, 4), "end": date.max, "status": "ACTIVE", "source": "MAJOR"},
            {"symbol": "GBPUSD", "start": date(1971, 8, 15), "end": date.max, "status": "ACTIVE", "source": "MAJOR"},
            {"symbol": "USDJPY", "start": date(1971, 8, 15), "end": date.max, "status": "ACTIVE", "source": "MAJOR"},
            {"symbol": "USDCHF", "start": date(1971, 8, 15), "end": date.max, "status": "ACTIVE", "source": "MAJOR"},
            {"symbol": "AUDUSD", "start": date(1983, 12, 12), "end": date.max, "status": "ACTIVE", "source": "MAJOR"},
            {"symbol": "USDCAD", "start": date(1970, 5, 31), "end": date.max, "status": "ACTIVE", "source": "MAJOR"},
            {"symbol": "NZDUSD", "start": date(1985, 3, 4), "end": date.max, "status": "ACTIVE", "source": "MAJOR"},
        ]
        
        # Historical discontinued pairs
        discontinued_pairs = [
            # European currencies replaced by EUR
            {"symbol": "USDDEM", "start": date(1948, 6, 20), "end": date(2001, 12, 31), 
             "status": "REDENOMINATED", "source": "HISTORICAL"},
            {"symbol": "USDFRF", "start": date(1960, 1, 1), "end": date(2001, 12, 31), 
             "status": "REDENOMINATED", "source": "HISTORICAL"},
            {"symbol": "USDITL", "start": date(1946, 1, 1), "end": date(2001, 12, 31), 
             "status": "REDENOMINATED", "source": "HISTORICAL"},
            {"symbol": "USDESP", "start": date(1868, 1, 1), "end": date(2001, 12, 31), 
             "status": "REDENOMINATED", "source": "HISTORICAL"},
            {"symbol": "USDNLG", "start": date(1816, 1, 1), "end": date(2001, 12, 31), 
             "status": "REDENOMINATED", "source": "HISTORICAL"},
            
            # Emerging market currency crises
            {"symbol": "USDVEF", "start": date(2008, 1, 1), "end": date(2018, 8, 20), 
             "status": "HYPERINFLATION", "source": "HISTORICAL"},
        ]
        
        all_pairs = major_pairs + discontinued_pairs
        for entry in all_pairs:
            self.add(**entry)
        
        self.logger.info(f"Added {len(all_pairs)} common FX pairs")
        return self
    
    def to_parquet(self, out_path: Union[str, Path]) -> None:
        """Save FX lifecycle data to parquet file."""
        if not self.rows:
            raise ValueError("No FX lifecycle data to save. Add some entries first.")
        
        df = pd.DataFrame(self.rows)
        df = df.sort_values('symbol').reset_index(drop=True)
        
        # Ensure output directory exists
        out_path = Path(out_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Save to parquet
        df.to_parquet(out_path, index=False)
        
        self.logger.info(f"Saved {len(df)} FX lifecycle entries to {out_path}")


if __name__ == "__main__":
    # Build sample FX lifecycle database
    print("Building sample FX lifecycle database...")
    
    builder = FxLifecycleBuilder()
    builder.add_common_pairs()
    builder.to_parquet("data/fx_lifecycle.parquet")
    
    print("✅ Sample FX lifecycle database created: data/fx_lifecycle.parquet")
    
    # Test the guard
    if Path("data/fx_lifecycle.parquet").exists():
        guard = FxLifecycle("data/fx_lifecycle.parquet")
        
        # Test current status
        now = pd.Timestamp.now()
        test_pairs = ["EURUSD", "USDDEM", "USDVEF"]
        
        for pair in test_pairs:
            try:
                is_active = guard.is_active(pair, now)
                print(f"{pair}: {'ACTIVE' if is_active else 'INACTIVE'}")
            except:
                print(f"{pair}: NOT FOUND")