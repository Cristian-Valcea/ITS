# src/data/bias_aware_data_agent.py
"""
Bias-Aware Data Agent Extension

This module extends the existing DataAgent with survivorship bias awareness:
1. Point-in-time universe construction
2. Delisting event integration
3. Corporate action handling
4. Bias-free data joins

This ensures that all data fetching operations are free from survivorship bias
by filtering securities at the data-join level, not after the fact.
"""

import pandas as pd
import numpy as np
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Set, Tuple, Union
from pathlib import Path

from ..agents.data_agent import DataAgent
from .survivorship_bias_handler import SurvivorshipBiasHandler, DelistingEvent, UniverseSnapshot


class BiasAwareDataAgent(DataAgent):
    """
    Extended DataAgent that eliminates survivorship bias in data operations.
    
    Key Features:
    - Point-in-time universe filtering
    - Delisting event integration
    - Corporate action adjustments
    - Bias impact reporting
    """
    
    def __init__(self, config: dict, ib_client=None):
        """
        Initialize BiasAwareDataAgent.
        
        Args:
            config: Configuration dictionary with additional bias-related settings:
                   - survivorship_bias_db: Path to survivorship bias database
                   - enable_bias_correction: Whether to apply bias correction
                   - universe_lookback_days: Days to look back for universe construction
            ib_client: Optional IB client instance
        """
        super().__init__(config, ib_client)
        
        # Initialize survivorship bias handler
        bias_db_path = config.get('survivorship_bias_db', 'data/survivorship_bias.db')
        self.survivorship_handler = SurvivorshipBiasHandler(
            db_path=bias_db_path,
            logger=self.logger
        )
        
        # Configuration
        self.enable_bias_correction = config.get('enable_bias_correction', True)
        self.universe_lookback_days = config.get('universe_lookback_days', 252)
        
        # Cache for performance
        self._universe_cache = {}
        self._delisting_cache = {}
        
        self.logger.info(f"BiasAwareDataAgent initialized with bias correction: {self.enable_bias_correction}")
    
    def fetch_universe_data(self,
                          symbols: List[str],
                          start_date: str,
                          end_date: str,
                          as_of_date: Optional[str] = None,
                          include_delisted: bool = True,
                          **kwargs) -> Dict[str, pd.DataFrame]:
        """
        Fetch data for a universe of symbols with survivorship bias correction.
        
        Args:
            symbols: List of symbols to fetch
            start_date: Start date for data
            end_date: End date for data
            as_of_date: Point-in-time date for universe construction (default: end_date)
            include_delisted: Whether to include delisted securities
            **kwargs: Additional arguments for data fetching
            
        Returns:
            Dictionary mapping symbols to their data DataFrames
        """
        if as_of_date is None:
            as_of_date = end_date
        
        as_of_datetime = pd.to_datetime(as_of_date)
        
        # Apply survivorship bias correction
        if self.enable_bias_correction:
            filtered_symbols = self._filter_universe_point_in_time(
                symbols=set(symbols),
                as_of_date=as_of_datetime,
                include_delisted=include_delisted
            )
        else:
            filtered_symbols = symbols
        
        self.logger.info(f"Fetching data for {len(filtered_symbols)}/{len(symbols)} symbols "
                        f"(bias correction: {self.enable_bias_correction})")
        
        # Fetch data for filtered universe
        universe_data = {}
        
        for symbol in filtered_symbols:
            try:
                # Fetch raw data using parent class method
                data = self.fetch_ibkr_bars(
                    symbol=symbol,
                    end_datetime_str=end_date,
                    duration_str=self._calculate_duration(start_date, end_date),
                    **kwargs
                )
                
                if data is not None and not data.empty:
                    # Apply corporate action adjustments
                    adjusted_data = self._apply_corporate_actions(symbol, data, as_of_datetime)
                    
                    # Handle delisting events
                    final_data = self._handle_delisting_in_data(symbol, adjusted_data, as_of_datetime)
                    
                    universe_data[symbol] = final_data
                else:
                    self.logger.warning(f"No data retrieved for {symbol}")
                    
            except Exception as e:
                self.logger.error(f"Error fetching data for {symbol}: {e}")
                continue
        
        # Log bias impact
        self._log_bias_impact(len(symbols), len(universe_data), as_of_datetime)
        
        return universe_data
    
    def _filter_universe_point_in_time(self,
                                     symbols: Set[str],
                                     as_of_date: datetime,
                                     include_delisted: bool = True) -> List[str]:
        """
        Filter universe to point-in-time active securities.
        
        Args:
            symbols: Set of symbols to filter
            as_of_date: Point-in-time date
            include_delisted: Whether to include recently delisted securities
            
        Returns:
            List of filtered symbols
        """
        # Get point-in-time universe snapshot
        universe_snapshot = self.survivorship_handler.get_point_in_time_universe(
            as_of_date=as_of_date,
            base_universe=symbols,
            lookback_days=self.universe_lookback_days
        )
        
        filtered_symbols = list(universe_snapshot.active_symbols)
        
        # Optionally include recently delisted securities
        if include_delisted:
            filtered_symbols.extend(list(universe_snapshot.recently_delisted))
        
        return filtered_symbols
    
    def _apply_corporate_actions(self,
                               symbol: str,
                               data: pd.DataFrame,
                               as_of_date: datetime) -> pd.DataFrame:
        """
        Apply corporate action adjustments to price data.
        
        Args:
            symbol: Stock symbol
            data: Raw price data
            as_of_date: As-of date for adjustments
            
        Returns:
            Adjusted price data
        """
        # This is a placeholder for corporate action adjustments
        # In practice, this would:
        # 1. Query corporate actions database
        # 2. Apply stock splits, dividends, spin-offs
        # 3. Adjust prices and volumes accordingly
        
        adjusted_data = data.copy()
        
        # Example: Apply a simple adjustment factor (placeholder)
        # In reality, this would be based on actual corporate actions
        adjustment_factor = 1.0  # No adjustment for now
        
        price_columns = ['Open', 'High', 'Low', 'Close']
        for col in price_columns:
            if col in adjusted_data.columns:
                adjusted_data[col] *= adjustment_factor
        
        # Adjust volume (inverse of price adjustment)
        if 'Volume' in adjusted_data.columns and adjustment_factor != 0:
            adjusted_data['Volume'] /= adjustment_factor
        
        return adjusted_data
    
    def _handle_delisting_in_data(self,
                                symbol: str,
                                data: pd.DataFrame,
                                as_of_date: datetime) -> pd.DataFrame:
        """
        Handle delisting events in the data.
        
        Args:
            symbol: Stock symbol
            data: Price data
            as_of_date: As-of date
            
        Returns:
            Data with delisting events handled
        """
        # Check for delisting events
        delisting_events = self.survivorship_handler.get_delisting_events(
            symbol=symbol,
            start_date=data.index.min(),
            end_date=as_of_date
        )
        
        if not delisting_events:
            return data
        
        # Handle the most recent delisting event
        delisting_event = delisting_events[0]  # Most recent
        delist_date = delisting_event.delist_date
        
        # Truncate data at delisting date
        if delist_date <= as_of_date:
            data_truncated = data[data.index <= delist_date].copy()
            
            # Add final delisting price if available
            if delisting_event.final_price is not None and not data_truncated.empty:
                last_row = data_truncated.iloc[-1].copy()
                last_row['Close'] = delisting_event.final_price
                last_row['High'] = max(last_row['High'], delisting_event.final_price)
                last_row['Low'] = min(last_row['Low'], delisting_event.final_price)
                last_row['Volume'] = 0  # No trading after delisting
                
                # Update the last row
                data_truncated.iloc[-1] = last_row
            
            self.logger.info(f"Applied delisting adjustment for {symbol} on {delist_date}")
            return data_truncated
        
        return data
    
    def _calculate_duration(self, start_date: str, end_date: str) -> str:
        """Calculate duration string for IBKR API."""
        start_dt = pd.to_datetime(start_date)
        end_dt = pd.to_datetime(end_date)
        days = (end_dt - start_dt).days
        
        if days <= 30:
            return f"{days} D"
        elif days <= 365:
            return f"{days // 7} W"
        else:
            return f"{days // 365} Y"
    
    def _log_bias_impact(self, original_count: int, final_count: int, as_of_date: datetime):
        """Log the impact of survivorship bias correction."""
        if original_count > 0:
            survival_rate = final_count / original_count
            excluded_count = original_count - final_count
            
            self.logger.info(f"Survivorship bias impact for {as_of_date.date()}:")
            self.logger.info(f"  Original universe: {original_count} symbols")
            self.logger.info(f"  Final universe: {final_count} symbols")
            self.logger.info(f"  Excluded (delisted): {excluded_count} symbols")
            self.logger.info(f"  Survival rate: {survival_rate:.1%}")
            
            if survival_rate < 0.90:
                self.logger.warning(f"Low survival rate ({survival_rate:.1%}) - significant bias risk!")
    
    def add_delisting_event(self, event: DelistingEvent) -> bool:
        """
        Add a delisting event to the handler.
        
        Args:
            event: DelistingEvent to add
            
        Returns:
            True if added successfully
        """
        return self.survivorship_handler.add_delisting_event(event)
    
    def load_delisting_data_from_file(self, file_path: str, file_format: str = "csv") -> int:
        """
        Load delisting data from external file.
        
        Args:
            file_path: Path to delisting data file
            file_format: File format ("csv", "excel", "crsp")
            
        Returns:
            Number of delisting events loaded
        """
        try:
            if file_format.lower() == "crsp":
                return self.survivorship_handler.load_crsp_delisting_data(file_path)
            
            elif file_format.lower() == "csv":
                return self._load_csv_delisting_data(file_path)
            
            elif file_format.lower() == "excel":
                return self._load_excel_delisting_data(file_path)
            
            else:
                self.logger.error(f"Unsupported file format: {file_format}")
                return 0
                
        except Exception as e:
            self.logger.error(f"Error loading delisting data from {file_path}: {e}")
            return 0
    
    def _load_csv_delisting_data(self, file_path: str) -> int:
        """Load delisting data from CSV file."""
        df = pd.read_csv(file_path)
        
        required_columns = ['symbol', 'delist_date', 'reason_code']
        if not all(col in df.columns for col in required_columns):
            raise ValueError(f"CSV must contain columns: {required_columns}")
        
        events_loaded = 0
        
        for _, row in df.iterrows():
            try:
                event = DelistingEvent(
                    symbol=row['symbol'],
                    delist_date=pd.to_datetime(row['delist_date']),
                    reason_code=str(row['reason_code']),
                    reason_desc=row.get('reason_desc', ''),
                    final_price=row.get('final_price'),
                    recovery_rate=row.get('recovery_rate'),
                    acquirer_symbol=row.get('acquirer_symbol'),
                    exchange_ratio=row.get('exchange_ratio'),
                    data_source="CSV_IMPORT"
                )
                
                if self.survivorship_handler.add_delisting_event(event):
                    events_loaded += 1
                    
            except Exception as e:
                self.logger.warning(f"Error processing row {row.name}: {e}")
                continue
        
        return events_loaded
    
    def _load_excel_delisting_data(self, file_path: str) -> int:
        """Load delisting data from Excel file."""
        df = pd.read_excel(file_path)
        return self._load_csv_delisting_data(file_path)  # Same logic as CSV
    
    def generate_bias_report(self,
                           symbols: List[str],
                           start_date: str,
                           end_date: str) -> Dict:
        """
        Generate comprehensive survivorship bias report.
        
        Args:
            symbols: List of symbols to analyze
            start_date: Analysis start date
            end_date: Analysis end date
            
        Returns:
            Dictionary with bias analysis results
        """
        start_dt = pd.to_datetime(start_date)
        end_dt = pd.to_datetime(end_date)
        
        return self.survivorship_handler.generate_bias_report(
            start_date=start_dt,
            end_date=end_dt,
            base_universe=set(symbols)
        )
    
    def get_survivorship_statistics(self) -> Dict:
        """Get survivorship bias handler statistics."""
        return self.survivorship_handler.get_statistics()
    
    def compare_biased_vs_unbiased_returns(self,
                                         symbols: List[str],
                                         start_date: str,
                                         end_date: str,
                                         strategy_func: callable) -> Dict:
        """
        Compare returns with and without survivorship bias correction.
        
        Args:
            symbols: Universe of symbols
            start_date: Start date for analysis
            end_date: End date for analysis
            strategy_func: Function that calculates strategy returns
            
        Returns:
            Dictionary with comparison results
        """
        # Calculate returns with bias (traditional approach)
        self.enable_bias_correction = False
        biased_data = self.fetch_universe_data(symbols, start_date, end_date)
        biased_returns = strategy_func(biased_data)
        
        # Calculate returns without bias (corrected approach)
        self.enable_bias_correction = True
        unbiased_data = self.fetch_universe_data(symbols, start_date, end_date)
        unbiased_returns = strategy_func(unbiased_data)
        
        # Calculate bias impact
        bias_impact = self.survivorship_handler.calculate_survivorship_bias_impact(
            returns_with_bias=biased_returns,
            returns_without_bias=unbiased_returns
        )
        
        return {
            'biased_returns': biased_returns,
            'unbiased_returns': unbiased_returns,
            'bias_impact': bias_impact,
            'biased_universe_size': len(biased_data),
            'unbiased_universe_size': len(unbiased_data)
        }


# Example usage and testing functions
def create_sample_delisting_database(db_path: str = "data/sample_survivorship.db"):
    """Create a sample database with historical delisting events."""
    from .survivorship_bias_handler import create_sample_delisting_data
    
    handler = SurvivorshipBiasHandler(db_path)
    
    # Add sample delisting events
    sample_events = create_sample_delisting_data()
    for event in sample_events:
        handler.add_delisting_event(event)
    
    # Add some additional events for testing
    additional_events = [
        DelistingEvent(
            symbol="WAMU",  # Washington Mutual
            delist_date=datetime(2008, 9, 25),
            reason_code="100",
            reason_desc="Bank failure",
            final_price=0.0,
            recovery_rate=0.0,
            data_source="HISTORICAL"
        ),
        DelistingEvent(
            symbol="GM",    # General Motors (old)
            delist_date=datetime(2009, 6, 1),
            reason_code="100",
            reason_desc="Bankruptcy reorganization",
            final_price=0.75,
            recovery_rate=0.0,
            data_source="HISTORICAL"
        )
    ]
    
    for event in additional_events:
        handler.add_delisting_event(event)
    
    print(f"Created sample survivorship bias database at {db_path}")
    return handler


if __name__ == "__main__":
    # Example usage
    logging.basicConfig(level=logging.INFO)
    
    # Create sample database
    create_sample_delisting_database()
    
    # Initialize bias-aware data agent
    config = {
        'data_dir_raw': 'data/raw',
        'survivorship_bias_db': 'data/sample_survivorship.db',
        'enable_bias_correction': True,
        'universe_lookback_days': 252
    }
    
    data_agent = BiasAwareDataAgent(config)
    
    # Test universe filtering
    test_symbols = ["AAPL", "GOOGL", "MSFT", "ENRN", "WCOM", "LEH", "BEAR"]
    
    # Generate bias report
    report = data_agent.generate_bias_report(
        symbols=test_symbols,
        start_date="2000-01-01",
        end_date="2010-01-01"
    )
    
    print("\nSurvivorship Bias Report:")
    print(f"Total symbols: {report['universe_stats']['total_symbols']}")
    print(f"Delisted symbols: {report['universe_stats']['delisted_symbols']}")
    print(f"Survival rate: {report['universe_stats']['survivorship_rate']:.1%}")
    print(f"Recommendations: {report['recommendations']}")