# src/data/survivorship_bias_handler.py
"""
Survivorship Bias Handler for IntradayJules Trading System

This module addresses the critical issue of survivorship bias in backtesting by:
1. Tracking delisted securities at the data-join level (not post-hoc filtering)
2. Implementing point-in-time universe construction
3. Integrating CRSP delisting flags and other data sources
4. Providing bias-free performance attribution

Key Insight: Survivorship bias can overstate returns by 1-3% annually because
delisted stocks (bankruptcies, mergers, etc.) are systematically excluded from
historical analysis, creating an unrealistic "winners-only" universe.
"""

import pandas as pd
import numpy as np
import logging
import sqlite3
import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Set, Union
from dataclasses import dataclass, asdict
from enum import Enum


class DelistingReason(Enum):
    """Standard delisting reason codes."""
    BANKRUPTCY = "100"  # Company bankruptcy
    MERGER = "200"      # Merger or acquisition  
    LIQUIDATION = "300" # Voluntary liquidation
    EXCHANGE_MOVE = "400" # Moved to different exchange
    INSUFFICIENT_CAPITAL = "500" # Insufficient capital/assets
    REGULATORY = "600"  # Regulatory issues
    OTHER = "999"       # Other reasons
    UNKNOWN = "000"     # Unknown/missing data


@dataclass
class DelistingEvent:
    """Represents a delisting event for a security."""
    symbol: str
    delist_date: datetime
    reason_code: str
    reason_desc: str
    final_price: Optional[float] = None
    recovery_rate: Optional[float] = None  # For bankruptcies
    acquirer_symbol: Optional[str] = None  # For mergers
    exchange_ratio: Optional[float] = None  # For mergers
    data_source: str = "MANUAL"
    created_at: datetime = None
    
    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.now()


@dataclass
class UniverseSnapshot:
    """Point-in-time universe snapshot."""
    as_of_date: datetime
    active_symbols: Set[str]
    recently_delisted: Set[str]  # Delisted within lookback period
    total_symbols: int
    survivorship_rate: float
    data_source: str
    
    def to_dict(self) -> dict:
        return {
            'as_of_date': self.as_of_date.isoformat(),
            'active_symbols': list(self.active_symbols),
            'recently_delisted': list(self.recently_delisted),
            'total_symbols': self.total_symbols,
            'survivorship_rate': self.survivorship_rate,
            'data_source': self.data_source
        }


class SurvivorshipBiasHandler:
    """
    Handles survivorship bias by maintaining point-in-time universe data
    and integrating delisting information at the data-join level.
    
    Now supports both US equities and FX pairs to eliminate survivorship bias
    across all asset classes.
    """
    
    def __init__(self, 
                 db_path: str = "data/survivorship_bias.db",
                 fx_lifecycle_path: Optional[str] = "data/fx_lifecycle.parquet",
                 logger: Optional[logging.Logger] = None):
        """
        Initialize the survivorship bias handler.
        
        Args:
            db_path: Path to SQLite database for storing delisting data
            fx_lifecycle_path: Path to FX lifecycle parquet file (None to disable FX support)
            logger: Optional logger instance
        """
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        
        self.logger = logger or logging.getLogger(__name__)
        
        # Initialize database for equities
        self._init_database()
        
        # Initialize FX lifecycle guard
        self.fx_lifecycle = None
        if fx_lifecycle_path and Path(fx_lifecycle_path).exists():
            try:
                from .fx_lifecycle import FxLifecycle
                self.fx_lifecycle = FxLifecycle(fx_lifecycle_path)
                self.logger.info(f"FX lifecycle guard initialized: {fx_lifecycle_path}")
            except Exception as e:
                self.logger.warning(f"Failed to initialize FX lifecycle guard: {e}")
        elif fx_lifecycle_path:
            self.logger.warning(f"FX lifecycle file not found: {fx_lifecycle_path}")
        
        # Cache for performance
        self._universe_cache = {}
        self._delisting_cache = {}
        
        self.logger.info(f"SurvivorshipBiasHandler initialized with database: {self.db_path}")
    
    def _init_database(self):
        """Initialize SQLite database with required tables."""
        with sqlite3.connect(self.db_path) as conn:
            # Delisting events table
            conn.execute("""
                CREATE TABLE IF NOT EXISTS delisting_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    symbol TEXT NOT NULL,
                    delist_date DATE NOT NULL,
                    reason_code TEXT NOT NULL,
                    reason_desc TEXT,
                    final_price REAL,
                    recovery_rate REAL,
                    acquirer_symbol TEXT,
                    exchange_ratio REAL,
                    data_source TEXT DEFAULT 'MANUAL',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(symbol, delist_date)
                )
            """)
            
            # Universe snapshots table
            conn.execute("""
                CREATE TABLE IF NOT EXISTS universe_snapshots (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    as_of_date DATE NOT NULL,
                    snapshot_data TEXT NOT NULL,  -- JSON
                    data_source TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(as_of_date, data_source)
                )
            """)
            
            # Symbol metadata table
            conn.execute("""
                CREATE TABLE IF NOT EXISTS symbol_metadata (
                    symbol TEXT PRIMARY KEY,
                    company_name TEXT,
                    sector TEXT,
                    industry TEXT,
                    market_cap_category TEXT,
                    first_trade_date DATE,
                    last_trade_date DATE,
                    is_active BOOLEAN DEFAULT 1,
                    data_source TEXT DEFAULT 'MANUAL',
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Create indexes for performance
            conn.execute("CREATE INDEX IF NOT EXISTS idx_delist_symbol ON delisting_events(symbol)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_delist_date ON delisting_events(delist_date)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_universe_date ON universe_snapshots(as_of_date)")
            
            conn.commit()
            
        self.logger.info("Database initialized successfully")
    
    def add_delisting_event(self, event: DelistingEvent) -> bool:
        """
        Add a delisting event to the database.
        
        Args:
            event: DelistingEvent instance
            
        Returns:
            True if added successfully, False if already exists
        """
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute("""
                    INSERT OR REPLACE INTO delisting_events 
                    (symbol, delist_date, reason_code, reason_desc, final_price, 
                     recovery_rate, acquirer_symbol, exchange_ratio, data_source)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    event.symbol,
                    event.delist_date.date(),
                    event.reason_code,
                    event.reason_desc,
                    event.final_price,
                    event.recovery_rate,
                    event.acquirer_symbol,
                    event.exchange_ratio,
                    event.data_source
                ))
                conn.commit()
                
            # Clear cache for this symbol
            if event.symbol in self._delisting_cache:
                del self._delisting_cache[event.symbol]
                
            self.logger.info(f"Added delisting event: {event.symbol} on {event.delist_date.date()}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error adding delisting event: {e}")
            return False
    
    def get_delisting_events(self, 
                           symbol: Optional[str] = None,
                           start_date: Optional[datetime] = None,
                           end_date: Optional[datetime] = None) -> List[DelistingEvent]:
        """
        Retrieve delisting events from database.
        
        Args:
            symbol: Optional symbol filter
            start_date: Optional start date filter
            end_date: Optional end date filter
            
        Returns:
            List of DelistingEvent objects
        """
        query = "SELECT * FROM delisting_events WHERE 1=1"
        params = []
        
        if symbol:
            query += " AND symbol = ?"
            params.append(symbol)
            
        if start_date:
            query += " AND delist_date >= ?"
            params.append(start_date.date())
            
        if end_date:
            query += " AND delist_date <= ?"
            params.append(end_date.date())
            
        query += " ORDER BY delist_date DESC"
        
        events = []
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                cursor = conn.execute(query, params)
                
                for row in cursor.fetchall():
                    event = DelistingEvent(
                        symbol=row['symbol'],
                        delist_date=datetime.strptime(row['delist_date'], '%Y-%m-%d'),
                        reason_code=row['reason_code'],
                        reason_desc=row['reason_desc'],
                        final_price=row['final_price'],
                        recovery_rate=row['recovery_rate'],
                        acquirer_symbol=row['acquirer_symbol'],
                        exchange_ratio=row['exchange_ratio'],
                        data_source=row['data_source'],
                        created_at=datetime.strptime(row['created_at'], '%Y-%m-%d %H:%M:%S')
                    )
                    events.append(event)
                    
        except Exception as e:
            self.logger.error(f"Error retrieving delisting events: {e}")
            
        return events
    
    def is_symbol_active(self, symbol: str, as_of_date: datetime, asset_class: str = "equity") -> bool:
        """
        Check if a symbol was active (not delisted) as of a specific date.
        
        Args:
            symbol: Symbol (stock symbol or FX pair)
            as_of_date: Date to check
            asset_class: "equity" for stocks, "fx" for FX pairs
            
        Returns:
            True if symbol was active, False if delisted
        """
        # Handle FX pairs
        if asset_class.lower() == "fx" and self.fx_lifecycle:
            return self.fx_lifecycle.is_active(symbol, pd.to_datetime(as_of_date))
        
        # Handle equities (original logic)
        cache_key = f"{symbol}_{as_of_date.date()}_{asset_class}"
        if cache_key in self._delisting_cache:
            return self._delisting_cache[cache_key]
        
        # Query database
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.execute("""
                    SELECT COUNT(*) FROM delisting_events 
                    WHERE symbol = ? AND delist_date <= ?
                """, (symbol, as_of_date.date()))
                
                count = cursor.fetchone()[0]
                is_active = count == 0
                
                # Cache result
                self._delisting_cache[cache_key] = is_active
                
                return is_active
                
        except Exception as e:
            self.logger.error(f"Error checking symbol activity: {e}")
            return True  # Default to active if error
    
    def get_point_in_time_universe(self, 
                                 as_of_date: datetime,
                                 base_universe: Set[str],
                                 lookback_days: int = 252) -> UniverseSnapshot:
        """
        Construct point-in-time universe excluding delisted securities.
        
        Args:
            as_of_date: Date for universe construction
            base_universe: Base set of symbols to filter
            lookback_days: Days to look back for recently delisted symbols
            
        Returns:
            UniverseSnapshot with bias-free universe
        """
        cache_key = f"{as_of_date.date()}_{len(base_universe)}_{lookback_days}"
        if cache_key in self._universe_cache:
            return self._universe_cache[cache_key]
        
        active_symbols = set()
        recently_delisted = set()
        
        lookback_date = as_of_date - timedelta(days=lookback_days)
        
        for symbol in base_universe:
            if self.is_symbol_active(symbol, as_of_date):
                active_symbols.add(symbol)
            else:
                # Check if delisted within lookback period
                delisting_events = self.get_delisting_events(
                    symbol=symbol,
                    start_date=lookback_date,
                    end_date=as_of_date
                )
                if delisting_events:
                    recently_delisted.add(symbol)
        
        survivorship_rate = len(active_symbols) / len(base_universe) if base_universe else 1.0
        
        snapshot = UniverseSnapshot(
            as_of_date=as_of_date,
            active_symbols=active_symbols,
            recently_delisted=recently_delisted,
            total_symbols=len(base_universe),
            survivorship_rate=survivorship_rate,
            data_source="BIAS_HANDLER"
        )
        
        # Cache result
        self._universe_cache[cache_key] = snapshot
        
        self.logger.info(f"Point-in-time universe for {as_of_date.date()}: "
                        f"{len(active_symbols)}/{len(base_universe)} active "
                        f"({survivorship_rate:.1%} survival rate)")
        
        return snapshot
    
    def apply_survivorship_filter(self, 
                                 df: pd.DataFrame, 
                                 symbol: str, 
                                 asset_class: str = "equity",
                                 mode: str = "drop") -> pd.DataFrame:
        """
        Apply survivorship bias filtering to a DataFrame.
        
        This is the main method that integrates both equity and FX survivorship bias handling.
        
        Args:
            df: DataFrame with datetime index or datetime column
            symbol: Symbol to filter (stock symbol or FX pair)
            asset_class: "equity" for stocks, "fx" for FX pairs
            mode: "drop" to remove rows outside active period,
                  "mask" to keep rows but NaN price columns
                  
        Returns:
            Filtered DataFrame
        """
        if asset_class.lower() == "fx" and self.fx_lifecycle:
            # Use FX lifecycle guard
            return self.fx_lifecycle.apply(df, symbol, mode)
        
        elif asset_class.lower() == "equity":
            # Use equity delisting logic
            if not hasattr(df.index, 'to_series') and 'datetime' not in df.columns:
                self.logger.warning(f"Cannot apply survivorship filter - no datetime index or column")
                return df
            
            # Get delisting events for this symbol
            delisting_events = self.get_delisting_events(symbol=symbol)
            
            if not delisting_events:
                # No delisting events - return original DataFrame
                return df
            
            # Find the earliest delisting date
            earliest_delist = min(event.delist_date for event in delisting_events)
            
            # Create filter mask
            if hasattr(df.index, 'to_series'):
                # DatetimeIndex
                active_mask = df.index < earliest_delist
            else:
                # Datetime column
                datetime_col = 'datetime' if 'datetime' in df.columns else 'timestamp'
                active_mask = df[datetime_col] < earliest_delist
            
            if mode == "drop":
                filtered_df = df.loc[active_mask].copy()
                dropped_rows = len(df) - len(filtered_df)
                if dropped_rows > 0:
                    self.logger.info(f"Dropped {dropped_rows} rows after delisting for {symbol}")
                return filtered_df
                
            elif mode == "mask":
                price_cols = ["open", "high", "low", "close", "bid", "ask", "mid", "price"]
                common_price_cols = [col for col in price_cols if col in df.columns]
                
                df_masked = df.copy()
                df_masked.loc[~active_mask, common_price_cols] = pd.NA
                
                masked_rows = (~active_mask).sum()
                if masked_rows > 0:
                    self.logger.info(f"Masked {masked_rows} rows after delisting for {symbol}")
                return df_masked
            
            else:
                raise ValueError("mode must be 'drop' or 'mask'")
        
        else:
            raise ValueError(f"Unsupported asset class: {asset_class}")
    
    def get_active_symbols(self, 
                          symbols: List[str], 
                          as_of_date: datetime,
                          asset_class: str = "equity") -> List[str]:
        """
        Filter a list of symbols to only include those active on a specific date.
        
        Args:
            symbols: List of symbols to check
            as_of_date: Date to check activity
            asset_class: "equity" for stocks, "fx" for FX pairs
            
        Returns:
            List of active symbols
        """
        active_symbols = []
        
        for symbol in symbols:
            if self.is_symbol_active(symbol, as_of_date, asset_class):
                active_symbols.append(symbol)
        
        self.logger.info(f"Filtered {len(symbols)} {asset_class} symbols to {len(active_symbols)} active on {as_of_date.date()}")
        return active_symbols
    
    def save_universe_snapshot(self, snapshot: UniverseSnapshot) -> bool:
        """Save universe snapshot to database."""
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute("""
                    INSERT OR REPLACE INTO universe_snapshots 
                    (as_of_date, snapshot_data, data_source)
                    VALUES (?, ?, ?)
                """, (
                    snapshot.as_of_date.date(),
                    json.dumps(snapshot.to_dict()),
                    snapshot.data_source
                ))
                conn.commit()
                
            self.logger.info(f"Saved universe snapshot for {snapshot.as_of_date.date()}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error saving universe snapshot: {e}")
            return False
    
    def calculate_survivorship_bias_impact(self, 
                                         returns_with_bias: pd.Series,
                                         returns_without_bias: pd.Series) -> Dict[str, float]:
        """
        Calculate the impact of survivorship bias on performance metrics.
        
        Args:
            returns_with_bias: Returns calculated with survivorship bias
            returns_without_bias: Returns calculated without survivorship bias
            
        Returns:
            Dictionary with bias impact metrics
        """
        def calculate_metrics(returns):
            return {
                'total_return': (1 + returns).prod() - 1,
                'annualized_return': (1 + returns).prod() ** (252 / len(returns)) - 1,
                'volatility': returns.std() * np.sqrt(252),
                'sharpe_ratio': returns.mean() / returns.std() * np.sqrt(252) if returns.std() > 0 else 0,
                'max_drawdown': (returns.cumsum() - returns.cumsum().cummax()).min()
            }
        
        biased_metrics = calculate_metrics(returns_with_bias)
        unbiased_metrics = calculate_metrics(returns_without_bias)
        
        impact = {}
        for metric in biased_metrics:
            biased_val = biased_metrics[metric]
            unbiased_val = unbiased_metrics[metric]
            
            if metric in ['total_return', 'annualized_return']:
                # Difference in percentage points
                impact[f'{metric}_bias_pp'] = (biased_val - unbiased_val) * 100
            else:
                # Relative difference
                if unbiased_val != 0:
                    impact[f'{metric}_bias_pct'] = ((biased_val - unbiased_val) / abs(unbiased_val)) * 100
                else:
                    impact[f'{metric}_bias_pct'] = 0
        
        return impact
    
    def load_crsp_delisting_data(self, crsp_file_path: str) -> int:
        """
        Load CRSP delisting data from file.
        
        Args:
            crsp_file_path: Path to CRSP delisting data file
            
        Returns:
            Number of delisting events loaded
        """
        try:
            # CRSP data typically has columns: PERMNO, TICKER, DLSTDT, DLSTCD, etc.
            df = pd.read_csv(crsp_file_path)
            
            # Map CRSP delisting codes to our standard codes
            crsp_code_mapping = {
                100: DelistingReason.BANKRUPTCY.value,
                200: DelistingReason.MERGER.value,
                300: DelistingReason.LIQUIDATION.value,
                400: DelistingReason.EXCHANGE_MOVE.value,
                500: DelistingReason.INSUFFICIENT_CAPITAL.value,
                600: DelistingReason.REGULATORY.value
            }
            
            events_loaded = 0
            
            for _, row in df.iterrows():
                if pd.isna(row.get('TICKER')) or pd.isna(row.get('DLSTDT')):
                    continue
                
                delist_date = pd.to_datetime(row['DLSTDT'])
                dlst_code = row.get('DLSTCD', 999)
                
                reason_code = crsp_code_mapping.get(dlst_code, DelistingReason.OTHER.value)
                
                event = DelistingEvent(
                    symbol=row['TICKER'],
                    delist_date=delist_date,
                    reason_code=reason_code,
                    reason_desc=f"CRSP Code: {dlst_code}",
                    final_price=row.get('DLPRC'),
                    data_source="CRSP"
                )
                
                if self.add_delisting_event(event):
                    events_loaded += 1
            
            self.logger.info(f"Loaded {events_loaded} delisting events from CRSP data")
            return events_loaded
            
        except Exception as e:
            self.logger.error(f"Error loading CRSP data: {e}")
            return 0
    
    def generate_bias_report(self, 
                           start_date: datetime,
                           end_date: datetime,
                           base_universe: Set[str]) -> Dict:
        """
        Generate comprehensive survivorship bias report.
        
        Args:
            start_date: Analysis start date
            end_date: Analysis end date  
            base_universe: Base universe of symbols
            
        Returns:
            Dictionary with bias analysis results
        """
        report = {
            'analysis_period': {
                'start_date': start_date.isoformat(),
                'end_date': end_date.isoformat(),
                'days': (end_date - start_date).days
            },
            'universe_stats': {
                'total_symbols': len(base_universe),
                'active_symbols': 0,
                'delisted_symbols': 0,
                'survivorship_rate': 0.0
            },
            'delisting_breakdown': {},
            'temporal_analysis': [],
            'recommendations': []
        }
        
        # Get delisting events in period
        delisting_events = self.get_delisting_events(
            start_date=start_date,
            end_date=end_date
        )
        
        # Filter to base universe
        relevant_events = [e for e in delisting_events if e.symbol in base_universe]
        
        # Calculate universe stats
        delisted_symbols = {e.symbol for e in relevant_events}
        active_symbols = base_universe - delisted_symbols
        
        report['universe_stats'].update({
            'active_symbols': len(active_symbols),
            'delisted_symbols': len(delisted_symbols),
            'survivorship_rate': len(active_symbols) / len(base_universe) if base_universe else 1.0
        })
        
        # Delisting reason breakdown
        reason_counts = {}
        for event in relevant_events:
            reason = event.reason_code
            reason_counts[reason] = reason_counts.get(reason, 0) + 1
        
        report['delisting_breakdown'] = reason_counts
        
        # Temporal analysis (quarterly snapshots)
        current_date = start_date
        while current_date <= end_date:
            snapshot = self.get_point_in_time_universe(current_date, base_universe)
            report['temporal_analysis'].append({
                'date': current_date.isoformat(),
                'active_count': len(snapshot.active_symbols),
                'survivorship_rate': snapshot.survivorship_rate
            })
            current_date += timedelta(days=90)  # Quarterly
        
        # Generate recommendations
        survivorship_rate = report['universe_stats']['survivorship_rate']
        
        if survivorship_rate < 0.85:
            report['recommendations'].append(
                "HIGH RISK: Survivorship rate below 85%. Bias correction is critical."
            )
        elif survivorship_rate < 0.95:
            report['recommendations'].append(
                "MEDIUM RISK: Survivorship rate below 95%. Consider bias correction."
            )
        else:
            report['recommendations'].append(
                "LOW RISK: High survivorship rate, but still monitor for bias."
            )
        
        if len(delisted_symbols) > 0:
            report['recommendations'].append(
                f"Include {len(delisted_symbols)} delisted symbols in backtests for accurate results."
            )
        
        return report
    
    def get_statistics(self) -> Dict:
        """Get handler statistics."""
        try:
            with sqlite3.connect(self.db_path) as conn:
                # Count delisting events
                cursor = conn.execute("SELECT COUNT(*) FROM delisting_events")
                total_events = cursor.fetchone()[0]
                
                # Count by reason
                cursor = conn.execute("""
                    SELECT reason_code, COUNT(*) 
                    FROM delisting_events 
                    GROUP BY reason_code
                """)
                reason_breakdown = dict(cursor.fetchall())
                
                # Count universe snapshots
                cursor = conn.execute("SELECT COUNT(*) FROM universe_snapshots")
                total_snapshots = cursor.fetchone()[0]
                
                return {
                    'total_delisting_events': total_events,
                    'reason_breakdown': reason_breakdown,
                    'universe_snapshots': total_snapshots,
                    'cache_size': len(self._universe_cache) + len(self._delisting_cache)
                }
                
        except Exception as e:
            self.logger.error(f"Error getting statistics: {e}")
            return {}
    
    def close(self):
        """Close any open resources (placeholder for future use)."""
        # Clear caches
        self._universe_cache.clear()
        self._delisting_cache.clear()
        self.logger.info("SurvivorshipBiasHandler closed")


def create_sample_delisting_data() -> List[DelistingEvent]:
    """Create sample delisting events for testing."""
    events = [
        DelistingEvent(
            symbol="ENRN",  # Enron
            delist_date=datetime(2001, 11, 28),
            reason_code=DelistingReason.BANKRUPTCY.value,
            reason_desc="Corporate bankruptcy",
            final_price=0.26,
            recovery_rate=0.0,
            data_source="HISTORICAL"
        ),
        DelistingEvent(
            symbol="WCOM",  # WorldCom
            delist_date=datetime(2002, 7, 1),
            reason_code=DelistingReason.BANKRUPTCY.value,
            reason_desc="Accounting fraud bankruptcy",
            final_price=0.83,
            recovery_rate=0.0,
            data_source="HISTORICAL"
        ),
        DelistingEvent(
            symbol="BEAR",  # Bear Stearns
            delist_date=datetime(2008, 5, 30),
            reason_code=DelistingReason.MERGER.value,
            reason_desc="Acquired by JPMorgan Chase",
            final_price=10.00,
            acquirer_symbol="JPM",
            exchange_ratio=0.21753,
            data_source="HISTORICAL"
        ),
        DelistingEvent(
            symbol="LEH",   # Lehman Brothers
            delist_date=datetime(2008, 9, 15),
            reason_code=DelistingReason.BANKRUPTCY.value,
            reason_desc="Investment bank bankruptcy",
            final_price=0.21,
            recovery_rate=0.08,
            data_source="HISTORICAL"
        )
    ]
    return events


if __name__ == "__main__":
    # Example usage
    logging.basicConfig(level=logging.INFO)
    
    handler = SurvivorshipBiasHandler("data/test_survivorship.db")
    
    # Add sample data
    sample_events = create_sample_delisting_data()
    for event in sample_events:
        handler.add_delisting_event(event)
    
    # Test point-in-time universe
    test_universe = {"AAPL", "GOOGL", "MSFT", "ENRN", "WCOM", "BEAR", "LEH"}
    snapshot = handler.get_point_in_time_universe(
        as_of_date=datetime(2008, 1, 1),
        base_universe=test_universe
    )
    
    print(f"Universe snapshot for 2008-01-01:")
    print(f"Active symbols: {snapshot.active_symbols}")
    print(f"Survivorship rate: {snapshot.survivorship_rate:.1%}")
    
    # Generate bias report
    report = handler.generate_bias_report(
        start_date=datetime(2000, 1, 1),
        end_date=datetime(2010, 1, 1),
        base_universe=test_universe
    )
    
    print(f"\nSurvivorship Bias Report:")
    print(f"Total symbols: {report['universe_stats']['total_symbols']}")
    print(f"Delisted symbols: {report['universe_stats']['delisted_symbols']}")
    print(f"Survivorship rate: {report['universe_stats']['survivorship_rate']:.1%}")