# src/column_names.py

COL_OPEN = 'Open'
COL_HIGH = 'High'
COL_LOW = 'Low'
COL_CLOSE = 'Close'
COL_VOLUME = 'Volume'
COL_DATETIME = 'datetime'
# Add more as needed
