# --- Test Suite ---
import pytest
from unittest.mock import MagicMock, patch
from src.api.orchestrator_agent import OrchestratorAgent

@pytest.fixture
def orchestrator(tmp_path):
    # Create dummy config files in tmp_path
    main_cfg_path = tmp_path / "main.yaml"
    model_params_cfg_path = tmp_path / "model.yaml"
    risk_limits_cfg_path = tmp_path / "risk.yaml"

    dummy_main_config = {
        'paths': {
            'data_dir_raw': 'data/raw_orch_test/',
            'data_dir_processed': 'data/processed_orch_test/',
            'scalers_dir': 'data/scalers_orch_test/',
            'model_save_dir': 'models/orch_test/',
            'tensorboard_log_dir': 'logs/tensorboard_orch_test/',
            'reports_dir': 'reports/orch_test/'
        },
        'ibkr_connection': None,
        'feature_engineering': {
            'features': ['RSI', 'EMA'], 'rsi': {'window': 14}, 'ema': {'windows': [10, 20]},
            'time_features': ['hour'], 'lookback_window': 3,
            'feature_cols_to_scale': ['rsi_14', 'ema_10', 'ema_20', 'hour_of_day'],
            'observation_feature_cols': ['rsi_14', 'ema_10', 'ema_20', 'hour_of_day', CLOSE]
        },
        'environment': {
            'initial_capital': 50000.0, 'transaction_cost_pct': 0.001, 'reward_scaling': 1.0,
            'log_trades_in_env': True
        },
        'training': {
            'total_timesteps': 2000, 'checkpoint_freq': 500, 'log_interval': 50,
            'data_duration_for_fetch': "10 D"
        },
        'evaluation': {
            'metrics': ['total_return', 'num_trades'],
            'data_duration_for_fetch': "5 D"
        }
    }
    with open(main_cfg_path, 'w') as f: yaml.dump(dummy_main_config, f)

    dummy_model_params = {
        'algorithm_name': 'DQN',
        'algorithm_params': {'policy': 'MlpPolicy', 'learning_rate': 1e-3, 'buffer_size': 5000, 'verbose': 0},
        'c51_features': {'dueling_nets': False, 'use_per': False, 'n_step_returns': 1, 'use_noisy_nets': False}
    }
    with open(model_params_cfg_path, 'w') as f: yaml.dump(dummy_model_params, f)

    dummy_risk_limits = {
        'max_daily_drawdown_pct': 0.025, 'max_hourly_turnover_ratio': 1.5, 'max_daily_turnover_ratio': 4.0,
        'halt_on_breach': True
    }
    with open(risk_limits_cfg_path, 'w') as f: yaml.dump(dummy_risk_limits, f)

    return OrchestratorAgent(
        main_config_path=str(main_cfg_path),
        model_params_path=str(model_params_cfg_path),
        risk_limits_path=str(risk_limits_cfg_path)
    )

def test_training_pipeline_success(orchestrator):
    # Mock all agent methods to return dummy data
    orchestrator.data_agent.run = MagicMock(return_value="dummy_data")
    orchestrator.feature_agent.run = MagicMock(return_value=("df", "features", "prices"))
    orchestrator.env_agent.run = MagicMock(return_value="env")
    orchestrator.trainer_agent.run = MagicMock(return_value="model_path")
    orchestrator.evaluator_agent.run = MagicMock(return_value={"metric": 1.0})

    result = orchestrator.run_training_pipeline(
        symbol="AAPL", start_date="2023-01-01", end_date="2023-01-10", interval="1min"
    )
    assert result == "model_path"

def test_training_pipeline_data_failure(orchestrator):
    orchestrator.data_agent.run = MagicMock(return_value=None)
    result = orchestrator.run_training_pipeline(
        symbol="AAPL", start_date="2023-01-01", end_date="2023-01-10", interval="1min"
    )
    assert result is None

