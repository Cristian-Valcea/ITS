#!/usr/bin/env python3
"""
Test to verify that all sensor calculators are properly instantiated
and that the RulesEngine won't immediately breach due to missing metrics.

This test ensures that:
1. All new sensor calculators are instantiated in both RiskAgentV2 and RiskAgentAdapter
2. Calculators produce valid results with test data
3. RulesEngine can evaluate policies without "metric not found" errors
4. No immediate rule breaches due to missing calculator outputs
"""

import sys
import os
import time
import numpy as np
from datetime import datetime
from typing import Dict, Any

# Add project root to path
sys.path.insert(0, os.path.dirname(__file__))

def test_risk_agent_v2_calculators():
    """Test that RiskAgentV2 instantiates all sensor calculators."""
    print("🧪 Testing RiskAgentV2 Calculator Instantiation")
    print("-" * 50)
    
    from src.risk.risk_agent_v2 import create_risk_agent_v2
    
    # Create minimal config
    config = {
        'calculators': {
            'drawdown': {'enabled': True, 'config': {}},
            'turnover': {'enabled': True, 'config': {}},
            'ulcer_index': {'enabled': True, 'config': {}},
            'drawdown_velocity': {'enabled': True, 'config': {}},
            'expected_shortfall': {'enabled': True, 'config': {}},
            'kyle_lambda': {'enabled': True, 'config': {}},
            'depth_shock': {'enabled': True, 'config': {}},
            'feed_staleness': {'enabled': True, 'config': {}},
            'latency_drift': {'enabled': True, 'config': {}},
            'adv_participation': {'enabled': True, 'config': {}}
        },
        'policies': []
    }
    
    # Create RiskAgentV2
    risk_agent = create_risk_agent_v2(config)
    
    # Check calculator count
    calculator_count = len(risk_agent.calculators)
    expected_count = 10  # 2 original + 8 new sensors
    
    print(f"Calculator count: {calculator_count} (expected: {expected_count})")
    
    # Check calculator types
    calculator_types = [calc.__class__.__name__ for calc in risk_agent.calculators]
    print(f"Calculator types: {calculator_types}")
    
    expected_types = [
        'DrawdownCalculator', 'TurnoverCalculator',
        'UlcerIndexCalculator', 'DrawdownVelocityCalculator',
        'ExpectedShortfallCalculator', 'KyleLambdaCalculator',
        'DepthShockCalculator', 'FeedStalenessCalculator',
        'LatencyDriftCalculator', 'ADVParticipationCalculator'
    ]
    
    missing_types = set(expected_types) - set(calculator_types)
    extra_types = set(calculator_types) - set(expected_types)
    
    print(f"Missing calculator types: {missing_types if missing_types else 'None'}")
    print(f"Extra calculator types: {extra_types if extra_types else 'None'}")
    
    success = (calculator_count == expected_count and 
               len(missing_types) == 0 and 
               len(extra_types) == 0)
    
    print(f"✅ RiskAgentV2 calculator instantiation: {'PASSED' if success else 'FAILED'}")
    return success


def test_risk_agent_adapter_calculators():
    """Test that RiskAgentAdapter instantiates all sensor calculators."""
    print("\n🧪 Testing RiskAgentAdapter Calculator Instantiation")
    print("-" * 50)
    
    from src.risk.risk_agent_adapter import RiskAgentAdapter
    
    # Create minimal config
    config = {
        'max_daily_drawdown_pct': 0.02,
        'max_hourly_turnover_ratio': 5.0,
        'max_daily_turnover_ratio': 20.0,
        'halt_on_breach': True,
        'liquidate_on_halt': False
    }
    
    # Create RiskAgentAdapter
    adapter = RiskAgentAdapter(config)
    
    # Check calculator count
    calculator_count = len(adapter.risk_agent_v2.calculators)
    expected_count = 10  # 2 original + 8 new sensors
    
    print(f"Calculator count: {calculator_count} (expected: {expected_count})")
    
    # Check calculator types
    calculator_types = [calc.__class__.__name__ for calc in adapter.risk_agent_v2.calculators]
    print(f"Calculator types: {calculator_types}")
    
    expected_types = [
        'DrawdownCalculator', 'TurnoverCalculator',
        'UlcerIndexCalculator', 'DrawdownVelocityCalculator',
        'ExpectedShortfallCalculator', 'KyleLambdaCalculator',
        'DepthShockCalculator', 'FeedStalenessCalculator',
        'LatencyDriftCalculator', 'ADVParticipationCalculator'
    ]
    
    missing_types = set(expected_types) - set(calculator_types)
    extra_types = set(calculator_types) - set(expected_types)
    
    print(f"Missing calculator types: {missing_types if missing_types else 'None'}")
    print(f"Extra calculator types: {extra_types if extra_types else 'None'}")
    
    success = (calculator_count == expected_count and 
               len(missing_types) == 0 and 
               len(extra_types) == 0)
    
    print(f"✅ RiskAgentAdapter calculator instantiation: {'PASSED' if success else 'FAILED'}")
    return success


def test_calculator_execution():
    """Test that all calculators can execute without errors."""
    print("\n🧪 Testing Calculator Execution")
    print("-" * 50)
    
    from src.risk.risk_agent_adapter import RiskAgentAdapter
    from src.risk.event_types import RiskEvent, EventType, EventPriority
    
    # Create adapter
    config = {
        'max_daily_drawdown_pct': 0.02,
        'max_hourly_turnover_ratio': 5.0,
        'max_daily_turnover_ratio': 20.0,
        'halt_on_breach': True,
        'liquidate_on_halt': False
    }
    adapter = RiskAgentAdapter(config)
    
    # Generate test data
    test_data = generate_comprehensive_test_data()
    
    # Test each calculator
    successful_calcs = 0
    failed_calcs = 0
    
    for calculator in adapter.risk_agent_v2.calculators:
        calc_name = calculator.__class__.__name__
        try:
            result = calculator.calculate_safe(test_data)
            if result.is_valid and len(result.values) > 0:
                print(f"  ✅ {calc_name}: {len(result.values)} metrics")
                successful_calcs += 1
            else:
                print(f"  ⚠️ {calc_name}: Invalid result or no metrics")
                failed_calcs += 1
        except Exception as e:
            print(f"  ❌ {calc_name}: Failed with {e}")
            failed_calcs += 1
    
    print(f"\nCalculator execution summary:")
    print(f"  Successful: {successful_calcs}")
    print(f"  Failed: {failed_calcs}")
    print(f"  Total: {successful_calcs + failed_calcs}")
    
    # Success if most calculators work (allow 1-2 failures for missing data)
    success = failed_calcs <= 1
    print(f"✅ Calculator execution: {'PASSED' if success else 'FAILED'}")
    return success


def test_rules_engine_integration():
    """Test that RulesEngine can evaluate policies without missing metric errors."""
    print("\n🧪 Testing RulesEngine Integration")
    print("-" * 50)
    
    from src.risk.risk_agent_adapter import RiskAgentAdapter
    from src.risk.event_types import RiskEvent, EventType, EventPriority
    
    # Create adapter
    config = {
        'max_daily_drawdown_pct': 0.02,
        'max_hourly_turnover_ratio': 5.0,
        'max_daily_turnover_ratio': 20.0,
        'halt_on_breach': True,
        'liquidate_on_halt': False
    }
    adapter = RiskAgentAdapter(config)
    
    # Generate test data
    test_data = generate_comprehensive_test_data()
    
    # Run all calculators to populate metrics
    all_metrics = {}
    calculator_errors = []
    
    for calculator in adapter.risk_agent_v2.calculators:
        try:
            result = calculator.calculate_safe(test_data)
            if result.is_valid:
                all_metrics.update(result.values)
            else:
                calculator_errors.append(f"{calculator.__class__.__name__}: Invalid result")
        except Exception as e:
            calculator_errors.append(f"{calculator.__class__.__name__}: {e}")
    
    print(f"Total metrics available: {len(all_metrics)}")
    print(f"Calculator errors: {len(calculator_errors)}")
    
    if calculator_errors:
        print("Calculator errors:")
        for error in calculator_errors[:5]:  # Show first 5 errors
            print(f"  - {error}")
    
    # Test basic policy evaluation
    try:
        policy_result = adapter.risk_agent_v2.rules_engine.evaluate_policy('basic_risk_limits', all_metrics)
        
        if policy_result is not None:
            print(f"Policy evaluation successful:")
            print(f"  Overall action: {policy_result.overall_action}")
            print(f"  Rules evaluated: {len(policy_result.rule_results)}")
            print(f"  Rules triggered: {sum(1 for r in policy_result.rule_results if r.triggered)}")
            
            # Check for "metric not found" errors
            metric_not_found_errors = [
                r for r in policy_result.rule_results 
                if hasattr(r, 'error_message') and r.error_message and "not found" in r.error_message.lower()
            ]
            
            print(f"  'Metric not found' errors: {len(metric_not_found_errors)}")
            
            if metric_not_found_errors:
                print("  Missing metric errors:")
                for error in metric_not_found_errors[:3]:
                    print(f"    - {error.rule_name}: {error.error_message}")
            
            # Success if no metric not found errors (some rules may trigger, that's OK)
            success = len(metric_not_found_errors) == 0
        else:
            print("Policy evaluation returned None")
            success = False
            
    except Exception as e:
        print(f"Policy evaluation failed: {e}")
        success = False
    
    print(f"✅ RulesEngine integration: {'PASSED' if success else 'FAILED'}")
    return success


def generate_comprehensive_test_data() -> Dict[str, Any]:
    """Generate comprehensive test data for all calculators."""
    np.random.seed(42)
    current_time = time.time()
    
    # Portfolio data
    n_points = 100
    initial_value = 1_000_000
    returns = np.random.normal(0.0001, 0.02, n_points)
    portfolio_values = [initial_value]
    
    for ret in returns:
        portfolio_values.append(portfolio_values[-1] * (1 + ret))
    
    portfolio_values = np.array(portfolio_values[1:])
    timestamps = np.array([current_time - (n_points - i) * 3600 for i in range(n_points)])
    
    # Market data
    feed_timestamps = {
        'market_data': current_time - 0.1,  # 100ms old
        'order_book': current_time - 0.05,  # 50ms old
        'trades': current_time - 0.2,       # 200ms old
        'news': current_time - 1.0          # 1s old
    }
    
    # Position data
    positions = {
        'AAPL': 1000,
        'MSFT': 500,
        'TSLA': -200,
        'GOOGL': 300
    }
    
    current_prices = {
        'AAPL': 150.0,
        'MSFT': 300.0,
        'TSLA': 200.0,
        'GOOGL': 2500.0
    }
    
    # Order flow data
    price_changes = np.random.normal(0, 0.001, 50)
    order_flows = np.random.normal(0, 100000, 50)
    
    # Volume data
    daily_volumes = {
        'AAPL': [50000000] * 20,
        'MSFT': [30000000] * 20,
        'TSLA': [80000000] * 20,
        'GOOGL': [25000000] * 20
    }
    
    # Order book depth
    order_book_depth = {
        'AAPL': {
            'bids': [(149.95, 1000), (149.90, 2000), (149.85, 1500)],
            'asks': [(150.05, 1200), (150.10, 1800), (150.15, 2200)]
        }
    }
    
    # Latency data
    order_latencies = np.random.normal(50, 10, 1000)
    
    # Trade values for TurnoverCalculator
    trade_values = np.random.uniform(1000, 50000, 50)
    trade_timestamps = np.array([current_time - (50 - i) * 60 for i in range(50)])
    
    return {
        'portfolio_values': portfolio_values,
        'returns': returns,
        'timestamps': timestamps,
        'current_time': current_time,
        'feed_timestamps': feed_timestamps,
        'positions': positions,
        'current_prices': current_prices,
        'price_changes': price_changes,
        'order_flows': order_flows,
        'daily_volumes': daily_volumes,
        'order_book_depth': order_book_depth,
        'order_latencies': order_latencies,
        
        # Trade data for TurnoverCalculator
        'trade_values': trade_values,
        'trade_timestamps': trade_timestamps,
        
        # Additional data for compatibility
        'start_of_day_value': initial_value,
        'current_portfolio_value': portfolio_values[-1],
        'daily_traded_value': 50000,
        'hourly_traded_value': 10000,
        'daily_drawdown': (portfolio_values[-1] - initial_value) / initial_value,
        'daily_turnover_ratio': 0.05,
        'hourly_turnover_ratio': 0.01
    }


def main():
    """Run all tests to verify calculator instantiation fix."""
    print("🚀 CALCULATOR INSTANTIATION FIX VALIDATION")
    print("=" * 70)
    
    tests = [
        ("RiskAgentV2 Calculator Instantiation", test_risk_agent_v2_calculators),
        ("RiskAgentAdapter Calculator Instantiation", test_risk_agent_adapter_calculators),
        ("Calculator Execution", test_calculator_execution),
        ("RulesEngine Integration", test_rules_engine_integration)
    ]
    
    passed = 0
    failed = 0
    
    for test_name, test_func in tests:
        try:
            result = test_func()
            if result:
                print(f"✅ {test_name}: PASSED")
                passed += 1
            else:
                print(f"❌ {test_name}: FAILED")
                failed += 1
        except Exception as e:
            print(f"❌ {test_name}: FAILED with exception: {e}")
            import traceback
            traceback.print_exc()
            failed += 1
    
    print(f"\n{'='*70}")
    print(f"📊 TEST SUMMARY")
    print(f"{'='*70}")
    print(f"✅ Passed: {passed}")
    print(f"❌ Failed: {failed}")
    print(f"📈 Total:  {passed + failed}")
    
    if failed == 0:
        print(f"\n🎉 ALL TESTS PASSED!")
        print("✅ All sensor calculators are properly instantiated!")
        print("✅ No more 'metric not found' rule breaches!")
        print("✅ RulesEngine integration works correctly!")
        print("✅ Ready for production deployment!")
        return True
    else:
        print(f"\n❌ Some tests failed. Calculator instantiation may need fixes.")
        return False


if __name__ == "__main__":
    success = main()
    if not success:
        sys.exit(1)