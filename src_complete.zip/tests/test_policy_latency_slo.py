# tests/test_policy_latency_slo.py
"""
Contract test for policy prediction latency SLO.
Ensures that policy bundles meet production latency requirements.
"""

import pytest
import numpy as np
import tempfile
from pathlib import Path
from unittest.mock import Mock, patch

from src.training.interfaces.rl_policy import RLPolicy
from src.training.policies.sb3_policy import TorchScriptPolicy
from src.shared.constants import MAX_PREDICTION_LATENCY_US


class MockTorchScriptPolicy(RLPolicy):
    """Mock policy for testing latency validation."""
    
    def __init__(self, prediction_latency_us: float = 50.0):
        super().__init__("mock_policy")
        self.prediction_latency_us = prediction_latency_us
    
    def predict(self, obs: np.ndarray, deterministic: bool = True):
        import time
        # Simulate prediction latency
        time.sleep(self.prediction_latency_us / 1_000_000)  # Convert µs to seconds
        return 1, {'mock': True}
    
    def save_bundle(self, bundle_path: Path):
        pass
    
    @classmethod
    def load_bundle(cls, bundle_path: Path):
        return cls()


class TestPolicyLatencySLO:
    """Test policy latency SLO compliance."""
    
    def test_fast_policy_meets_slo(self):
        """Test that fast policy meets latency SLO."""
        policy = MockTorchScriptPolicy(prediction_latency_us=30.0)  # Well under 100µs
        obs = np.random.randn(10)
        
        stats = policy.validate_prediction_latency(obs, num_trials=50)
        
        assert stats['mean_latency_us'] < MAX_PREDICTION_LATENCY_US
        assert stats['p95_latency_us'] < MAX_PREDICTION_LATENCY_US
        assert stats['p99_latency_us'] < MAX_PREDICTION_LATENCY_US
        assert stats['slo_violation_rate'] == 0.0
    
    def test_slow_policy_violates_slo(self):
        """Test that slow policy is detected as SLO violation."""
        policy = MockTorchScriptPolicy(prediction_latency_us=150.0)  # Over 100µs
        obs = np.random.randn(10)
        
        stats = policy.validate_prediction_latency(obs, num_trials=50)
        
        assert stats['mean_latency_us'] > MAX_PREDICTION_LATENCY_US
        assert stats['slo_violation_rate'] > 0.5  # Most predictions should violate
    
    def test_borderline_policy_latency(self):
        """Test policy at the edge of SLO compliance."""
        policy = MockTorchScriptPolicy(prediction_latency_us=95.0)  # Just under 100µs
        obs = np.random.randn(10)
        
        stats = policy.validate_prediction_latency(obs, num_trials=100)
        
        # Should mostly meet SLO but might have some violations due to system noise
        assert stats['mean_latency_us'] < MAX_PREDICTION_LATENCY_US * 1.1  # 10% tolerance
        assert stats['slo_violation_rate'] < 0.1  # Less than 10% violations acceptable
    
    def test_latency_statistics_structure(self):
        """Test that latency statistics have correct structure."""
        policy = MockTorchScriptPolicy(prediction_latency_us=50.0)
        obs = np.random.randn(5)
        
        stats = policy.validate_prediction_latency(obs, num_trials=20)
        
        required_keys = [
            'mean_latency_us', 'p95_latency_us', 'p99_latency_us', 'max_latency_us',
            'slo_violations', 'slo_violation_rate'
        ]
        
        for key in required_keys:
            assert key in stats
            assert isinstance(stats[key], (int, float))
        
        # Sanity checks
        assert stats['mean_latency_us'] > 0
        assert stats['p95_latency_us'] >= stats['mean_latency_us']
        assert stats['p99_latency_us'] >= stats['p95_latency_us']
        assert stats['max_latency_us'] >= stats['p99_latency_us']
        assert 0 <= stats['slo_violation_rate'] <= 1
    
    def test_different_observation_shapes(self):
        """Test latency validation with different observation shapes."""
        policy = MockTorchScriptPolicy(prediction_latency_us=40.0)
        
        # Test different observation shapes
        test_shapes = [
            (5,),      # 1D observation
            (10,),     # Larger 1D observation
            (3, 4),    # 2D observation (if supported)
        ]
        
        for shape in test_shapes:
            obs = np.random.randn(*shape)
            stats = policy.validate_prediction_latency(obs, num_trials=10)
            
            assert stats['mean_latency_us'] > 0
            assert stats['slo_violation_rate'] == 0.0  # Should meet SLO
    
    @pytest.mark.skipif(not Path("models/test_policy_bundle").exists(), 
                       reason="Test policy bundle not available")
    def test_real_torchscript_policy_latency(self):
        """Test latency of real TorchScript policy if available."""
        bundle_path = Path("models/test_policy_bundle")
        
        try:
            policy = TorchScriptPolicy.load_bundle(bundle_path)
            obs = np.random.randn(10)  # Adjust shape based on your model
            
            stats = policy.validate_prediction_latency(obs, num_trials=100)
            
            # Log results for manual inspection
            print(f"Real policy latency stats: {stats}")
            
            # Assert SLO compliance
            assert stats['p99_latency_us'] < MAX_PREDICTION_LATENCY_US * 2  # Allow 2x for CI environment
            
        except Exception as e:
            pytest.skip(f"Could not load test policy bundle: {e}")
    
    @pytest.mark.skipif(not Path("models/test_policy_bundle").exists(),
                       reason="Test policy bundle not available")
    def test_execution_agent_stub_contract(self):
        """Contract test: ExecutionAgentStub with real policy bundle."""
        from src.execution.execution_agent_stub import create_execution_agent_stub
        
        bundle_path = Path("models/test_policy_bundle")
        
        try:
            # Create execution agent stub
            agent = create_execution_agent_stub(bundle_path)
            
            # Run SLO validation
            results = agent.validate_slo_compliance(num_trials=50)
            
            # Contract assertions
            assert results['slo_violation_rate'] < 0.05  # Less than 5% violations
            assert results['p99_latency_us'] < MAX_PREDICTION_LATENCY_US * 1.5  # Allow 50% margin
            assert results['mean_latency_us'] > 0  # Sanity check
            
            # Log results
            print(f"ExecutionAgentStub contract test results: {results}")
            
        except Exception as e:
            pytest.skip(f"Could not test ExecutionAgentStub: {e}")


class TestLatencyBenchmark:
    """Benchmark tests for policy latency."""
    
    def test_numpy_baseline_latency(self):
        """Benchmark baseline NumPy operations for comparison."""
        import time
        
        obs = np.random.randn(100, 10)
        weights = np.random.randn(10, 3)
        
        latencies = []
        for i in range(100):
            start = time.perf_counter()
            result = np.dot(obs[i], weights)
            action = np.argmax(result)
            end = time.perf_counter()
            latencies.append((end - start) * 1_000_000)
        
        mean_latency = np.mean(latencies)
        p99_latency = np.percentile(latencies, 99)
        
        print(f"NumPy baseline - Mean: {mean_latency:.1f}µs, P99: {p99_latency:.1f}µs")
        
        # NumPy operations should be very fast
        assert mean_latency < 10.0  # Should be under 10µs
        assert p99_latency < 50.0   # P99 should be under 50µs
    
    def test_policy_overhead_analysis(self):
        """Analyze overhead of policy wrapper vs raw computation."""
        # This test helps identify where latency bottlenecks might be
        policy = MockTorchScriptPolicy(prediction_latency_us=1.0)  # Minimal computation
        obs = np.random.randn(10)
        
        stats = policy.validate_prediction_latency(obs, num_trials=100)
        
        # The overhead should be minimal for a mock policy
        # If this fails, there's overhead in the policy wrapper itself
        assert stats['mean_latency_us'] < 20.0  # Should be very low for mock
        
        print(f"Policy wrapper overhead: {stats['mean_latency_us']:.1f}µs")


if __name__ == "__main__":
    # Run basic latency tests
    test_suite = TestPolicyLatencySLO()
    
    print("🚀 Running Policy Latency SLO Tests")
    print("=" * 50)
    
    try:
        test_suite.test_fast_policy_meets_slo()
        print("✅ Fast policy SLO test passed")
        
        test_suite.test_slow_policy_violates_slo()
        print("✅ Slow policy detection test passed")
        
        test_suite.test_latency_statistics_structure()
        print("✅ Statistics structure test passed")
        
        test_suite.test_different_observation_shapes()
        print("✅ Different observation shapes test passed")
        
        # Run benchmark
        benchmark = TestLatencyBenchmark()
        benchmark.test_numpy_baseline_latency()
        print("✅ NumPy baseline benchmark completed")
        
        benchmark.test_policy_overhead_analysis()
        print("✅ Policy overhead analysis completed")
        
        print("\n🎯 All latency SLO tests passed!")
        print(f"   Production SLO: {MAX_PREDICTION_LATENCY_US}µs per prediction")
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        raise