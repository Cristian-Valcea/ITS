# tests/test_trainer_integration.py
"""
Integration test for the complete TrainerAgent → ExecutionAgentStub pipeline.
Validates the end-to-end contract from training to production deployment.
"""

import pytest
import tempfile
import numpy as np
import pandas as pd
from pathlib import Path
import logging

# Configure logging for tests
logging.basicConfig(level=logging.INFO)

from src.training.trainer_agent import create_trainer_agent
from src.execution.execution_agent_stub import create_execution_agent_stub
from src.gym_env.intraday_trading_env import IntradayTradingEnv
from src.shared.constants import CLOSE, MAX_PREDICTION_LATENCY_US


class TestTrainerIntegration:
    """Integration tests for TrainerAgent → ExecutionAgentStub pipeline."""
    
    @pytest.fixture
    def mock_training_data(self):
        """Create mock training data."""
        num_steps = 500
        num_features = 5
        
        # Generate mock market features
        market_features = np.random.randn(num_steps, num_features).astype(np.float32)
        
        # Generate mock price series
        prices = 100 + np.cumsum(np.random.randn(num_steps) * 0.05)
        dates = pd.date_range(start='2023-01-01', periods=num_steps, freq='1min')
        price_series = pd.Series(prices, index=dates, name=CLOSE)
        
        return market_features, price_series
    
    @pytest.fixture
    def training_env(self, mock_training_data):
        """Create training environment."""
        market_features, price_series = mock_training_data
        
        env = IntradayTradingEnv(
            processed_feature_data=market_features,
            price_data=price_series,
            initial_capital=100000,
            lookback_window=1,
            max_daily_drawdown_pct=0.05,
            transaction_cost_pct=0.001,
            max_episode_steps=100
        )
        
        return env
    
    @pytest.fixture
    def training_config(self):
        """Create training configuration."""
        return {
            'algorithm': 'DQN',
            'algo_params': {
                'policy': 'MlpPolicy',
                'learning_rate': 1e-3,
                'buffer_size': 1000,
                'learning_starts': 100,
                'batch_size': 32,
                'target_update_interval': 100,
                'exploration_fraction': 0.1,
                'exploration_final_eps': 0.1,
                'verbose': 0,  # Quiet for tests
                'seed': 42,
            },
            'training_params': {
                'total_timesteps': 1000,  # Short for tests
                'log_interval': 100,
                'checkpoint_freq': 500,
                'use_eval_callback': False,
            },
            'risk_config': {
                'enabled': False,  # Disable for basic test
            }
        }
    
    def test_end_to_end_training_to_execution(self, training_env, training_config):
        """Test complete pipeline: training → bundle → execution."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            
            # Update config with temp directories
            training_config['model_save_dir'] = str(temp_path / 'models')
            training_config['log_dir'] = str(temp_path / 'logs')
            
            # Step 1: Train model
            trainer = create_trainer_agent(training_config)
            bundle_path = trainer.run(training_env)
            
            assert bundle_path is not None, "Training should produce a model bundle"
            
            bundle_path = Path(bundle_path)
            assert bundle_path.exists(), f"Bundle path should exist: {bundle_path}"
            
            # Validate bundle structure
            assert (bundle_path / "policy.pt").exists(), "TorchScript policy should exist"
            assert (bundle_path / "metadata.json").exists(), "Metadata should exist"
            
            # Step 2: Load bundle in execution agent
            execution_agent = create_execution_agent_stub(bundle_path)
            
            # Step 3: Test prediction
            test_obs = training_env.reset()
            if isinstance(test_obs, tuple):
                test_obs = test_obs[0]  # Handle new gym API
            
            action, info = execution_agent.predict(test_obs, deterministic=True)
            
            # Validate prediction
            assert isinstance(action, (int, np.integer)), f"Action should be int, got {type(action)}"
            assert 0 <= action <= 2, f"Action should be 0-2, got {action}"
            assert 'latency_us' in info, "Info should contain latency"
            
            # Step 4: Validate SLO compliance
            slo_results = execution_agent.validate_slo_compliance(num_trials=20)
            
            assert slo_results['num_trials'] == 20
            assert slo_results['mean_latency_us'] > 0
            assert slo_results['slo_violation_rate'] <= 0.2  # Allow 20% violations in test env
            
            print(f"✅ End-to-end test passed:")
            print(f"   Bundle: {bundle_path}")
            print(f"   Mean latency: {slo_results['mean_latency_us']:.1f}µs")
            print(f"   SLO violations: {slo_results['slo_violation_rate']:.2%}")
    
    def test_policy_bundle_portability(self, training_env, training_config):
        """Test that policy bundles are portable across different environments."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            
            # Update config
            training_config['model_save_dir'] = str(temp_path / 'models')
            training_config['log_dir'] = str(temp_path / 'logs')
            
            # Train model
            trainer = create_trainer_agent(training_config)
            bundle_path = trainer.run(training_env)
            
            assert bundle_path is not None
            bundle_path = Path(bundle_path)
            
            # Test loading in multiple execution agents (simulating different processes)
            agents = []
            for i in range(3):
                agent = create_execution_agent_stub(bundle_path)
                agents.append(agent)
            
            # Test that all agents produce consistent results
            test_obs = training_env.reset()
            if isinstance(test_obs, tuple):
                test_obs = test_obs[0]
            
            actions = []
            for agent in agents:
                action, info = agent.predict(test_obs, deterministic=True)
                actions.append(action)
            
            # All agents should produce the same action (deterministic policy)
            assert len(set(actions)) == 1, f"All agents should produce same action, got {actions}"
            
            print(f"✅ Portability test passed: {len(agents)} agents, consistent action: {actions[0]}")
    
    def test_performance_regression_detection(self, training_env, training_config):
        """Test that we can detect performance regressions."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            
            # Update config
            training_config['model_save_dir'] = str(temp_path / 'models')
            training_config['log_dir'] = str(temp_path / 'logs')
            
            # Train model
            trainer = create_trainer_agent(training_config)
            bundle_path = trainer.run(training_env)
            
            assert bundle_path is not None
            
            # Create execution agent
            agent = create_execution_agent_stub(Path(bundle_path))
            
            # Benchmark against baseline
            baseline_latency = 10.0  # 10µs baseline
            benchmark_results = agent.benchmark_against_baseline(
                baseline_latency_us=baseline_latency,
                num_trials=30
            )
            
            # Validate benchmark structure
            assert 'baseline_latency_us' in benchmark_results
            assert 'overhead_us' in benchmark_results
            assert 'overhead_ratio' in benchmark_results
            assert 'efficiency_score' in benchmark_results
            
            # Log results
            print(f"✅ Performance benchmark:")
            print(f"   Baseline: {benchmark_results['baseline_latency_us']:.1f}µs")
            print(f"   Actual: {benchmark_results['mean_latency_us']:.1f}µs")
            print(f"   Overhead: {benchmark_results['overhead_us']:.1f}µs")
            print(f"   Efficiency: {benchmark_results['efficiency_score']:.2%}")
            
            # Performance should be reasonable (not more than 100x baseline)
            assert benchmark_results['overhead_ratio'] < 100.0, "Performance regression detected"
    
    @pytest.mark.skipif(True, reason="Risk-aware training requires risk config setup")
    def test_risk_aware_training_integration(self, training_env, training_config):
        """Test risk-aware training integration (placeholder)."""
        # This would test the risk-aware training pipeline
        # Requires proper risk configuration setup
        pass


if __name__ == "__main__":
    # Run tests directly
    import sys
    
    # Create test instance
    test_suite = TestTrainerIntegration()
    
    # Create fixtures manually
    num_steps = 300
    num_features = 4
    market_features = np.random.randn(num_steps, num_features).astype(np.float32)
    prices = 100 + np.cumsum(np.random.randn(num_steps) * 0.03)
    dates = pd.date_range(start='2023-01-01', periods=num_steps, freq='1min')
    price_series = pd.Series(prices, index=dates, name=CLOSE)
    
    env = IntradayTradingEnv(
        processed_feature_data=market_features,
        price_data=price_series,
        initial_capital=50000,
        lookback_window=1,
        max_daily_drawdown_pct=0.05,
        transaction_cost_pct=0.001,
        max_episode_steps=50
    )
    
    config = {
        'algorithm': 'DQN',
        'algo_params': {
            'policy': 'MlpPolicy',
            'learning_rate': 1e-3,
            'buffer_size': 500,
            'learning_starts': 50,
            'batch_size': 16,
            'target_update_interval': 50,
            'exploration_fraction': 0.1,
            'exploration_final_eps': 0.1,
            'verbose': 1,
            'seed': 42,
        },
        'training_params': {
            'total_timesteps': 500,  # Very short for manual test
            'log_interval': 50,
            'checkpoint_freq': 250,
            'use_eval_callback': False,
        },
        'risk_config': {
            'enabled': False,
        }
    }
    
    print("🚀 Running TrainerAgent Integration Tests")
    print("=" * 50)
    
    try:
        test_suite.test_end_to_end_training_to_execution(env, config)
        print("\n✅ All integration tests passed!")
        
    except Exception as e:
        print(f"\n❌ Integration test failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    
    finally:
        env.close()